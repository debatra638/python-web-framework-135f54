"""End-to-end tests for JSON, URL-encoded and multipart request bodies."""

from __future__ import annotations

import pytest
from myframework import App, request


@pytest.fixture
def api() -> App:
    app = App(__name__, TESTING=True, PROPAGATE_EXCEPTIONS=False)

    @app.route("/json", methods=["POST"])
    def json_echo():
        return {"received": request.json}

    @app.route("/form", methods=["POST"])
    def form_echo():
        return {"fields": request.form.to_dict(flat=False)}

    @app.route("/upload", methods=["POST"])
    def upload():
        stored = {
            key: {"filename": value.filename, "size": value.content_length}
            for key, value in request.files.items(multi=True)
        }
        return {"fields": request.form.to_dict(), "files": stored}

    @app.route("/query", methods=["GET"])
    def query_echo():
        return {"args": request.args.to_dict(flat=False), "raw": request.query_string_text}

    @app.route("/combined", methods=["POST"])
    def combined():
        return {
            "query": request.args["shared"],
            "form": request.form["shared"],
            "values": request.values["shared"],
        }

    return app


def test_json_roundtrip(api):
    payload = {"name": "Ada", "tags": ["a", "b"], "nested": {"n": 1}}
    response = api.test_client().post("/json", json=payload)
    assert response.status_code == 200
    assert response.json == {"received": payload}


def test_json_body_sent_as_raw_bytes(api):
    response = api.test_client().post(
        "/json", data=b'{"raw": true}', headers={"Content-Type": "application/json"}
    )
    assert response.json == {"received": {"raw": True}}


def test_json_null_body(api):
    assert api.test_client().post("/json", data=b"").json == {"received": None}


def test_urlencoded_form_multi_values(api):
    response = api.test_client().post("/form", form={"tag": ["a", "b"], "name": "x"})
    assert response.json["fields"] == {"tag": ["a", "b"], "name": ["x"]}


def test_form_with_special_characters(api):
    response = api.test_client().post("/form", form={"text": "a&b=c d"})
    assert response.json["fields"]["text"] == ["a&b=c d"]


def test_multipart_upload(api):
    response = api.test_client().post(
        "/upload",
        form={"title": "notes"},
        files={"document": ("notes.txt", b"file content")},
    )
    payload = response.json
    assert payload["fields"] == {"title": "notes"}
    assert payload["files"]["document"]["filename"] == "notes.txt"
    assert payload["files"]["document"]["size"] == len(b"file content")


def test_multiple_files_with_same_field_name(api):

    boundary = "----myframeworkboundary"
    body = (
        f"--{boundary}\r\n"
        'Content-Disposition: form-data; name="doc"; filename="a.txt"\r\n\r\n'
        "AAA\r\n"
        f"--{boundary}\r\n"
        'Content-Disposition: form-data; name="doc"; filename="b.txt"\r\n\r\n'
        "BBBB\r\n"
        f"--{boundary}--\r\n"
    ).encode()
    response = api.test_client().post(
        "/upload",
        data=body,
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
    )
    # MultiDict keeps only the first value per key in to_dict(); the view used
    # items(multi=True), so the last write for the key wins in the dict view.
    assert response.status_code == 200
    assert response.json["files"]["doc"]["filename"] == "b.txt"


def test_query_string_parsing(api):
    response = api.test_client().get("/query", query_string={"a": ["1", "2"], "b": ""})
    payload = response.json
    assert payload["args"] == {"a": ["1", "2"], "b": [""]}
    assert "a=1" in payload["raw"]


def test_query_string_in_url(api):
    response = api.test_client().get("/query?x=1&x=2")
    assert response.json["args"] == {"x": ["1", "2"]}


def test_combined_values_prefer_query_string(api):
    response = api.test_client().post("/combined?shared=query", form={"shared": "form"})
    assert response.json == {"query": "query", "form": "form", "values": "query"}


def test_unicode_form_data(api):
    response = api.test_client().post("/form", form={"name": "café"})
    assert response.json["fields"]["name"] == ["café"]


def test_large_form_within_limit(api):
    api.config["MAX_CONTENT_LENGTH"] = 10_000
    response = api.test_client().post("/form", form={"data": "x" * 5000})
    assert response.status_code == 200
