"""Shared pytest fixtures and helpers."""

from __future__ import annotations

import os
from collections.abc import Iterable, Sequence
from typing import Any

import pytest
from myframework import App
from myframework.wsgi import make_environ

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEMPLATE_DIR = os.path.join(REPO_ROOT, "examples", "templates")
STATIC_DIR = os.path.join(REPO_ROOT, "examples", "static")


@pytest.fixture
def app() -> App:
    """A small application with a representative route table."""
    application = App(
        __name__,
        template_dir=TEMPLATE_DIR,
        static_dir=STATIC_DIR,
        TESTING=True,
        PROPAGATE_EXCEPTIONS=False,
        SECRET_KEY="test-only",
    )

    @application.route("/")
    def index() -> str:
        return "<h1>Home</h1>"

    @application.route("/users/<username>")
    def user(username: str) -> str:
        return f"<h1>{username}</h1>"

    @application.route("/users/me")
    def me() -> str:
        return "<h1>me</h1>"

    @application.route("/numbers/<int:value>")
    def number(value: int) -> dict[str, Any]:
        return {"value": value, "type": type(value).__name__}

    @application.route("/files/<path:filename>")
    def files(filename: str) -> str:
        return filename

    @application.route("/api/items", methods=["GET", "POST"])
    def items() -> Any:
        from myframework import request

        if request.method == "POST":
            return {"created": request.get_json(silent=True) or request.form.to_dict()}, 201
        return {"items": []}

    @application.route("/api/items/<int:item_id>", methods=["GET", "PUT", "DELETE"])
    def item(item_id: int) -> Any:
        from myframework import request

        return {"id": item_id, "method": request.method}

    return application


@pytest.fixture
def client(app: App) -> Any:
    """A test client bound to the :func:`app` fixture."""
    return app.test_client()


def call_wsgi(
    wsgi_app: Any,
    path: str = "/",
    method: str = "GET",
    query_string: str = "",
    headers: Sequence[tuple[str, str]] | None = None,
    body: bytes = b"",
    **environ_options: Any,
) -> tuple[str, list[tuple[str, str]], bytes]:
    """Call a WSGI app directly and return ``(status, headers, body)``."""
    captured: dict[str, Any] = {}

    def start_response(
        status: str, response_headers: Iterable[tuple[str, str]], exc_info: Any = None
    ) -> Any:
        captured["status"] = status
        captured["headers"] = list(response_headers)
        return lambda data: None

    environ = make_environ(
        path=path,
        method=method,
        query_string=query_string,
        headers=headers,
        body=body,
        **environ_options,
    )
    result = wsgi_app(environ, start_response)
    chunks = list(result)
    close = getattr(result, "close", None)
    if callable(close):
        close()
    return captured["status"], captured["headers"], b"".join(chunks)


@pytest.fixture
def wsgi_call() -> Any:
    """Expose :func:`call_wsgi` as a fixture."""
    return call_wsgi
