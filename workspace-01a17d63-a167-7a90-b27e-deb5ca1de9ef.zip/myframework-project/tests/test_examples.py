"""Smoke tests for the bundled examples (they are part of the deliverable)."""

from __future__ import annotations

import importlib.util
import os
import sys
from types import ModuleType

import pytest

EXAMPLES = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "examples")


def load_example(name: str) -> ModuleType:
    path = os.path.join(EXAMPLES, f"{name}.py")
    spec = importlib.util.spec_from_file_location(f"example_{name}", path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


@pytest.fixture(scope="module")
def blog() -> ModuleType:
    return load_example("blog_app")


@pytest.fixture(scope="module")
def api() -> ModuleType:
    return load_example("api_app")


@pytest.fixture(scope="module")
def hello() -> ModuleType:
    return load_example("hello_world")


def test_hello_world_example(hello):
    client = hello.app.test_client()
    assert client.get("/").text == "<h1>My Website</h1>"
    assert "Hello, ada" in client.get("/users/ada").text
    assert client.get("/api/data").json == {"message": "Hello from my framework"}
    assert client.get("/greet?name=Ada").json == {"greeting": "Hello, Ada!"}
    assert client.post("/greet", json={"name": "Grace"}).json == {"greeting": "Hello, Grace!"}


def test_blog_index_renders_templates(blog):
    response = blog.app.test_client().get("/")
    assert response.status_code == 200
    body = response.text
    assert "<h1>MyFramework demo</h1>" in body
    assert "Welcome, visitor" in body
    assert "/static/style.css" in body
    assert "1. Templates" in body


def test_blog_users_page(blog):
    response = blog.app.test_client().get("/users")
    assert response.status_code == 200
    assert "Ada Lovelace" in response.text
    assert "Grace Hopper" in response.text


def test_blog_user_detail_escapes_bio(blog):
    response = blog.app.test_client().get("/users/Grace Hopper")
    assert response.status_code == 200
    assert "<script>alert(1)</script>" not in response.text
    assert "&lt;script&gt;" in response.text


def test_blog_user_detail_404_with_custom_handler(blog):
    response = blog.app.test_client().get("/users/nobody")
    assert response.status_code == 404
    assert "<h1>404</h1>" in response.text


def test_blog_api_get_and_post(blog):
    client = blog.app.test_client()
    listing = client.get("/api/items").json
    assert listing["count"] == len(listing["items"])
    created = client.post("/api/items", json={"name": "Gadget", "price": 3.5})
    assert created.status_code == 201
    assert created.json["name"] == "Gadget"
    assert created.headers["Location"] == "/api/items"


def test_blog_api_rejects_bad_payload(blog):
    response = blog.app.test_client().post("/api/items", json={"nope": 1})
    assert response.status_code == 400


def test_blog_redirect(blog):
    response = blog.app.test_client().get("/old-page")
    assert response.status_code == 301
    assert response.headers["Location"] == "/"


def test_blog_error_handler_for_runtime_error(blog):
    response = blog.app.test_client().get("/boom")
    assert response.status_code == 500
    assert "Something broke" in response.text


def test_blog_static_files(blog):
    response = blog.app.test_client().get("/static/style.css")
    assert response.status_code == 200
    assert "system-ui" in response.text


def test_api_app_crud(api):
    client = api.app.test_client()
    listing = client.get("/api/notes").json
    assert listing["notes"]

    created = client.post("/api/notes", json={"text": "second"})
    assert created.status_code == 201
    note_id = created.json["id"]
    assert created.headers["Location"] == f"/api/notes/{note_id}"

    fetched = client.get(f"/api/notes/{note_id}").json
    assert fetched["text"] == "second"

    patched = client.patch(f"/api/notes/{note_id}", json={"text": "edited"}).json
    assert patched["text"] == "edited"

    assert client.delete(f"/api/notes/{note_id}").status_code == 204
    assert client.get(f"/api/notes/{note_id}").status_code == 404


def test_api_app_validation(api):
    response = api.app.test_client().post("/api/notes", json={"wrong": "field"})
    assert response.status_code == 422
    assert response.json["error"] == "unprocessable_entity"


def test_api_app_middleware_headers(api):
    client = api.app.test_client()
    response = client.get("/api/notes", headers={"Origin": "https://example.com"})
    assert response.headers["X-Request-ID"]
    assert response.headers["Access-Control-Allow-Origin"] == "https://example.com"
    assert response.headers["X-Frame-Options"] == "DENY"


def test_api_app_rejects_content_over_limit(api):
    # api_app.py sets MAX_CONTENT_LENGTH = 64 KiB.
    response = api.app.test_client().post(
        "/api/notes",
        data=b'{"text": "' + b"x" * (70 * 1024) + b'"}',
        content_type="application/json",
    )
    assert response.status_code == 413
