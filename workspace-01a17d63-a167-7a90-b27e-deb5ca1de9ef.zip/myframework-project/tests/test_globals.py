"""Tests for the context-local proxies in :mod:`myframework.globals`."""

from __future__ import annotations

import concurrent.futures
import threading

import pytest
from myframework import App, Response, g, request
from myframework.globals import (
    LocalProxy,
    current_app,
    get_current_app,
    get_current_request,
    has_request_context,
    render_template,
    url_for,
)


def test_has_request_context_false_outside_request():
    assert has_request_context() is False
    with pytest.raises(RuntimeError):
        get_current_request()
    with pytest.raises(RuntimeError):
        get_current_app()


def test_proxies_work_inside_context():
    app = App(__name__, TESTING=True)

    @app.route("/")
    def index():
        return {
            "path": request.path,
            "app": current_app.name,
            "has_context": has_request_context(),
        }

    payload = app.test_client().get("/").json
    assert payload["path"] == "/"
    assert payload["has_context"] is True


def test_g_stores_values_per_request():
    app = App(__name__, TESTING=True)

    @app.before_request
    def setup():
        g.value = g.get("value", 0) + 1 if hasattr(g, "get") else 1

    @app.route("/")
    def index():
        return {"value": g.value}

    client = app.test_client()
    assert client.get("/").json == {"value": 1}
    assert client.get("/").json == {"value": 1}  # fresh g per request


def test_g_attribute_error_for_missing():
    app = App(__name__, TESTING=True)

    @app.route("/")
    def index():
        try:
            g.missing
        except AttributeError as exc:
            return {"message": str(exc)}
        return {}

    payload = app.test_client().get("/").json
    assert "no attribute 'missing'" in payload["message"]


def test_g_delete_and_contains():
    app = App(__name__, TESTING=True)

    @app.route("/")
    def index():
        g.a = 1
        had = "a" in g
        del g.a
        return {"had": had, "has_now": "a" in g}

    assert app.test_client().get("/").json == {"had": True, "has_now": False}


def test_g_clear():
    app = App(__name__, TESTING=True)

    @app.route("/")
    def index():
        g.x = 1
        g._values.clear()
        return {"has": "x" in g}

    assert app.test_client().get("/").json == {"has": False}


def test_url_for_and_render_template_helpers():
    app = App(__name__, TESTING=True)

    @app.route("/")
    def index():
        return "home"

    @app.route("/helper")
    def helper():
        return {"url": url_for("index"), "html": render_template("x.html", v=1)}

    app.config["TEMPLATE_DIR"] = None
    app._template_env = None
    from myframework.templates import DictLoader, Environment

    app._template_env = Environment(loader=DictLoader({"x.html": "v={{ v }}"}))
    assert app.test_client().get("/helper").json == {"url": "/", "html": "v=1"}


def test_local_proxy_dunder_behaviour():
    value = {"a": [1, 2, 3]}
    proxy = LocalProxy("value", lambda: value)
    assert proxy["a"] == [1, 2, 3]
    assert len(proxy) == 1
    assert "a" in proxy
    assert list(proxy) == ["a"]
    assert bool(proxy) is True
    assert proxy == value
    assert proxy != {}
    hashable = LocalProxy("hashable", lambda: "text")
    assert hash(hashable) == hash("text")
    assert str(proxy) == str(value)
    proxy["b"] = 2
    assert value["b"] == 2


def test_local_proxy_setattr_and_call():
    class Thing:
        def __init__(self):
            self.value = 1

        def __call__(self, x):
            return x * 2

    thing = Thing()
    proxy = LocalProxy("thing", lambda: thing)
    proxy.value = 5
    assert thing.value == 5
    assert proxy(3) == 6
    del proxy.value
    assert not hasattr(thing, "value")


def test_local_proxy_unbound_repr_and_bool():
    proxy = LocalProxy("nothing", lambda: (_ for _ in ()).throw(LookupError()))
    assert bool(proxy) is False
    assert "unbound" in repr(proxy)


def test_request_context_manager_pops_on_exception():
    app = App(__name__, TESTING=True)

    with pytest.raises(ValueError):
        with app.test_request_context("/"):
            assert request.path == "/"
            raise ValueError("boom")
    assert has_request_context() is False


def test_context_isolated_between_threads():
    app = App(__name__, TESTING=True)

    @app.route("/echo/<value>")
    def echo(value):
        threading.Event().wait(0.01)
        return {"value": value, "path": request.path}

    def fetch(value):
        return app.test_client().get(f"/echo/{value}").json

    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        results = list(pool.map(fetch, [str(i) for i in range(12)]))

    for index, payload in enumerate(results):
        assert payload["value"] == str(index)
        assert payload["path"] == f"/echo/{index}"


def test_request_context_push_pop_directly():
    app = App(__name__, TESTING=True)
    context = app.test_request_context("/direct")
    context.push()
    try:
        assert request.path == "/direct"
        assert current_app.name == app.import_name
    finally:
        context.pop()
    assert has_request_context() is False


def test_nested_contexts():
    app = App(__name__, TESTING=True)
    with app.test_request_context("/outer"):
        assert request.path == "/outer"
        with app.test_request_context("/inner"):
            assert request.path == "/inner"
        assert request.path == "/outer"


def test_current_app_proxy_in_view():
    app = App(__name__, TESTING=True)

    @app.route("/")
    def index():
        return {"name": current_app.name, "debug": current_app.config["DEBUG"]}

    assert app.test_client().get("/").json == {"name": app.import_name, "debug": False}


def test_request_is_slotted_use_g_for_custom_state():
    """``Request`` has no ``__dict__`` on purpose (less memory per request)."""
    app = App(__name__, TESTING=True)

    @app.route("/")
    def index():
        g.custom = "x"
        try:
            request.custom = "y"
        except AttributeError:
            return {"value": g.custom, "request_is_slotted": True}
        return {"value": g.custom, "request_is_slotted": False}

    assert app.test_client().get("/").json == {"value": "x", "request_is_slotted": True}


def test_app_globals_repr():
    app = App(__name__, TESTING=True)

    @app.route("/")
    def index():
        g.thing = Response("x")
        return {"repr": repr(g)}

    assert "g {" in app.test_client().get("/").json["repr"]
