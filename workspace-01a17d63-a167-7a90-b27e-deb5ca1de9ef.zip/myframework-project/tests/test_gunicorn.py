"""Integration test: run the application under Gunicorn (a real WSGI server).

Skipped automatically when Gunicorn is not installed or on platforms without it.
"""

from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request

import pytest

pytest.importorskip(
    "gunicorn", reason="gunicorn is an optional dependency (pip install myframework[servers])"
)

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

pytestmark = [pytest.mark.slow, pytest.mark.requires_gunicorn]


def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def wait_for_port(port: int, timeout: float = 30.0) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.5):
                return
        except OSError:
            time.sleep(0.1)
    raise AssertionError(f"gunicorn did not start on port {port}")


@pytest.fixture(scope="module")
def gunicorn_server(tmp_path_factory):
    directory = tmp_path_factory.mktemp("gunicorn_app")
    (directory / "guni_app.py").write_text(
        "from myframework import App, request\n"
        "app = App(__name__)\n"
        "@app.route('/')\n"
        "def index():\n"
        "    return '<h1>gunicorn</h1>'\n"
        "@app.route('/json')\n"
        "def json_view():\n"
        "    return {'ok': True, 'method': request.method}\n"
        "@app.route('/echo', methods=['POST'])\n"
        "def echo():\n"
        "    return {'body': request.get_data(as_text=True)}\n",
        encoding="utf-8",
    )
    port = free_port()
    env = dict(os.environ)
    env["PYTHONPATH"] = REPO_ROOT
    process = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "gunicorn",
            "--workers",
            "2",
            "--bind",
            f"127.0.0.1:{port}",
            "--log-level",
            "error",
            "guni_app:app",
        ],
        cwd=str(directory),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    try:
        wait_for_port(port)
        yield f"http://127.0.0.1:{port}"
    finally:
        process.terminate()
        try:
            process.wait(timeout=15)
        except subprocess.TimeoutExpired:  # pragma: no cover
            process.kill()
            process.wait(timeout=5)


def test_gunicorn_serves_html(gunicorn_server):
    with urllib.request.urlopen(gunicorn_server + "/", timeout=10) as response:
        assert response.status == 200
        assert response.read() == b"<h1>gunicorn</h1>"
        assert response.headers["Content-Type"] == "text/html; charset=utf-8"


def test_gunicorn_serves_json(gunicorn_server):
    with urllib.request.urlopen(gunicorn_server + "/json", timeout=10) as response:
        assert json.loads(response.read()) == {"ok": True, "method": "GET"}


def test_gunicorn_handles_post(gunicorn_server):
    request = urllib.request.Request(
        gunicorn_server + "/echo",
        data=b"through gunicorn",
        headers={"Content-Type": "text/plain"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=10) as response:
        assert json.loads(response.read()) == {"body": "through gunicorn"}


def test_gunicorn_returns_404(gunicorn_server):
    with pytest.raises(urllib.error.HTTPError) as excinfo:
        urllib.request.urlopen(gunicorn_server + "/missing", timeout=10)
    assert excinfo.value.code == 404


def test_gunicorn_handles_concurrent_requests(gunicorn_server):
    import threading

    statuses: list[int] = []

    def fetch() -> None:
        with urllib.request.urlopen(gunicorn_server + "/json", timeout=15) as response:
            statuses.append(response.status)

    threads = [threading.Thread(target=fetch) for _ in range(6)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=20)
    assert statuses == [200] * 6
