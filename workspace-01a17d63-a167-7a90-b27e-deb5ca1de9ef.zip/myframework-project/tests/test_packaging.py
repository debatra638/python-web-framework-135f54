"""Tests that guard the *library* contract: metadata, exports, docs, artifacts.

These are cheap checks that catch the mistakes which make a package look finished
to its author but unusable to everyone else — a version that drifts from the
build configuration, a public name that is exported but missing, a missing
``py.typed`` marker, documentation that no longer matches the code.
"""

from __future__ import annotations

import importlib
import os
import re
import subprocess
import sys
from pathlib import Path

import myframework
import pytest

ROOT = Path(__file__).resolve().parent.parent


def test_version_is_a_pep440_string():
    assert re.fullmatch(r"\d+\.\d+\.\d+([abc]|rc|\.post|\.dev)?\d*", myframework.__version__)


def test_version_matches_metadata_when_installed():
    """The build reads the version from ``__init__``; this catches any drift."""
    from importlib import metadata

    try:
        installed = metadata.version("myframework")
    except metadata.PackageNotFoundError:  # running from a plain source checkout
        pytest.skip("myframework is not installed as a distribution")
    assert installed == myframework.__version__


def test_all_public_names_exist_and_are_sorted():
    names = myframework.__all__
    assert len(names) == len(set(names)), "duplicate entries in __all__"
    for name in names:
        assert hasattr(myframework, name), f"__all__ lists {name!r} but it is not importable"
    without_version = [name for name in names if name != "__version__"]
    assert without_version == sorted(without_version), "__all__ should stay alphabetically sorted"
    assert "__version__" in names


def test_star_import_exposes_the_documented_api():
    namespace: dict[str, object] = {}
    exec("from myframework import *", namespace)  # the point of the test
    missing = [name for name in myframework.__all__ if name not in namespace]
    assert not missing, f"star import is missing {missing}"


def test_every_submodule_imports_cleanly():
    package_dir = Path(myframework.__file__).parent
    modules = sorted(
        path.stem for path in package_dir.glob("*.py") if not path.stem.startswith("_")
    )
    assert "app" in modules and "templates" in modules
    for module in modules:
        importlib.import_module(f"myframework.{module}")


def test_py_typed_marker_ships_with_the_package():
    assert (Path(myframework.__file__).parent / "py.typed").is_file()


def test_package_has_no_runtime_dependencies():
    from importlib import metadata

    try:
        requires = metadata.requires("myframework") or []
    except metadata.PackageNotFoundError:  # pragma: no cover - source checkout
        pytest.skip("myframework is not installed as a distribution")
    unconditional = [item for item in requires if "extra ==" not in item]
    assert unconditional == [], f"unexpected runtime dependencies: {unconditional}"


def test_console_entry_point_is_declared():
    from importlib import metadata

    config = ROOT / "pyproject.toml"
    assert 'myframework = "myframework.cli:main"' in config.read_text(encoding="utf-8")

    try:
        scripts = metadata.entry_points(group="console_scripts")
    except TypeError:  # pragma: no cover - very old Python
        scripts = metadata.entry_points().get("console_scripts", [])  # type: ignore[attr-defined]
    names = {entry.name for entry in scripts}
    if "myframework" in names:  # only when installed
        entry = next(entry for entry in scripts if entry.name == "myframework")
        assert entry.value == "myframework.cli:main"
        assert callable(entry.load())


def test_python_module_entry_point_works():
    result = subprocess.run(
        [sys.executable, "-m", "myframework", "version"],
        capture_output=True,
        text=True,
        cwd=str(ROOT),
        env={**os.environ, "PYTHONPATH": str(ROOT)},
        timeout=60,
    )
    assert result.returncode == 0, result.stderr
    assert myframework.__version__ in result.stdout


@pytest.mark.parametrize(
    "path",
    [
        "README.md",
        "CHANGELOG.md",
        "LICENSE",
        "MANIFEST.in",
        "docs/installation.md",
        "docs/quickstart.md",
        "docs/api.md",
        "docs/architecture.md",
        "docs/security.md",
        "docs/deployment.md",
        "scripts/check.sh",
        "scripts/verify_install.sh",
    ],
)
def test_shipped_files_exist(path):
    assert (ROOT / path).is_file(), f"{path} is referenced in the docs but missing"


def test_readme_mentions_the_current_version_and_key_commands():
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    assert myframework.__version__ not in {"", None}
    assert "pip install" in readme
    assert "myframework run" in readme
    assert "docs/quickstart.md" in readme
    assert "docs/api.md" in readme
    assert "Implemented" in readme


def test_api_reference_is_up_to_date():
    result = subprocess.run(
        [sys.executable, "scripts/build_api_docs.py", "--check"],
        capture_output=True,
        text=True,
        cwd=str(ROOT),
        timeout=120,
    )
    assert result.returncode == 0, result.stdout + result.stderr


def test_manifest_covers_everything_a_contributor_needs():
    manifest = (ROOT / "MANIFEST.in").read_text(encoding="utf-8")
    for pattern in ("README.md", "LICENSE", "CHANGELOG.md", "tests", "docs", "examples", "scripts"):
        assert pattern in manifest, f"MANIFEST.in does not mention {pattern}"
    # conftest.py is required for the shipped tests to run at all.
    assert "tests/conftest.py" in manifest


def test_pyproject_has_the_metadata_pypi_requires():
    tomllib = pytest.importorskip("tomllib")
    config = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    project = config["project"]
    for key in ("name", "description", "readme", "license", "requires-python", "classifiers"):
        assert key in project, f"pyproject.toml [project] is missing {key}"
    assert project["name"] == "myframework"
    # The version is single-sourced from myframework.__version__.
    assert project["dynamic"] == ["version"]
    assert "version" not in project
    dynamic = config["tool"]["setuptools"]["dynamic"]["version"]
    assert dynamic == {"attr": "myframework.__version__"}


def test_no_placeholder_urls_in_metadata():
    config = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    assert "example.invalid" not in config
    assert "TODO@" not in config


def test_examples_run_against_the_public_api():
    examples = sorted((ROOT / "examples").glob("*.py"))
    assert examples, "no examples to check"
    for path in examples:
        source = path.read_text(encoding="utf-8")
        assert "from myframework import" in source
        compile(source, str(path), "exec")
