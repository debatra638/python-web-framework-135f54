"""Tests for the WSGI middleware collection."""

from __future__ import annotations

import logging

import pytest
from myframework import App
from myframework.middleware import (
    AccessLogMiddleware,
    CORSMiddleware,
    HeaderMiddleware,
    HTTPSRedirectMiddleware,
    MiddlewareStack,
    ProxyFix,
    RequestIDMiddleware,
    SecurityHeadersMiddleware,
    TrustedHostMiddleware,
    WSGIMiddleware,
)

from conftest import call_wsgi


@pytest.fixture
def simple_app() -> App:
    app = App(__name__, TESTING=True, PROPAGATE_EXCEPTIONS=False)

    @app.route("/")
    def index():
        from myframework import request

        return {
            "host": request.host,
            "scheme": request.scheme,
            "remote": request.remote_addr,
            "script": request.script_name,
            "request_id": request.environ.get("myframework.request_id"),
        }

    return app


def header_dict(headers):
    return {name.lower(): value for name, value in headers}


def test_custom_middleware_process_hooks(simple_app):
    class Marker(WSGIMiddleware):
        def process_environ(self, environ):
            environ["myframework.marker"] = "yes"
            return environ

        def process_response(self, status, headers):
            headers.append(("X-Middleware", "1"))
            return status, headers

    class Reader(WSGIMiddleware):
        def process_environ(self, environ):
            environ["myframework.seen"] = environ.get("myframework.marker", "no")
            return environ

    base = App(__name__, TESTING=True)

    @base.route("/")
    def index():
        from myframework import request

        return {"marker": request.environ.get("myframework.seen")}

    base.use(Marker())
    base.use(Reader())
    status, headers, body = call_wsgi(base)
    assert status == "200 OK"
    assert header_dict(headers)["x-middleware"] == "1"
    assert b'"marker": "yes"' in body


def test_middleware_ordering_outermost_first():
    app = App(__name__, TESTING=True)
    order = []

    class Layer(WSGIMiddleware):
        def __init__(self, name, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.name = name

        def process_response(self, status, headers):
            order.append(self.name)
            headers.append(("X-Order", self.name))
            return status, headers

    app.use(Layer("first"))
    app.use(Layer("second"))

    @app.route("/")
    def index():
        return "ok"

    status, headers, body = call_wsgi(app)
    # Innermost middleware appends first, outermost last.
    assert order == ["second", "first"]
    # But the outermost middleware gets the last word on the response headers.
    values = [value for name, value in headers if name == "X-Order"]
    assert values[-1] == "first"


def test_request_id_middleware_generates_and_echoes(simple_app):
    simple_app.use(RequestIDMiddleware())
    status, headers, body = call_wsgi(simple_app)
    request_id = header_dict(headers)["x-request-id"]
    assert len(request_id) == 32
    assert request_id.encode() in body


def test_request_id_middleware_reuses_inbound_header(simple_app):
    simple_app.use(RequestIDMiddleware())
    status, headers, body = call_wsgi(simple_app, headers=[("X-Request-ID", "abc-123")])
    assert header_dict(headers)["x-request-id"] == "abc-123"
    assert b"abc-123" in body


def test_access_log_middleware(simple_app, caplog):
    simple_app.use(AccessLogMiddleware())
    with caplog.at_level(logging.INFO, logger="myframework.access"):
        call_wsgi(simple_app, "/")
    assert any("GET / 200 OK" in record.getMessage() for record in caplog.records)


def test_security_headers_middleware(simple_app):
    simple_app.use(SecurityHeadersMiddleware())
    status, headers, body = call_wsgi(simple_app)
    values = header_dict(headers)
    assert values["x-content-type-options"] == "nosniff"
    assert values["x-frame-options"] == "DENY"
    assert values["referrer-policy"] == "strict-origin-when-cross-origin"
    assert "default-src 'self'" in values["content-security-policy"]
    assert "strict-transport-security" not in values  # opt-in (HTTPS only)


def test_security_headers_hsts_enabled():
    app = App(__name__, TESTING=True)
    app.add_url_rule("/", "index", lambda: "ok")
    app.use(SecurityHeadersMiddleware(hsts_max_age=3600))
    status, headers, body = call_wsgi(app)
    assert header_dict(headers)["strict-transport-security"] == "max-age=3600"


def test_header_middleware_does_not_override(simple_app):
    @simple_app.after_request
    def set_header(response):
        response.headers["X-Custom"] = "app"
        return response

    simple_app.use(HeaderMiddleware(headers={"X-Custom": "middleware", "X-Other": "1"}))
    status, headers, body = call_wsgi(simple_app)
    values = header_dict(headers)
    assert values["x-custom"] == "app"
    assert values["x-other"] == "1"


def test_cors_simple_request_allowed_origin(simple_app):
    simple_app.use(CORSMiddleware(allow_origins=["https://good.test"]))
    status, headers, body = call_wsgi(simple_app, headers=[("Origin", "https://good.test")])
    values = header_dict(headers)
    assert values["access-control-allow-origin"] == "https://good.test"
    assert values["vary"] == "Origin"


def test_cors_disallowed_origin_has_no_headers(simple_app):
    simple_app.use(CORSMiddleware(allow_origins=["https://good.test"]))
    status, headers, body = call_wsgi(simple_app, headers=[("Origin", "https://evil.test")])
    assert "access-control-allow-origin" not in header_dict(headers)


def test_cors_preflight(simple_app):
    simple_app.use(CORSMiddleware(allow_origins=["https://good.test"], allow_credentials=True))
    status, headers, body = call_wsgi(
        simple_app,
        method="OPTIONS",
        headers=[
            ("Origin", "https://good.test"),
            ("Access-Control-Request-Method", "POST"),
        ],
    )
    assert status == "204 No Content"
    values = header_dict(headers)
    assert values["access-control-allow-origin"] == "https://good.test"
    assert values["access-control-allow-credentials"] == "true"
    assert "POST" in values["access-control-allow-methods"]


def test_cors_wildcard_with_credentials_echoes_origin(simple_app):
    simple_app.use(CORSMiddleware(allow_origins="*", allow_credentials=True))
    status, headers, body = call_wsgi(simple_app, headers=[("Origin", "https://any.test")])
    assert header_dict(headers)["access-control-allow-origin"] == "https://any.test"


def test_cors_callable_origin(simple_app):
    simple_app.use(
        CORSMiddleware(
            allow_origins=lambda origin: origin if origin and origin.endswith(".test") else None
        )
    )
    status, headers, body = call_wsgi(simple_app, headers=[("Origin", "https://sub.test")])
    assert header_dict(headers)["access-control-allow-origin"] == "https://sub.test"


def test_trusted_host_rejects_unknown(simple_app):
    simple_app.use(TrustedHostMiddleware(allowed_hosts=["example.com"]))
    status, headers, body = call_wsgi(simple_app, headers=[("Host", "evil.test")])
    assert status.startswith("400")
    status, headers, body = call_wsgi(simple_app, headers=[("Host", "example.com")])
    assert status == "200 OK"


def test_trusted_host_wildcard(simple_app):
    simple_app.use(TrustedHostMiddleware(allowed_hosts=["*.example.com"]))
    assert call_wsgi(simple_app, headers=[("Host", "api.example.com")])[0] == "200 OK"
    assert call_wsgi(simple_app, headers=[("Host", "example.org")])[0].startswith("400")


def test_proxy_fix_reads_forwarded_headers(simple_app):
    simple_app.use(ProxyFix(x_for=1, x_proto=1, x_host=1, x_prefix=1))
    status, headers, body = call_wsgi(
        simple_app,
        headers=[
            ("X-Forwarded-For", "203.0.113.9, 10.0.0.1"),
            ("X-Forwarded-Proto", "https"),
            ("X-Forwarded-Host", "public.example.com"),
            ("X-Forwarded-Prefix", "/api"),
        ],
    )
    import json

    payload = json.loads(body)
    assert payload["remote"] == "10.0.0.1"  # last hop (trusted proxy)
    assert payload["scheme"] == "https"
    assert payload["host"] == "public.example.com"
    assert payload["script"] == "/api"


def test_proxy_fix_ignores_headers_when_disabled(simple_app):
    simple_app.use(ProxyFix(x_for=0, x_proto=0, x_host=0))
    status, headers, body = call_wsgi(
        simple_app,
        headers=[("X-Forwarded-For", "203.0.113.9"), ("X-Forwarded-Proto", "https")],
    )
    import json

    payload = json.loads(body)
    assert payload["remote"] == "127.0.0.1"
    assert payload["scheme"] == "http"


def test_https_redirect(simple_app):
    simple_app.use(HTTPSRedirectMiddleware())
    status, headers, body = call_wsgi(simple_app, "/path", query_string="a=1")
    assert status.startswith("308")
    assert header_dict(headers)["location"] == "https://localhost/path?a=1"


def test_https_redirect_passes_through_https(simple_app):
    simple_app.use(HTTPSRedirectMiddleware())
    status, headers, body = call_wsgi(simple_app, scheme="https")
    assert status == "200 OK"


def test_middleware_stack_build(simple_app):
    stack = MiddlewareStack(simple_app)
    stack.add(SecurityHeadersMiddleware())
    stack.add(RequestIDMiddleware())
    wrapped = stack.build()
    status, headers, body = call_wsgi(wrapped)
    assert status == "200 OK"
    assert "x-request-id" in header_dict(headers)
    assert "x-frame-options" in header_dict(headers)


def test_middleware_requires_bound_app():
    with pytest.raises(RuntimeError):
        SecurityHeadersMiddleware()({}, lambda *a: None)


def test_middleware_works_with_plain_wsgi_app():
    def plain(environ, start_response):
        start_response("200 OK", [("Content-Type", "text/plain")])
        return [b"plain"]

    wrapped = SecurityHeadersMiddleware(plain)
    status, headers, body = call_wsgi(wrapped)
    assert status == "200 OK"
    assert body == b"plain"
    assert header_dict(headers)["x-frame-options"] == "DENY"
