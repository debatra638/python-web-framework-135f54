"""Tests for the template engine."""

from __future__ import annotations

import os

import pytest
from myframework.exceptions import (
    SecurityError,
    TemplateNotFound,
    TemplateRuntimeError,
    TemplateSyntaxError,
    UndefinedError,
)
from myframework.templates import (
    DictLoader,
    Environment,
    FileSystemLoader,
    Markup,
    split_filters,
    tokenize,
)

from conftest import TEMPLATE_DIR


@pytest.fixture
def env() -> Environment:
    return Environment()


def render(source: str, **context) -> str:
    return Environment().from_string(source).render(context)


# -- interpolation and escaping ---------------------------------------------
def test_variable_interpolation():
    assert render("Hello {{ name }}!", name="Ada") == "Hello Ada!"


def test_html_is_escaped_by_default():
    assert render("{{ value }}", value="<script>alert(1)</script>") == (
        "&lt;script&gt;alert(1)&lt;/script&gt;"
    )


def test_escaping_of_all_special_characters():
    assert render("{{ v }}", v="""&<>"'""") == "&amp;&lt;&gt;&#34;&#39;"


def test_markup_is_not_double_escaped():
    assert render("{{ v }}", v=Markup("<b>bold</b>")) == "<b>bold</b>"


def test_safe_filter_marks_html():
    assert render("{{ v|safe }}", v="<b>x</b>") == "<b>x</b>"


def test_e_filter_escapes_explicitly():
    assert render("{{ v|e }}", v="<i>") == "&lt;i&gt;"


def test_autoescape_disabled():
    environment = Environment(autoescape=False)
    assert environment.from_string("{{ v }}").render(v="<b>") == "<b>"


def test_none_renders_empty():
    assert render("[{{ v }}]", v=None) == "[]"


def test_numbers_and_arithmetic():
    assert render("{{ 1 + 2 }} {{ 7 // 2 }} {{ 2 ** 8 }}") == "3 3 256"


def test_comparisons_and_booleans():
    assert render("{{ 1 < 2 and 3 > 2 }}") == "True"
    assert render("{{ 'a' in 'cat' }}") == "True"
    assert render("{{ not False }}") == "True"


def test_conditional_expression():
    assert render("{{ 'yes' if ok else 'no' }}", ok=True) == "yes"


def test_fstring_support():
    assert render('{{ f"{n:03d}" }}', n=7) == "007"


def test_attribute_and_index_access():
    assert render("{{ user.name }} {{ user['name'] }}", user={"name": "Ada"}) == "Ada Ada"
    assert render("{{ items[1] }}", items=["a", "b"]) == "b"


def test_slicing():
    assert render("{{ items[0:2] }}", items=[1, 2, 3]) == "[1, 2]"


def test_dict_and_list_literals():
    assert render("{{ {'a': 1}['a'] }} {{ [1, 2]|length }}") == "1 2"


# -- undefined handling ------------------------------------------------------
def test_undefined_raises_by_default():
    with pytest.raises(UndefinedError) as excinfo:
        render("{{ missing }}")
    assert "missing" in str(excinfo.value)


def test_undefined_message_lists_known_names():
    with pytest.raises(UndefinedError) as excinfo:
        Environment().from_string("{{ nope }}").render(known="value")
    assert "known" in str(excinfo.value)


def test_default_filter_makes_optional_variables_work():
    assert render("{{ missing|default('fallback') }}") == "fallback"
    assert render("{{ present|default('fallback') }}", present="here") == "here"


def test_lenient_mode_renders_empty():
    environment = Environment(undefined="lenient")
    assert environment.from_string("[{{ missing }}]").render() == "[]"
    assert environment.from_string("[{{ missing.deep }}]").render() == "[]"


def test_missing_attribute_is_an_error():
    with pytest.raises(TemplateRuntimeError):
        render("{{ user.nope }}", user={"name": "x"})


# -- statements --------------------------------------------------------------
def test_if_elif_else():
    template = "{% if n > 2 %}big{% elif n == 2 %}two{% else %}small{% endif %}"
    assert render(template, n=3) == "big"
    assert render(template, n=2) == "two"
    assert render(template, n=1) == "small"


def test_for_loop_with_loop_variables():
    template = (
        "{% for item in items %}{{ loop.index }}/{{ loop.length }}"
        "{% if loop.first %}F{% endif %}{% if loop.last %}L{% endif %} "
        "{% endfor %}"
    )
    assert render(template, items=["a", "b", "c"]) == "1/3F 2/3 3/3L "


def test_loop_properties():
    template = (
        "{% for x in xs %}{{ loop.index0 }}{{ loop.revindex }}{{ loop.cycle('a', 'b') }}"
        "{% endfor %}"
    )
    assert render(template, xs=["x", "y"]) == "02a11b"


def test_for_else():
    assert render("{% for x in xs %}{{ x }}{% else %}empty{% endfor %}", xs=[]) == "empty"


def test_tuple_unpacking_in_loops():
    template = "{% for k, v in pairs %}{{ k }}={{ v }};{% endfor %}"
    assert render(template, pairs=[("a", 1), ("b", 2)]) == "a=1;b=2;"


def test_iterating_a_mapping():
    assert render("{% for k, v in d.items() %}{{ k }}{% endfor %}", d={"a": 1, "b": 2}) == "ab"


def test_set_statement():
    assert render("{% set x = 5 %}{{ x + 1 }}") == "6"


def test_set_inside_loop_is_scoped():
    assert (
        render("{% for i in [1,2] %}{% set y = i %}{% endfor %}[{{ y|default('none') }}]")
        == "[none]"
    )


def test_comments_are_removed():
    assert render("a{# hidden #}b") == "ab"


def test_raw_block_is_not_parsed():
    assert render("{% raw %}{{ x }}{% endraw %}") == "{{ x }}"


def test_whitespace_control():
    assert render("{%- for i in [1,2] -%} {{ i }} {%- endfor -%}") == "12"


# -- inheritance -------------------------------------------------------------
def test_template_inheritance_with_blocks():
    loader = DictLoader(
        {
            "base.html": "<title>{% block title %}Base{% endblock %}</title>"
            "<body>{% block body %}base body{% endblock %}</body>",
            "child.html": '{% extends "base.html" %}'
            "{% block title %}Child{% endblock %}"
            "{% block body %}child body{% endblock %}",
        }
    )
    env = Environment(loader=loader)
    assert env.get_template("child.html").render() == (
        "<title>Child</title><body>child body</body>"
    )


def test_inheritance_can_skip_blocks():
    loader = DictLoader(
        {
            "base.html": "[{% block a %}A{% endblock %}][{% block b %}B{% endblock %}]",
            "child.html": '{% extends "base.html" %}{% block b %}custom{% endblock %}',
        }
    )
    assert Environment(loader=loader).get_template("child.html").render() == "[A][custom]"


def test_super_in_blocks():
    loader = DictLoader(
        {
            "base.html": "{% block content %}base{% endblock %}",
            "mid.html": '{% extends "base.html" %}{% block content %}mid({{ super() }})'
            "{% endblock %}",
            "leaf.html": '{% extends "mid.html" %}{% block content %}leaf({{ super() }})'
            "{% endblock %}",
        }
    )
    assert Environment(loader=loader).get_template("leaf.html").render() == ("leaf(mid(base))")


def test_include_partial():
    loader = DictLoader(
        {
            "page.html": "<div>{% include 'nav.html' %}</div>",
            "nav.html": "<a>{{ label }}</a>",
        }
    )
    assert Environment(loader=loader).get_template("page.html").render(label="Home") == (
        "<div><a>Home</a></div>"
    )


def test_include_ignore_missing():
    env = Environment(loader=DictLoader({"p.html": "{% include 'nope.html' ignore missing %}ok"}))
    assert env.get_template("p.html").render() == "ok"


def test_include_missing_raises():
    env = Environment(loader=DictLoader({"p.html": "{% include 'nope.html' %}"}))
    with pytest.raises(TemplateNotFound):
        env.get_template("p.html").render()


def test_missing_parent_template():
    env = Environment(loader=DictLoader({"c.html": '{% extends "nope.html" %}'}))
    with pytest.raises(TemplateNotFound):
        env.get_template("c.html").render()


def test_blocks_inside_conditionals_are_registered():
    loader = DictLoader(
        {
            "base.html": "{% block a %}A{% endblock %}",
            "child.html": (
                "{% extends 'base.html' %}{% if true %}{% block a %}X{% endblock %}{% endif %}"
            ),
        }
    )
    assert Environment(loader=loader).get_template("child.html").render() == "X"


# -- filters -----------------------------------------------------------------
@pytest.mark.parametrize(
    ("source", "context", "expected"),
    [
        ("{{ 'abc'|upper }}", {}, "ABC"),
        ("{{ 'ABC'|lower }}", {}, "abc"),
        ("{{ '  x  '|trim }}", {}, "x"),
        ("{{ 'hello world'|title }}", {}, "Hello World"),
        ("{{ [1,2,3]|length }}", {}, "3"),
        ("{{ [1,2,3]|join('-') }}", {}, "1-2-3"),
        ("{{ ['b','a']|sort|join('') }}", {}, "ab"),
        ("{{ [1,2]|reverse|join('') }}", {}, "21"),
        ("{{ '3'|int }}", {}, "3"),
        ("{{ 3.14159|round(2) }}", {}, "3.14"),
        ("{{ 'a b'|urlencode }}", {}, "a%20b"),
        ("{{ '<b>x</b>'|striptags }}", {}, "x"),
        ("{{ 'abcdefghij'|truncate(8, end='…') }}", {}, "abcdefg…"),
        ("{{ {'a': 1}|tojson }}", {}, '{"a": 1}'),
        ("{{ 'x'|replace('x', 'y') }}", {}, "y"),
    ],
)
def test_filters(source, context, expected):
    assert Environment().from_string(source).render(context) == expected


def test_tojson_escapes_script_tags():
    output = Environment().from_string("{{ data|tojson }}").render(data={"x": "<script>"})
    assert "\\u003cscript\\u003e" in output


def test_filter_with_string_containing_pipe():
    assert render("{{ 'a|b'|upper }}") == "A|B"


def test_split_filters_helper():
    base, filters = split_filters("value|upper|default('x')")
    assert base == "value"
    assert filters == ["upper", "default('x')"]


def test_unknown_filter_has_helpful_error():
    with pytest.raises(TemplateRuntimeError) as excinfo:
        render("{{ 'x'|nope }}")
    assert "Unknown template filter" in str(excinfo.value)
    assert "upper" in str(excinfo.value)


def test_filter_error_is_wrapped():
    with pytest.raises(TemplateRuntimeError):
        render("{{ 'x'|round(2) }}")


def test_custom_filter():
    environment = Environment(filters={"shout": lambda value: str(value).upper() + "!"})
    assert environment.from_string("{{ 'hi'|shout }}").render() == "HI!"


# -- safety ------------------------------------------------------------------
def test_private_attribute_access_blocked():
    with pytest.raises(TemplateRuntimeError) as excinfo:
        render("{{ obj.__class__ }}", obj=1)
    assert "private attribute" in str(excinfo.value)


def test_private_method_call_blocked():
    with pytest.raises(TemplateRuntimeError):
        render("{{ obj._private() }}", obj=object())


def test_lambda_expressions_rejected():
    with pytest.raises(TemplateRuntimeError) as excinfo:
        render("{{ (lambda: 1)() }}")
    assert "Lambda" in str(excinfo.value)


def test_comprehensions_rejected():
    with pytest.raises(TemplateRuntimeError):
        render("{{ [x for x in [1,2]] }}")


def test_dunder_import_not_possible():
    with pytest.raises((TemplateRuntimeError, TemplateSyntaxError)):
        render("{{ __import__('os').system('true') }}")


def test_calling_non_callable_is_an_error():
    with pytest.raises(TemplateRuntimeError):
        render("{{ x() }}", x=5)


# -- syntax errors -----------------------------------------------------------
@pytest.mark.parametrize(
    "source",
    [
        "{% if true %}unclosed",
        "{% for x in y %}unclosed",
        "{% block a %}unclosed",
        "{% endif %}",
        "{{ unclosed",
        "{% unknown %}",
        "{% set bad %}",
        "{% if %}x{% endif %}",
        "{% block 1bad %}{% endblock %}",
    ],
)
def test_syntax_errors(source):
    with pytest.raises(TemplateSyntaxError):
        Environment().from_string(source)


def test_endblock_name_must_match():
    with pytest.raises(TemplateSyntaxError):
        Environment().from_string("{% block a %}x{% endblock b %}")


def test_error_has_line_number():
    with pytest.raises(TemplateSyntaxError) as excinfo:
        Environment().from_string("line1\nline2\n{% if %}")
    assert excinfo.value.lineno == 3


def test_tokenize_reports_lines():
    tokens = tokenize("a\n{{ b }}\n{% if c %}{% endif %}")
    assert tokens[1].kind == "var" and tokens[1].lineno == 2
    block_tokens = [token for token in tokens if token.kind == "block"]
    assert block_tokens[0].lineno == 3


def test_filters_inside_larger_expressions():
    # A filter applies to everything on its left; comparisons bind looser.
    assert render("{% if items|length > 1 %}many{% endif %}", items=[1, 2]) == "many"
    assert render("{{ items|length > 1 }}", items=[1]) == "False"
    # Filters chain left to right.
    assert render("{{ missing|default('a')|upper }}") == "A"
    # Parenthesise when mixing with arithmetic (documented rule).
    assert render("{{ ('3'|int) + 1 }}") == "4"
    # ... and a filter can be applied to a computed value.
    assert render("{{ (1 + 2)|string }}") == "3"


def test_filter_mixed_with_arithmetic_needs_parentheses():
    with pytest.raises(TemplateRuntimeError) as excinfo:
        Environment().from_string("{{ '3'|int + 1 }}").render()
    assert "parenthes" in str(excinfo.value)


def test_filter_inside_function_call():
    assert render("{{ max(1, items|length) }}", items=[1, 2, 3]) == "3"


def test_set_with_filter():
    assert render("{% set n = '3'|int %}{{ n + 1 }}") == "4"


# -- loaders -----------------------------------------------------------------
def test_filesystem_loader_reads_templates():
    env = Environment(loader=FileSystemLoader(TEMPLATE_DIR))
    output = env.get_template("index.html").render(
        title="Hello",
        user={"name": "Ada"},
        visits=3,
        items=["a", "b"],
        url_for=lambda endpoint, **values: f"/{endpoint}",
        site_version="0.1.0",
    )
    assert "<h1>Hello</h1>" in output
    assert "Welcome, Ada" in output
    assert "2 items in total" in output
    assert "Built with MyFramework" in output  # from base.html


def test_filesystem_loader_adds_extension():
    env = Environment(loader=FileSystemLoader(TEMPLATE_DIR))
    assert env.get_template("index").name == "index"


def test_template_not_found_message_lists_paths():
    env = Environment(loader=FileSystemLoader(TEMPLATE_DIR))
    with pytest.raises(TemplateNotFound) as excinfo:
        env.get_template("does-not-exist.html")
    assert "does-not-exist.html" in str(excinfo.value)


@pytest.mark.parametrize(
    "name",
    ["../secret.txt", "/etc/passwd", "sub/../../escape.html", "..\\windows.txt", "a//b"],
)
def test_loader_blocks_path_traversal(name):
    env = Environment(loader=FileSystemLoader(TEMPLATE_DIR))
    with pytest.raises((SecurityError, TemplateNotFound)):
        env.get_template(name)


def test_loader_blocks_symlink_escape(tmp_path):
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "secret.html").write_text("secret", encoding="utf-8")
    templates = tmp_path / "templates"
    templates.mkdir()
    os.symlink(outside / "secret.html", templates / "link.html")

    env = Environment(loader=FileSystemLoader(str(templates)))
    with pytest.raises(SecurityError):
        env.get_template("link.html")


def test_loader_caches_templates():
    env = Environment(loader=DictLoader({"a.html": "one"}))
    first = env.get_template("a.html")
    assert env.get_template("a.html") is first


def test_auto_reload_picks_up_changes(tmp_path):
    path = tmp_path / "page.html"
    path.write_text("first", encoding="utf-8")
    env = Environment(loader=FileSystemLoader(str(tmp_path)), auto_reload=True)
    assert env.get_template("page.html").render() == "first"

    path.write_text("second", encoding="utf-8")
    os.utime(path, (os.path.getmtime(path) + 1, os.path.getmtime(path) + 1))
    assert env.get_template("page.html").render() == "second"


def test_list_templates():
    env = Environment(loader=DictLoader({"b.html": "", "a.html": ""}))
    assert env.list_templates() == ["a.html", "b.html"]


def test_select_template():
    env = Environment(loader=DictLoader({"b.html": "B"}))
    assert env.select_template(["a.html", "b.html"]).render() == "B"


def test_render_string_helper_from_package():
    from myframework import render_template_string

    assert render_template_string("{{ 1 + 1 }}") == "2"


def test_environment_rejects_bad_undefined_mode():
    with pytest.raises(ValueError):
        Environment(undefined="whatever")


def test_template_repr_and_attributes():
    template = Environment().from_string("x", name="virtual.html")
    assert "virtual.html" in repr(template)
    assert template.name == "virtual.html"
