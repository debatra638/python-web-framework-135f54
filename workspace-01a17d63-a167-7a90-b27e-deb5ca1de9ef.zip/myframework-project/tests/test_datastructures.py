"""Tests for MultiDict, Headers and FileStorage."""

from __future__ import annotations

import io

import pytest
from myframework.datastructures import FileStorage, Headers, MultiDict
from myframework.utils import (
    dump_cookie,
    http_date,
    parse_cookie,
    parse_http_date,
    parse_options_header,
)


# -- MultiDict ---------------------------------------------------------------
def test_multidict_first_value_and_getlist():
    md = MultiDict([("a", "1"), ("b", "2"), ("a", "3")])
    assert md["a"] == "1"
    assert md.getlist("a") == ["1", "3"]
    assert md.to_dict() == {"a": "1", "b": "2"}
    assert md.to_dict(flat=False) == {"a": ["1", "3"], "b": ["2"]}


def test_multidict_mapping_protocol():
    md = MultiDict({"a": "1"})
    md["b"] = "2"
    md.add("b", "3")
    assert len(md) == 2
    assert "b" in md
    assert list(md) == ["a", "b"]
    md.setlist("b", ["x"])
    assert md.getlist("b") == ["x"]
    del md["b"]
    assert "b" not in md
    with pytest.raises(KeyError):
        del md["b"]
    with pytest.raises(KeyError):
        _ = md["missing"]


def test_multidict_items_multi():
    md = MultiDict([("a", "1"), ("a", "2")])
    assert list(md.items()) == [("a", "1")]
    assert list(md.items(multi=True)) == [("a", "1"), ("a", "2")]
    assert list(md.lists()) == [("a", ["1", "2"])]


def test_multidict_copy_and_equality():
    md = MultiDict([("a", "1")])
    clone = md.copy()
    clone.add("b", "2")
    assert md == MultiDict({"a": "1"})
    assert md == {"a": "1"}
    assert clone.getlist("b") == ["2"]


def test_multidict_none_values_become_empty_string():
    md = MultiDict()
    md.add("a", None)
    assert md["a"] == ""


def test_multidict_repr():
    assert "MultiDict" in repr(MultiDict({"a": "1"}))


# -- Headers -----------------------------------------------------------------
def test_headers_case_insensitive():
    headers = Headers({"Content-Type": "text/html"})
    assert headers["content-type"] == "text/html"
    assert "CONTENT-TYPE" in headers
    headers["X-Test"] = "1"
    headers.add("X-Test", "2")
    assert headers.getlist("x-test") == ["1", "2"]
    headers.set("X-Test", "3")
    assert headers.getlist("X-Test") == ["3"]


def test_headers_iteration_preserves_casing_of_first_set():
    headers = Headers([("X-Custom-Header", "a")])
    assert list(headers) == ["X-Custom-Header"]


def test_headers_mapping_protocol():
    headers = Headers()
    headers["A"] = "1"
    assert len(headers) == 1
    del headers["a"]
    assert len(headers) == 0
    with pytest.raises(KeyError):
        del headers["a"]
    with pytest.raises(KeyError):
        _ = headers["a"]


def test_headers_to_wsgi_list():
    headers = Headers({"A": "1"})
    assert headers.to_wsgi_list() == [("A", "1")]


def test_headers_copy_and_repr():
    headers = Headers({"A": "1"})
    clone = Headers(headers)
    clone["B"] = "2"
    assert "B" not in headers
    assert "Headers" in repr(headers)


# -- FileStorage -------------------------------------------------------------
def test_filestorage_helpers():
    storage = FileStorage(
        io.BytesIO(b"payload"), filename="a.txt", name="file", content_type="text/plain"
    )
    assert storage.content_length == 7
    assert storage.data == b"payload"
    assert storage.read(3) == b"pay"
    assert "a.txt" in repr(storage)


def test_filestorage_save_to_file(tmp_path):
    storage = FileStorage(io.BytesIO(b"payload"), filename="a.txt")
    target = tmp_path / "saved.txt"
    storage.save(str(target))
    assert target.read_bytes() == b"payload"


def test_filestorage_save_to_stream():
    storage = FileStorage(io.BytesIO(b"payload"), filename="a.txt")
    buffer = io.BytesIO()
    storage.save(buffer)
    assert buffer.getvalue() == b"payload"


# -- utils -------------------------------------------------------------------
def test_dump_cookie_flags():
    header = dump_cookie("a", "b", max_age=10, secure=True, httponly=True, samesite="Strict")
    assert "a=b" in header
    assert "Max-Age=10" in header
    assert "Secure" in header
    assert "HttpOnly" in header
    assert "SameSite=Strict" in header
    assert "Path=/" in header


def test_dump_cookie_rejects_invalid_names():
    with pytest.raises(ValueError):
        dump_cookie("bad name", "x")
    with pytest.raises(ValueError):
        dump_cookie("", "x")


def test_dump_cookie_samesite_none_needs_secure():
    with pytest.raises(ValueError):
        dump_cookie("a", "b", samesite="None")
    assert "Secure" in dump_cookie("a", "b", samesite="None", secure=True)


def test_parse_cookie_roundtrip():
    # A request Cookie header only contains name=value pairs (attributes such
    # as Path/SameSite belong to Set-Cookie responses).
    assert parse_cookie("a=b; session=abc123") == {"a": "b", "session": "abc123"}


def test_parse_cookie_quoted_values():
    assert parse_cookie('a="b c"; d=e') == {"a": "b c", "d": "e"}


def test_parse_options_header():
    main, options = parse_options_header('multipart/form-data; boundary="abc"; charset=utf-8')
    assert main == "multipart/form-data"
    assert options == {"boundary": "abc", "charset": "utf-8"}
    assert parse_options_header(None) == ("", {})


def test_http_date_roundtrip():
    stamp = 1_700_000_000
    header = http_date(stamp)
    assert parse_http_date(header) == stamp
    assert parse_http_date("not a date") is None
    assert parse_http_date(None) is None
