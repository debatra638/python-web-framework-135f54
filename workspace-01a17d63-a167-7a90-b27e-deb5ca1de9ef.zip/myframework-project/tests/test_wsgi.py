"""Tests for PEP 3333 compliance and the WSGI integration."""

from __future__ import annotations

import threading
import time
import urllib.error
import urllib.request
from socketserver import ThreadingMixIn
from wsgiref.simple_server import WSGIServer, make_server

import pytest
from myframework import App, Response
from myframework.wsgi import (
    WSGIContractError,
    make_environ,
    middleware_chain,
    validate_headers,
    validate_response,
    validate_status,
    wsgi_application,
)


def build_app() -> App:
    """A purpose-built WSGI test application (independent of the fixture)."""
    app = App(__name__, TESTING=True, PROPAGATE_EXCEPTIONS=False)

    @app.route("/")
    def index():
        return "<h1>wsgi</h1>"

    @app.route("/json")
    def json_view():
        return {"ok": True}

    @app.route("/echo", methods=["POST"])
    def echo():
        from myframework import request

        return Response(
            request.data, content_type=request.content_type or "application/octet-stream"
        )

    @app.route("/stream")
    def stream():
        def generate():
            yield from (b"a", b"b", b"c")

        return Response(generate(), mimetype="text/plain")

    return app


def test_callable_signature_and_response_contract(wsgi_app, wsgi_call):
    status, headers, body = wsgi_call(wsgi_app, "/")
    assert status.startswith("200 ")
    assert isinstance(headers, list)
    assert all(isinstance(item, tuple) and len(item) == 2 for item in headers)
    assert all(isinstance(value, str) for _name, value in headers)
    assert isinstance(body, bytes)


def test_status_line_format(wsgi_app, wsgi_call):
    status, _headers, _body = wsgi_call(wsgi_app, "/missing")
    validate_status(status)
    code, reason = status.split(" ", 1)
    assert code == "404"
    assert reason == "NOT FOUND"


def test_headers_have_no_newlines(wsgi_app, wsgi_call):
    _status, headers, _body = wsgi_call(wsgi_app, "/")
    validate_headers(headers)
    for name, value in headers:
        assert "\n" not in name and "\n" not in value


def test_body_chunks_are_bytes(wsgi_app, wsgi_call):
    _status, _headers, body = wsgi_call(wsgi_app, "/stream")
    assert body == b"abc"


def test_response_start_response_is_called_once(wsgi_app, wsgi_call):
    calls = []

    def start_response(status, headers, exc_info=None):
        calls.append(status)
        return lambda data: None

    result = wsgi_app(make_environ(path="/"), start_response)
    list(result)
    assert calls == ["200 OK"]


def test_app_does_not_read_wsgi_input_for_get(wsgi_app, wsgi_call):
    status, _headers, body = wsgi_call(wsgi_app, "/", body=b"")
    assert status == "200 OK"
    assert body == b"<h1>wsgi</h1>"


def test_environ_is_not_mutated_destructively(wsgi_app):
    environ = make_environ(path="/")
    original_keys = set(environ)
    wsgi_app(environ, lambda *args: lambda data: None)
    assert set(environ) >= original_keys


def test_wsgi_application_helper(wsgi_app):
    assert wsgi_application(wsgi_app) is not None
    with pytest.raises(TypeError):
        wsgi_application(object())


def test_middleware_chain_order(wsgi_app, wsgi_call):
    trace = []

    def outer(inner):
        def wrapper(environ, start_response):
            trace.append("outer-in")
            result = list(inner(environ, start_response))
            trace.append("outer-out")
            return iter(result)

        return wrapper

    def inner_factory(app_inner):
        def wrapper(environ, start_response):
            trace.append("inner-in")
            result = list(app_inner(environ, start_response))
            trace.append("inner-out")
            return iter(result)

        return wrapper

    chained = middleware_chain(wsgi_app, outer, inner_factory)
    status, _headers, body = wsgi_call(chained)
    assert status == "200 OK"
    assert trace == ["outer-in", "inner-in", "inner-out", "outer-out"]


def test_validate_status_rejects_bad_values():
    for bad in ["200", "OK", "2000 OK", 200, "200 "]:
        with pytest.raises(WSGIContractError):
            validate_status(bad)


def test_validate_headers_rejects_bad_values():
    with pytest.raises(WSGIContractError):
        validate_headers([("X", 1)])
    with pytest.raises(WSGIContractError):
        validate_headers({"X": "1"})
    with pytest.raises(WSGIContractError):
        validate_headers([("X", "a\nb")])
    with pytest.raises(WSGIContractError):
        validate_headers([("X",)])


def test_validate_response_rejects_str_body():
    with pytest.raises(WSGIContractError):
        validate_response("200 OK", [], ["not bytes"])


def test_make_environ_encoding():
    environ = make_environ(path="/caf\u00e9", query_string="a=1", body=b"x")
    assert environ["PATH_INFO"].encode("latin-1").decode("utf-8") == "/caf\u00e9"
    assert environ["CONTENT_LENGTH"] == "1"
    assert environ["HTTP_HOST"] == "localhost"


def test_make_environ_custom_headers():
    environ = make_environ(headers={"X-Test": "1", "Content-Type": "application/json"})
    assert environ["HTTP_X_TEST"] == "1"
    assert environ["CONTENT_TYPE"] == "application/json"


def test_post_body_roundtrip_through_wsgi(wsgi_app, wsgi_call):
    status, _headers, body = wsgi_call(
        wsgi_app,
        "/echo",
        method="POST",
        body=b"payload",
        headers=[("Content-Type", "text/plain")],
    )
    assert status == "200 OK"
    assert body == b"payload"


def test_close_is_called_on_response_iterable():
    closed = {"called": False}

    class Body:
        def __iter__(self):
            yield b"chunk"

        def close(self):
            closed["called"] = True

    response = Response(Body(), direct_passthrough=True)
    result = response.wsgi(make_environ(), lambda *a: lambda d: None)
    assert list(result) == [b"chunk"]
    result.close()  # type: ignore[attr-defined]
    assert closed["called"] is True


@pytest.fixture
def wsgi_app() -> App:
    return build_app()


@pytest.fixture
def http_server(wsgi_app: App):
    """A real threaded wsgiref server running the test app."""
    app = wsgi_app

    class Threaded(ThreadingMixIn, WSGIServer):
        daemon_threads = True

    httpd = make_server("127.0.0.1", 0, app, server_class=Threaded)
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    host, port = httpd.server_address[:2]
    try:
        yield f"http://{host}:{port}"
    finally:
        httpd.shutdown()
        httpd.server_close()
        thread.join(timeout=5)


@pytest.mark.slow
def test_real_http_server_serves_app(http_server):
    with urllib.request.urlopen(http_server + "/", timeout=5) as response:
        assert response.status == 200
        assert response.read() == b"<h1>wsgi</h1>"
        assert response.headers["Content-Type"] == "text/html; charset=utf-8"


@pytest.mark.slow
def test_real_http_server_404(http_server):
    with pytest.raises(urllib.error.HTTPError) as excinfo:
        urllib.request.urlopen(http_server + "/missing", timeout=5)
    assert excinfo.value.code == 404


@pytest.mark.slow
def test_real_http_server_post(http_server):
    request_object = urllib.request.Request(
        http_server + "/echo",
        data=b"hello server",
        headers={"Content-Type": "text/plain"},
        method="POST",
    )
    with urllib.request.urlopen(request_object, timeout=5) as response:
        assert response.read() == b"hello server"


@pytest.mark.slow
def test_real_http_server_streaming(http_server):
    with urllib.request.urlopen(http_server + "/stream", timeout=5) as response:
        assert response.read() == b"abc"


@pytest.mark.slow
def test_server_handles_concurrent_requests(http_server):
    results: list[int] = []

    def fetch() -> None:
        with urllib.request.urlopen(http_server + "/json", timeout=10) as response:
            results.append(response.status)

    threads = [threading.Thread(target=fetch) for _ in range(5)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=10)
    assert results == [200] * 5
    time.sleep(0.01)
