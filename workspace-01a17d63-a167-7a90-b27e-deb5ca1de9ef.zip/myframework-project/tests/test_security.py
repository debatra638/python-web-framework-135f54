"""Security-focused tests: escaping, traversal, limits, headers, malformed input."""

from __future__ import annotations

import pytest
from myframework import App, Response
from myframework.exceptions import BadRequest
from myframework.utils import escape


def build_app(**overrides) -> App:
    settings = {"TESTING": True, "PROPAGATE_EXCEPTIONS": False}
    settings.update(overrides)
    app = App(__name__, **settings)

    @app.route("/echo/<value>")
    def echo(value: str):
        return app.render_template_string("<p>{{ value }}</p>", value=value)

    @app.route("/header-echo")
    def header_echo():
        from myframework import request

        return Response("ok", headers={"X-Echo": request.args.get("v", "none")})

    @app.route("/form", methods=["POST"])
    def form():
        from myframework import request

        return {"name": request.form.get("name")}

    return app


# -- escaping ---------------------------------------------------------------
def test_escape_helper():
    assert escape("<b>") == "&lt;b&gt;"
    assert escape(None) == ""
    assert escape("'") == "&#39;"
    assert escape('"') == "&#34;"
    assert escape("&") == "&amp;"


def test_xss_in_path_parameter_is_escaped():
    app = build_app()
    # NOTE: an encoded slash (%2F) becomes a real separator on every WSGI
    # server, so the payload here has no slash and is fully escaped instead.
    response = app.test_client().get("/echo/%3Cscript%3Ealert(1)")
    assert response.status_code == 200
    assert "<script>" not in response.text
    assert "&lt;script&gt;" in response.text


def test_error_page_escapes_description():
    app = build_app()

    @app.route("/abort")
    def abort_view():
        from myframework import abort

        abort(400, "<img src=x onerror=alert(1)>")

    response = app.test_client().get("/abort")
    assert "<img" not in response.text
    assert "&lt;img" in response.text


def test_404_page_does_not_reflect_user_input():
    app = build_app()
    response = app.test_client().get("/<script>alert(1)</script>")
    assert "<script>alert(1)</script>" not in response.text


def test_header_value_is_not_injectable():
    app = build_app()
    response = app.test_client().get("/header-echo", query_string={"v": "x"})
    assert response.headers["X-Echo"] == "x"


# -- request limits ---------------------------------------------------------
def test_request_size_limit():
    app = build_app(MAX_CONTENT_LENGTH=1024)

    @app.route("/upload", methods=["POST"])
    def upload():
        from myframework import request

        return {"length": len(request.data)}

    client = app.test_client()
    assert client.post("/upload", data=b"x" * 1024).status_code == 200
    assert client.post("/upload", data=b"x" * 1025).status_code == 413


def test_json_body_limit():
    app = build_app(MAX_CONTENT_LENGTH=50)

    @app.route("/json", methods=["POST"])
    def json_view():
        from myframework import request

        return {"ok": request.get_json(silent=True) is not None}

    response = app.test_client().post("/json", json={"data": "x" * 500})
    assert response.status_code == 413


# -- malformed input --------------------------------------------------------
def test_malformed_json_returns_400():
    app = build_app()

    @app.route("/json", methods=["POST"])
    def json_view():
        from myframework import request

        return {"value": request.get_json()}

    response = app.test_client().post(
        "/json", data=b"{broken", headers={"Content-Type": "application/json"}
    )
    assert response.status_code == 400
    assert "JSON" in response.text


def test_wrong_content_type_for_json_returns_415():
    app = build_app()

    @app.route("/json", methods=["POST"])
    def json_view():
        from myframework import request

        return {"value": request.get_json()}

    response = app.test_client().post("/json", data=b"{}", content_type="text/plain")
    assert response.status_code == 415


def test_invalid_content_length_returns_400():
    from myframework import Request
    from myframework.wsgi import make_environ

    environ = make_environ(path="/", method="POST")
    environ["CONTENT_LENGTH"] = "abc"
    request = Request(environ)
    with pytest.raises(BadRequest):
        request.get_data()


def test_multipart_without_boundary_returns_400():
    app = build_app()

    @app.route("/upload", methods=["POST"])
    def upload():
        from myframework import request

        return {"fields": len(request.form)}

    response = app.test_client().post(
        "/upload", data=b"x", headers={"Content-Type": "multipart/form-data"}
    )
    assert response.status_code == 400


def test_unicode_path_does_not_crash():
    app = build_app()
    response = app.test_client().get("/echo/caf%C3%A9")
    assert response.status_code == 200
    assert "café" in response.text


# -- error output -----------------------------------------------------------
def test_production_error_page_is_generic():
    app = build_app()

    @app.route("/boom")
    def boom():
        raise ValueError("internal detail: password=hunter2")

    response = app.test_client().get("/boom")
    assert response.status_code == 500
    assert "hunter2" not in response.text
    assert "Traceback" not in response.text
    assert "X-Debug-Mode" not in response.headers


def test_debug_page_never_enabled_by_default():
    assert build_app().config["DEBUG"] is False


# -- cookies ----------------------------------------------------------------
def test_cookie_defaults_and_flags():
    app = build_app()

    @app.route("/set")
    def set_cookie():
        response = Response("ok")
        response.set_cookie("session_id", "abc123", httponly=True, secure=True, samesite="Lax")
        return response

    response = app.test_client().get("/set")
    cookie = response.headers.getlist("Set-Cookie")[0]
    assert "HttpOnly" in cookie
    assert "Secure" in cookie
    assert "SameSite=Lax" in cookie
    assert "Path=/" in cookie


def test_client_sends_cookies_back():
    app = build_app()

    @app.route("/set")
    def set_cookie():
        response = Response("ok")
        response.set_cookie("theme", "dark")
        return response

    @app.route("/read")
    def read_cookie():
        from myframework import request

        return {"theme": request.cookies.get("theme")}

    client = app.test_client()
    client.get("/set")
    assert client.get("/read").json == {"theme": "dark"}


def test_hostile_cookie_does_not_break_request():
    app = build_app()
    response = app.test_client().get("/echo/x", headers={"Cookie": "broken; =; a=b"})
    assert response.status_code == 200


# -- response headers -------------------------------------------------------
def test_no_sniffing_header_by_default():
    app = build_app()
    assert app.test_client().get("/echo/a").headers["X-Content-Type-Options"] == "nosniff"


def test_security_headers_are_opt_in_via_middleware():
    app = build_app()
    response = app.test_client().get("/echo/a")
    assert "Content-Security-Policy" not in response.headers


def test_json_responses_are_not_html_sniffable():
    app = build_app()

    @app.route("/api")
    def api():
        return {"a": 1}

    response = app.test_client().get("/api")
    assert response.mimetype == "application/json"
    assert response.headers["X-Content-Type-Options"] == "nosniff"


# -- template sandbox -------------------------------------------------------
def test_template_cannot_reach_dunders():
    app = build_app()
    with pytest.raises(Exception) as excinfo:
        app.render_template_string("{{ ''.__class__.__mro__ }}")
    assert "private" in str(excinfo.value).lower()


def test_template_globals_do_not_include_dangerous_builtins():
    env = build_app().template_env
    for name in ("eval", "exec", "open", "compile", "__import__", "globals"):
        assert name not in env.globals
