"""Tests for the HTTP request object (parsing of the WSGI environ)."""

from __future__ import annotations

import io

import pytest
from myframework import Request
from myframework.exceptions import BadRequest, PayloadTooLarge, UnsupportedMediaType
from myframework.wsgi import make_environ


def make_request(**kwargs) -> Request:
    headers = kwargs.pop("headers", None)
    body = kwargs.pop("body", b"")
    environ = make_environ(headers=headers, body=body, **kwargs)
    return Request(environ)


def test_basic_properties():
    request = make_request(
        path="/hello",
        query_string="a=1&b=2",
        headers=[("Host", "example.com"), ("User-Agent", "pytest")],
    )
    assert request.method == "GET"
    assert request.path == "/hello"
    assert request.query_string == b"a=1&b=2"
    assert request.full_path == "/hello?a=1&b=2"
    assert request.args["a"] == "1"
    assert request.headers["user-agent"] == "pytest"
    assert request.host == "example.com"
    assert request.url == "http://example.com/hello?a=1&b=2"
    assert request.base_url == "http://example.com/hello"
    assert request.scheme == "http"
    assert not request.is_secure


def test_utf8_path_is_decoded():
    request = make_request(path="/caf\u00e9")
    assert request.path == "/caf\u00e9"
    assert request.environ["PATH_INFO"].encode("latin-1").decode("utf-8") == "/caf\u00e9"


def test_utf8_query_string():
    request = make_request(path="/", query_string="q=caf%C3%A9")
    assert request.args["q"] == "caf\u00e9"


def test_multi_value_args():
    request = make_request(path="/", query_string="a=1&a=2&b=")
    assert request.args["a"] == "1"
    assert request.args.getlist("a") == ["1", "2"]
    assert request.args["b"] == ""
    assert request.args.to_dict() == {"a": "1", "b": ""}
    assert request.args.to_dict(flat=False) == {"a": ["1", "2"], "b": [""]}


def test_content_length_and_type():
    request = make_request(
        path="/",
        method="POST",
        body=b"hello",
        headers=[("Content-Type", "text/plain; charset=utf-8")],
    )
    assert request.content_length == 5
    assert request.content_type == "text/plain; charset=utf-8"
    assert request.mimetype == "text/plain"
    assert request.get_data() == b"hello"
    assert request.get_data(as_text=True) == "hello"
    assert request.data == b"hello"


def test_invalid_content_length_raises_bad_request():
    environ = make_environ(path="/", method="POST")
    environ["CONTENT_LENGTH"] = "not-a-number"
    request = Request(environ)
    with pytest.raises(BadRequest):
        request.get_data()


def test_json_body():
    request = make_request(
        path="/",
        method="POST",
        headers=[("Content-Type", "application/json")],
        body=b'{"a": [1, 2], "b": null}',
    )
    assert request.is_json
    assert request.json == {"a": [1, 2], "b": None}
    assert request.get_json() == {"a": [1, 2], "b": None}


def test_json_invalid_raises():
    request = make_request(
        path="/",
        method="POST",
        headers=[("Content-Type", "application/json")],
        body=b"{oops",
    )
    with pytest.raises(BadRequest):
        request.get_json()
    assert request.get_json(silent=True) is None


def test_json_requires_content_type():
    request = make_request(path="/", method="POST", body=b'{"a": 1}')
    with pytest.raises(UnsupportedMediaType):
        request.get_json()
    assert request.get_json(force=True) == {"a": 1}


def test_empty_json_body_is_none():
    request = make_request(
        path="/", method="POST", headers=[("Content-Type", "application/json")], body=b""
    )
    assert request.json is None


def test_vendor_json_content_type():
    request = make_request(
        path="/",
        method="POST",
        headers=[("Content-Type", "application/vnd.api+json")],
        body=b'{"data": 1}',
    )
    assert request.is_json
    assert request.json == {"data": 1}


def test_urlencoded_form():
    request = make_request(
        path="/",
        method="POST",
        headers=[("Content-Type", "application/x-www-form-urlencoded")],
        body=b"name=Ada+Lovelace&tag=a&tag=b",
    )
    assert request.form["name"] == "Ada Lovelace"
    assert request.form.getlist("tag") == ["a", "b"]
    assert request.values["name"] == "Ada Lovelace"


def test_multipart_form_and_file_upload():
    boundary = "xyz123"
    body = (
        f"--{boundary}\r\n"
        'Content-Disposition: form-data; name="title"\r\n\r\n'
        "My upload\r\n"
        f"--{boundary}\r\n"
        'Content-Disposition: form-data; name="document"; filename="notes.txt"\r\n'
        "Content-Type: text/plain\r\n\r\n"
        "file contents\r\n"
        f"--{boundary}--\r\n"
    ).encode()
    request = make_request(
        path="/upload",
        method="POST",
        headers=[("Content-Type", f"multipart/form-data; boundary={boundary}")],
        body=body,
    )
    assert request.form["title"] == "My upload"
    upload = request.files["document"]
    assert upload.filename == "notes.txt"
    assert upload.content_type == "text/plain"
    assert upload.data == b"file contents"
    assert upload.content_length == len(b"file contents")


def test_multipart_without_boundary_is_bad_request():
    request = make_request(
        path="/upload",
        method="POST",
        headers=[("Content-Type", "multipart/form-data")],
        body=b"whatever",
    )
    with pytest.raises(BadRequest):
        request.form


def test_form_ignored_for_get():
    request = make_request(path="/", method="GET", body=b"a=1")
    assert request.form.to_dict() == {}


def test_max_content_length_blocks_large_body():
    request = Request(
        make_environ(path="/", method="POST", body=b"x" * 100),
        max_content_length=10,
    )
    with pytest.raises(PayloadTooLarge):
        request.get_data()


def test_max_content_length_without_content_length():
    environ = make_environ(path="/", method="POST", body=b"x" * 100)
    environ["CONTENT_LENGTH"] = ""
    environ["wsgi.input"] = io.BytesIO(b"x" * 100)
    request = Request(environ, max_content_length=10)
    with pytest.raises(PayloadTooLarge):
        request.get_data()


def test_cookies_are_parsed():
    request = make_request(path="/", headers=[("Cookie", "a=1; b=two")])
    assert request.cookies == {"a": "1", "b": "two"}


def test_malformed_cookie_does_not_crash():
    request = make_request(path="/", headers=[("Cookie", "=broken; ok=1")])
    assert request.cookies.get("ok") == "1"


def test_remote_addr_and_headers():
    request = make_request(path="/", remote_addr="203.0.113.7")
    assert request.remote_addr == "203.0.113.7"
    assert "Host" in request.headers
    assert request.get_header("Host") is not None
    assert request.get_header("X-Missing", "fallback") == "fallback"


def test_get_param_lookup_order():
    request = make_request(
        path="/",
        method="POST",
        query_string="shared=query&only_query=1",
        headers=[("Content-Type", "application/x-www-form-urlencoded")],
        body=b"shared=form&only_form=2",
    )
    assert request.get_param("shared") == "query"
    assert request.get_param("only_form") == "2"
    assert request.get_param("missing", "default") == "default"


def test_iter_pairs_and_urlencoded_form():
    request = make_request(path="/", query_string="a=1&b=2")
    assert list(request.iter_pairs()) == [("a", "1"), ("b", "2")]
    assert request.urlencoded_form() == "a=1&b=2"


def test_to_dict_summary():
    request = make_request(path="/x", query_string="a=1")
    summary = request.to_dict()
    assert summary["method"] == "GET"
    assert summary["path"] == "/x"
    assert summary["query_string"] == "a=1"


def test_from_environ_classmethod():
    request = Request.from_environ(make_environ(path="/x"))
    assert request.path == "/x"


def test_repr():
    assert repr(make_request(path="/abc")) == "<Request GET '/abc'>"
