"""Tests for :mod:`myframework.routing` — rules, converters, matching, building."""

from __future__ import annotations

import uuid

import pytest
from myframework.exceptions import MethodNotAllowed, NotFound, RequestRedirect, RoutingError
from myframework.routing import (
    AnyConverter,
    BaseConverter,
    ConverterRegistry,
    Map,
    Rule,
    StringConverter,
    parse_rule,
)


def simple_map(*rules, **kwargs):
    url_map = Map()
    for rule, endpoint, methods in rules:
        url_map.add(rule, endpoint, methods=methods)
    return url_map


# ---------------------------------------------------------------------------
# rule parsing
# ---------------------------------------------------------------------------


def test_parse_static_rule():
    parts = parse_rule("/about", ConverterRegistry())
    assert parts == [("literal", "/about")]


def test_parse_dynamic_rule():
    parts = parse_rule("/users/<username>", ConverterRegistry())
    assert parts[0] == ("literal", "/users/")
    assert parts[1][0] == "dynamic"
    assert parts[1][1] == "username"
    assert isinstance(parts[1][2], StringConverter)


def test_parse_converter_with_argument():
    parts = parse_rule("/<any(a, b):page>", ConverterRegistry())
    assert parts[0] == ("literal", "/")
    dynamic = parts[1]
    assert isinstance(dynamic[2], AnyConverter)
    assert list(dynamic[2].args) == ["a", "b"]


@pytest.mark.parametrize(
    "rule",
    ["", "no-slash", "/users/<username", "/users/username>", "/<unknown:x>", "/<int:>"],
)
def test_invalid_rules_rejected(rule):
    url_map = Map()
    with pytest.raises(RoutingError):
        url_map.add(rule, "endpoint")


def test_duplicate_rule_rejected():
    url_map = Map()
    url_map.add("/x", "a")
    with pytest.raises(RoutingError):
        url_map.add("/x", "a")
    # Same rule, different endpoint is fine (two views on one URL).
    url_map.add("/x", "b")


def test_query_string_in_rule_rejected():
    with pytest.raises(RoutingError):
        Map().add("/x?y=1", "endpoint")


def test_non_string_rule_rejected():
    with pytest.raises(RoutingError):
        Map().add(42, "endpoint")  # type: ignore[arg-type]


def test_invalid_method_rejected():
    with pytest.raises(RoutingError):
        Map().add("/x", "endpoint", methods=["FETCH"])


def test_methods_are_normalised_and_head_implied():
    url_map = Map()
    rule = url_map.add("/x", "endpoint", methods=["get"])
    assert rule.methods == frozenset({"GET", "HEAD"})
    assert "OPTIONS" in rule.allowed_methods


# ---------------------------------------------------------------------------
# matching
# ---------------------------------------------------------------------------


def test_static_rule_matches():
    url_map = simple_map(("/about", "about", None))
    result = url_map.match("/about")
    assert result.rule is not None
    assert result.rule.endpoint == "about"
    assert result.arguments == {}


def test_unknown_path_does_not_match():
    url_map = simple_map(("/about", "about", None))
    result = url_map.match("/nope")
    assert result.rule is None
    assert result.redirect_path is None


def test_string_converter_rejects_slashes():
    url_map = simple_map(("/users/<username>", "user", None))
    assert url_map.match("/users/ada").arguments == {"username": "ada"}
    assert url_map.match("/users/a/b").rule is None


def test_path_converter_accepts_slashes():
    url_map = simple_map(("/files/<path:filename>", "files", None))
    assert url_map.match("/files/a/b/c.txt").arguments == {"filename": "a/b/c.txt"}


def test_integer_converter_casts():
    url_map = simple_map(("/n/<int:value>", "number", None))
    arguments = url_map.match("/n/42").arguments
    assert arguments == {"value": 42}
    assert isinstance(arguments["value"], int)
    assert url_map.match("/n/4.2").rule is None
    assert url_map.match("/n/-1").rule is None


def test_float_converter_casts():
    url_map = simple_map(("/f/<float:value>", "floaty", None))
    assert url_map.match("/f/1.5").arguments == {"value": 1.5}
    assert url_map.match("/f/1").rule is None


def test_uuid_converter_casts():
    url_map = simple_map(("/u/<uuid:identifier>", "uuid", None))
    value = uuid.uuid4()
    assert url_map.match(f"/u/{value}").arguments == {"identifier": value}
    assert url_map.match("/u/not-a-uuid").rule is None


def test_any_converter_restricts_values():
    url_map = simple_map(("/<any(one, two):page>", "page", None))
    assert url_map.match("/one").arguments == {"page": "one"}
    assert url_map.match("/three").rule is None


def test_specific_rule_wins_over_converter():
    url_map = Map()
    url_map.add("/users/<username>", "user")
    url_map.add("/users/me", "me")
    assert url_map.match("/users/me").rule.endpoint == "me"
    assert url_map.match("/users/ada").rule.endpoint == "user"


def test_more_literal_characters_win():
    url_map = Map()
    url_map.add("/a/<x>", "short")
    url_map.add("/a/b/<x>", "long")
    assert url_map.match("/a/b/c").rule.endpoint == "long"


def test_registration_order_breaks_ties():
    url_map = Map()
    url_map.add("/<x>/one", "first")
    url_map.add("/<x>/two", "second")
    assert url_map.match("/z/one").rule.endpoint == "first"


def test_method_not_allowed_reports_all_methods():
    url_map = Map()
    url_map.add("/x", "get_view", methods=["GET"])
    url_map.add("/x", "post_view", methods=["POST"])
    url_map.add("/x", "put_view", methods=["PUT"])
    result = url_map.match("/x", "DELETE")
    assert result.rule is None
    assert result.allowed_methods == frozenset({"GET", "HEAD", "OPTIONS", "POST", "PUT"})


def test_options_is_always_allowed():
    url_map = simple_map(("/x", "view", ["GET"]))
    assert url_map.match("/x", "OPTIONS").rule is not None


def test_head_uses_the_get_view():
    url_map = simple_map(("/x", "view", ["GET"]))
    result = url_map.match("/x", "HEAD")
    assert result.rule is not None
    assert result.rule.endpoint == "view"


def test_method_matching_is_case_insensitive():
    url_map = simple_map(("/x", "view", ["POST"]))
    assert url_map.match("/x", "post").rule is not None


def test_trailing_slash_redirect_is_reported():
    url_map = simple_map(("/about/", "about", None))
    result = url_map.match("/about")
    assert result.rule is None
    assert result.redirect_path == "/about/"


def test_extra_trailing_slash_redirects_back():
    url_map = simple_map(("/about", "about", None))
    result = url_map.match("/about/")
    assert result.redirect_path == "/about"


def test_strict_slashes_false_matches_both():
    url_map = Map()
    url_map.add("/thing/", "thing", strict_slashes=False)
    assert url_map.match("/thing/").rule is not None
    assert url_map.match("/thing").rule is not None
    assert url_map.match("/thing").redirect_path is None


def test_root_path_matches_exactly():
    url_map = simple_map(("/", "index", None))
    assert url_map.match("/").rule is not None
    assert url_map.match("").rule is None


def test_unicode_paths_match():
    url_map = simple_map(("/grüße/<name>", "greet", None))
    assert url_map.match("/grüße/ada").arguments == {"name": "ada"}


def test_regex_special_characters_are_literal():
    url_map = simple_map(("/a.b/(x)+", "weird", None))
    assert url_map.match("/a.b/(x)+").rule is not None
    assert url_map.match("/axb/xx").rule is None


def test_defaults_are_merged_into_arguments():
    url_map = Map()
    url_map.add("/list", "list_items", defaults={"page": 1})
    assert url_map.match("/list").arguments == {"page": 1}


def test_resolve_raises_typed_errors():
    url_map = simple_map(("/x", "view", ["GET"]), ("/about/", "about", None))
    with pytest.raises(NotFound):
        url_map.resolve("/nope")
    with pytest.raises(MethodNotAllowed) as info:
        url_map.resolve("/x", "POST")
    assert "GET" in info.value.valid_methods
    with pytest.raises(RequestRedirect) as info:
        url_map.resolve("/about")
    assert info.value.new_url == "/about/"


# ---------------------------------------------------------------------------
# building
# ---------------------------------------------------------------------------


def test_build_static_and_dynamic_urls():
    url_map = Map()
    url_map.add("/", "index")
    url_map.add("/users/<username>", "user")
    url_map.add("/n/<int:value>", "number")
    assert url_map.build("index") == "/"
    assert url_map.build("user", {"username": "ada"}) == "/users/ada"
    assert url_map.build("number", {"value": 7}) == "/n/7"


def test_build_percent_encodes_values():
    url_map = Map()
    url_map.add("/users/<path:username>", "user")
    assert url_map.build("user", {"username": "a b/c"}) == "/users/a%20b/c"


def test_build_appends_unknown_values_as_query_string():
    url_map = Map()
    url_map.add("/search", "search")
    built = url_map.build("search", {"q": "café", "page": 2})
    assert built.startswith("/search?")
    assert "q=caf%C3%A9" in built
    assert "page=2" in built


def test_build_can_drop_unknown_values():
    url_map = Map()
    url_map.add("/search", "search")
    assert url_map.build("search", {"q": "x"}, append_unknown=False) == "/search"


def test_build_missing_value_raises():
    url_map = Map()
    url_map.add("/users/<username>", "user")
    with pytest.raises(RoutingError):
        url_map.build("user", {})


def test_build_unknown_endpoint_raises_with_hint():
    url_map = simple_map(("/x", "known", None))
    with pytest.raises(RoutingError) as info:
        url_map.build("nope")
    assert "known" in str(info.value)


def test_build_only_rules_are_not_matched():
    url_map = Map()
    url_map.add("/only-built", "build_only", build_only=True)
    assert url_map.match("/only-built").rule is None
    assert url_map.build("build_only") == "/only-built"


def test_build_picks_a_rule_that_fits():
    url_map = Map()
    url_map.add("/users/<username>", "user")
    url_map.add("/users/<int:user_id>", "user")
    assert url_map.build("user", {"user_id": 5}) == "/users/5"
    assert url_map.build("user", {"username": "ada"}) == "/users/ada"


def test_map_iteration_and_length():
    url_map = simple_map(("/a", "a", None), ("/b", "b", None))
    assert len(url_map) == 2
    assert [rule.endpoint for rule in url_map] == ["a", "b"]


def test_rule_repr_and_converter_repr():
    url_map = simple_map(("/x/<int:n>", "view", None))
    rule = next(iter(url_map))
    assert "view" in repr(rule)
    assert "IntegerConverter" in repr(rule._converter_for("n"))
    assert isinstance(rule, Rule)


# ---------------------------------------------------------------------------
# custom converters
# ---------------------------------------------------------------------------


class HexConverter(BaseConverter):
    regex = "[0-9a-f]+"

    def to_python(self, value: str) -> int:
        return int(value, 16)

    def to_url(self, value: object) -> str:
        return format(int(value), "x")  # type: ignore[arg-type]


def test_custom_converter_roundtrip():
    registry = ConverterRegistry()
    registry.register("hex", HexConverter)
    url_map = Map(registry)
    url_map.add("/<hex:value>", "hex")
    assert url_map.match("/ff").arguments == {"value": 255}
    assert url_map.build("hex", {"value": 255}) == "/ff"


def test_registering_the_same_converter_twice_is_fine():
    registry = ConverterRegistry()
    registry.register("hex", HexConverter)
    registry.register("hex", HexConverter)
    assert "hex" in registry
    assert "missing" not in registry
    assert len(list(registry.copy())) == len(list(registry))


def test_unknown_converter_name_in_rule():
    with pytest.raises(RoutingError) as info:
        Map().add("/<nope:x>", "endpoint")
    assert "nope" in str(info.value)


def test_any_converter_requires_arguments():
    with pytest.raises(RoutingError):
        Map().add("/<any():x>", "endpoint")
