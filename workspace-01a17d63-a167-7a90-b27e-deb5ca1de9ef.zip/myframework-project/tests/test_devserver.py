"""Integration tests for the development server (real HTTP, real process)."""

from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request

import pytest
from myframework.devserver import Reloader

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def wait_for_port(port: int, timeout: float = 20.0) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.5):
                return
        except OSError:
            time.sleep(0.05)
    raise AssertionError(f"Server did not start on port {port}")


def write_app(directory: str) -> None:
    with open(os.path.join(directory, "dev_app.py"), "w", encoding="utf-8") as handle:
        handle.write(
            "from myframework import App, request\n"
            "app = App(__name__)\n"
            "@app.route('/')\n"
            "def index():\n"
            "    return '<h1>dev</h1>'\n"
            "@app.route('/echo', methods=['POST'])\n"
            "def echo():\n"
            "    return {'body': request.get_data(as_text=True)}\n"
            "@app.route('/slow')\n"
            "def slow():\n"
            "    import time; time.sleep(0.2)\n"
            "    return 'slow'\n"
        )


@pytest.fixture
def dev_server(tmp_path):
    write_app(str(tmp_path))
    port = free_port()
    env = dict(os.environ)
    env["PYTHONPATH"] = REPO_ROOT
    env["MYFRAMEWORK_NO_RELOADER"] = "1"
    process = subprocess.Popen(
        [
            sys.executable,
            "-m",
            "myframework.cli",
            "run",
            "--app",
            "dev_app:app",
            "--port",
            str(port),
            "--debug",
        ],
        cwd=str(tmp_path),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    try:
        wait_for_port(port)
        yield f"http://127.0.0.1:{port}"
    finally:
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:  # pragma: no cover
            process.kill()
            process.wait(timeout=5)


@pytest.mark.slow
def test_dev_server_serves_requests(dev_server):
    with urllib.request.urlopen(dev_server + "/", timeout=10) as response:
        assert response.status == 200
        assert response.read() == b"<h1>dev</h1>"


@pytest.mark.slow
def test_dev_server_handles_post(dev_server):
    request = urllib.request.Request(
        dev_server + "/echo",
        data=b"hello",
        headers={"Content-Type": "text/plain"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=10) as response:
        payload = json.loads(response.read())
    assert payload == {"body": "hello"}


@pytest.mark.slow
def test_dev_server_is_threaded(dev_server):
    """Two concurrent requests to a slow endpoint must overlap."""
    import threading

    results: list[float] = []

    def fetch() -> None:
        started = time.perf_counter()
        with urllib.request.urlopen(dev_server + "/slow", timeout=10) as response:
            response.read()
        results.append(time.perf_counter() - started)

    threads = [threading.Thread(target=fetch) for _ in range(4)]
    started = time.perf_counter()
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=20)
    total = time.perf_counter() - started
    assert len(results) == 4
    # Serial handling of 4 x 0.2s would take >= 0.8s; threaded stays well below.
    assert total < 0.75


@pytest.mark.slow
def test_dev_server_404(dev_server):
    with pytest.raises(urllib.error.HTTPError) as excinfo:
        urllib.request.urlopen(dev_server + "/missing", timeout=10)
    assert excinfo.value.code == 404


@pytest.mark.slow
def test_dev_server_debug_traceback(dev_server, tmp_path):
    # The app has no /error route; hitting an unhandled path proves 404 works.
    with pytest.raises(urllib.error.HTTPError):
        urllib.request.urlopen(dev_server + "/nope", timeout=10)


def test_reloader_detects_changes(tmp_path):
    watched = tmp_path / "module.py"
    watched.write_text("x = 1", encoding="utf-8")
    reloader = Reloader([str(tmp_path)], interval=0.05)
    baseline = reloader._snapshot()
    watched.write_text("x = 2", encoding="utf-8")
    os.utime(watched, (time.time() + 1, time.time() + 1))
    assert reloader._snapshot() != baseline
    # Do not call start(): it would execv the test process.
    reloader.stop()


def test_reloader_ignores_unrelated_files(tmp_path):
    (tmp_path / "notes.md").write_text("hello", encoding="utf-8")
    reloader = Reloader([str(tmp_path)])
    baseline = reloader._snapshot()
    (tmp_path / "notes.md").write_text("changed", encoding="utf-8")
    os.utime(tmp_path / "notes.md", (time.time() + 1, time.time() + 1))
    assert reloader._snapshot() == baseline


# ---------------------------------------------------------------------------
# unit tests for the pieces (no process, no sockets)
# ---------------------------------------------------------------------------


def test_banner_lists_routes():
    from myframework import App
    from myframework.devserver import _banner

    app = App(__name__, TESTING=True, static_dir=False)

    @app.route("/thing/<int:value>", methods=["GET", "POST"])
    def thing(value: int):
        return str(value)

    banner = _banner(app, "127.0.0.1", 8123, debug=True, reload=True)
    assert "MyFramework development server" in banner
    assert "http://127.0.0.1:8123/" in banner
    assert "/thing/<int:value>" in banner
    assert "GET,HEAD,POST" in banner
    assert "Debug:    on" in banner
    assert "Not for production" in banner


def test_request_handler_is_quiet_when_asked(capsys):
    from myframework.devserver import DevServerRequestHandler

    class Quiet(DevServerRequestHandler):
        quiet = True

    handler = Quiet.__new__(Quiet)
    handler.quiet = True
    handler.address_string = lambda: "127.0.0.1"  # type: ignore[method-assign]
    handler.log_message('"GET / HTTP/1.1" %s', "200")
    handler.log_error("something %s", "bad")
    assert capsys.readouterr().err == ""


def test_request_handler_logs_when_not_quiet(capsys):
    from myframework.devserver import DevServerRequestHandler

    handler = DevServerRequestHandler.__new__(DevServerRequestHandler)
    handler.quiet = False
    handler.address_string = lambda: "127.0.0.1"  # type: ignore[method-assign]
    handler.log_message('"GET / HTTP/1.1" %s', "200")
    assert "GET / HTTP/1.1" in capsys.readouterr().err


def test_run_dev_server_reports_bind_errors(monkeypatch, tmp_path):
    from myframework import App
    from myframework.devserver import run_dev_server

    app = App(__name__, TESTING=True, static_dir=False)

    def failing_make_server(*args, **kwargs):
        raise OSError(98, "Address already in use")

    monkeypatch.setattr("myframework.devserver.make_server", failing_make_server)
    with pytest.raises(SystemExit) as info:
        run_dev_server(app, host="127.0.0.1", port=8000, quiet=True)
    assert "Cannot bind" in str(info.value)


def test_run_dev_server_serves_and_stops(monkeypatch):
    """Run the real server in a thread, make one request, then shut it down."""
    import threading
    import urllib.request

    from myframework import App
    from myframework.devserver import run_dev_server

    app = App(__name__, TESTING=True, static_dir=False)

    @app.route("/ping")
    def ping():
        return {"pong": True}

    port = free_port()
    thread = threading.Thread(
        target=run_dev_server,
        args=(app, "127.0.0.1", port, False, False),
        kwargs={"quiet": True},
        daemon=True,
    )
    thread.start()
    try:
        wait_for_port(port)
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/ping", timeout=10) as response:
            assert json.loads(response.read()) == {"pong": True}
            assert response.headers["X-Content-Type-Options"] == "nosniff"
    finally:
        thread.join(timeout=5)


def test_run_dev_server_starts_reloader_unless_disabled(monkeypatch, tmp_path):
    from myframework import App
    from myframework.devserver import run_dev_server

    started: list[object] = []

    class FakeReloader:
        def __init__(self, roots, interval=0.6):
            started.append(roots)

        def start(self):
            started.append("started")

        def stop(self):
            started.append("stopped")

    monkeypatch.setattr("myframework.devserver.Reloader", FakeReloader)

    def fake_make_server(*args, **kwargs):
        raise OSError("stop here")

    monkeypatch.setattr("myframework.devserver.make_server", fake_make_server)
    app = App(__name__, TESTING=True, static_dir=False)

    monkeypatch.delenv("MYFRAMEWORK_NO_RELOADER", raising=False)
    with pytest.raises(SystemExit):
        run_dev_server(app, port=8001, reload=True, quiet=True)
    assert "started" in started

    started.clear()
    monkeypatch.setenv("MYFRAMEWORK_NO_RELOADER", "1")
    with pytest.raises(SystemExit):
        run_dev_server(app, port=8001, reload=True, quiet=True)
    assert started == []


def test_reloader_start_and_stop(tmp_path, monkeypatch):
    from myframework.devserver import Reloader

    reloader = Reloader([str(tmp_path)], interval=0.05)
    monkeypatch.setattr(reloader, "_restart", lambda: None)
    reloader.start()
    assert reloader._thread is not None and reloader._thread.is_alive()
    reloader.stop()
    assert not reloader._thread.is_alive()


def test_reloader_restart_uses_execv(monkeypatch):
    from myframework.devserver import Reloader

    calls = []
    monkeypatch.setattr("os.execv", lambda path, argv: calls.append((path, argv)))
    Reloader._restart()
    assert calls and calls[0][1][0] == sys.executable
