"""Tests for the configuration system."""

from __future__ import annotations

import json
import sys

import pytest
from myframework import App, Config
from myframework.config import DEFAULTS, ConfigAttribute, load_config
from myframework.exceptions import ConfigurationError


def test_defaults_are_present():
    config = Config()
    assert config["DEBUG"] is False
    assert config["MAX_CONTENT_LENGTH"] == 16 * 1024 * 1024
    assert config["STATIC_URL_PATH"] == "/static"


def test_attribute_access():
    config = Config()
    assert config.DEBUG is False
    config.DEBUG = True
    assert config["DEBUG"] is True
    with pytest.raises(AttributeError) as excinfo:
        _ = config.NOT_A_KEY
    assert "UNKNOWN" not in str(excinfo.value)


def test_unknown_key_error_lists_valid_keys():
    with pytest.raises(KeyError) as excinfo:
        Config()["NOPE"]
    assert "Known keys" in str(excinfo.value)


def test_update_and_from_mapping():
    config = Config()
    changed = config.from_mapping({"debug": True}, EXTRA="x")
    assert config["DEBUG"] is True
    assert config["EXTRA"] == "x"
    assert set(changed) == {"DEBUG", "EXTRA"}


def test_from_env_coercion(monkeypatch):
    monkeypatch.setenv("MYFRAMEWORK_DEBUG", "1")
    monkeypatch.setenv("MYFRAMEWORK_MAX_CONTENT_LENGTH", "1024")
    monkeypatch.setenv("MYFRAMEWORK_SECRET_KEY", "abc")
    config = Config()
    config.from_env("MYFRAMEWORK_")
    assert config["DEBUG"] is True
    assert config["MAX_CONTENT_LENGTH"] == 1024
    assert config["SECRET_KEY"] == "abc"


def test_from_env_rejects_bad_boolean():
    config = Config()
    with pytest.raises(ConfigurationError):
        config.from_env(environ={"MYFRAMEWORK_DEBUG": "maybe"})


def test_from_env_rejects_bad_integer():
    config = Config()
    with pytest.raises(ConfigurationError):
        config.from_env(environ={"MYFRAMEWORK_MAX_CONTENT_LENGTH": "lots"})


def test_from_env_custom_prefix():
    config = Config()
    config.from_env("APP_", environ={"APP_DEBUG": "yes", "OTHER_DEBUG": "no"})
    assert config["DEBUG"] is True


def test_from_json_file(tmp_path):
    path = tmp_path / "config.json"
    path.write_text(json.dumps({"DEBUG": True, "MAX_CONTENT_LENGTH": 2048}), encoding="utf-8")
    config = Config()
    config.from_file(path)
    assert config["DEBUG"] is True
    assert config["MAX_CONTENT_LENGTH"] == 2048


def test_from_json_invalid(tmp_path):
    path = tmp_path / "config.json"
    path.write_text("{not json", encoding="utf-8")
    with pytest.raises(ConfigurationError):
        Config().from_file(path)


def test_from_toml_file(tmp_path):
    if sys.version_info < (3, 11):
        pytest.skip("tomllib requires Python 3.11+")
    path = tmp_path / "config.toml"
    path.write_text("[myframework]\nDEBUG = true\nMAX_CONTENT_LENGTH = 4096\n", encoding="utf-8")
    config = Config()
    config.from_file(path)
    assert config["DEBUG"] is True
    assert config["MAX_CONTENT_LENGTH"] == 4096


def test_from_file_missing(tmp_path):
    with pytest.raises(ConfigurationError):
        Config().from_file(tmp_path / "missing.json")


def test_from_file_unsupported_extension(tmp_path):
    path = tmp_path / "config.ini"
    path.write_text("x", encoding="utf-8")
    with pytest.raises(ConfigurationError):
        Config().from_file(path)


def test_from_object_module(tmp_path, monkeypatch):
    module_path = tmp_path / "settings.py"
    module_path.write_text("DEBUG = True\nSECRET_KEY = 'from-module'\nlower = 'ignored'\n")
    monkeypatch.syspath_prepend(str(tmp_path))
    try:
        config = Config()
        config.from_object("settings")
        assert config["DEBUG"] is True
        assert config["SECRET_KEY"] == "from-module"
        assert "LOWER" not in config
    finally:
        sys.modules.pop("settings", None)


def test_load_config_precedence(tmp_path):
    path = tmp_path / "config.json"
    path.write_text(json.dumps({"DEBUG": False, "SECRET_KEY": "file"}), encoding="utf-8")
    config = load_config(
        overrides={"SECRET_KEY": "override"},
        env_prefix="TESTENV_",
        file=path,
    )
    assert config["DEBUG"] is False
    assert config["SECRET_KEY"] == "override"


def test_copy_is_independent():
    original = Config()
    clone = original.copy()
    clone["DEBUG"] = True
    assert original["DEBUG"] is False


def test_as_dict_hides_secrets():
    config = Config(overrides={"SECRET_KEY": "top-secret"})
    dumped = config.as_dict()
    assert dumped["SECRET_KEY"] == "***"


def test_get_helpers():
    config = Config(overrides={"MAX_CONTENT_LENGTH": "not-an-int"})
    assert config.get_bool("DEBUG") is False
    assert config.get_list("TRUSTED_HOSTS") == []
    with pytest.raises(ConfigurationError):
        config.get_int("MAX_CONTENT_LENGTH")


def test_config_attribute_descriptor():
    class Holder:
        config = Config()

        debug = ConfigAttribute("DEBUG")

    holder = Holder()
    assert holder.debug is False
    holder.debug = True
    assert holder.config["DEBUG"] is True


def test_repr_masks_secrets():
    config = Config(overrides={"SECRET_KEY": "shhh"})
    assert "shhh" not in repr(config)


def test_app_config_overrides():
    app = App(__name__, config={"DEBUG": True}, MAX_CONTENT_LENGTH=123)
    assert app.config["DEBUG"] is True
    assert app.config["MAX_CONTENT_LENGTH"] == 123
    assert app.debug is True


def test_app_resolves_default_directories():
    app = App(__name__)
    assert app.config["STATIC_DIR"].endswith("static")
    assert app.config["TEMPLATE_DIR"].endswith("templates")


def test_all_defaults_stay_in_sync():
    config = Config()
    assert set(DEFAULTS) <= set(config)
