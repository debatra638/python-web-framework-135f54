"""Tests for the ``myframework`` CLI."""

from __future__ import annotations

import os
import subprocess
import sys

import pytest
from myframework.cli import build_parser, load_app, main


def run_cli(*args: str, cwd: str | None = None) -> subprocess.CompletedProcess[str]:
    """Run the CLI in a subprocess (isolates sys.modules and sys.path)."""
    env = dict(os.environ)
    env["PYTHONPATH"] = os.pathsep.join(
        [os.path.dirname(os.path.dirname(os.path.abspath(__file__))), env.get("PYTHONPATH", "")]
    )
    return subprocess.run(
        [sys.executable, "-m", "myframework.cli", *args],
        capture_output=True,
        text=True,
        cwd=cwd,
        env=env,
        timeout=60,
    )


def test_version_command():
    result = run_cli("version")
    assert result.returncode == 0
    assert "myframework" in result.stdout


def test_help_lists_commands():
    result = run_cli("--help")
    assert result.returncode == 0
    for command in ("run", "routes", "new", "version"):
        assert command in result.stdout


def test_run_help_documents_flags():
    result = run_cli("run", "--help")
    assert result.returncode == 0
    assert "--host" in result.stdout
    assert "--port" in result.stdout
    assert "--debug" in result.stdout


def test_routes_command(tmp_path):
    (tmp_path / "demo_app.py").write_text(
        "from myframework import App\n"
        "app = App(__name__)\n"
        "@app.route('/')\n"
        "def index():\n"
        "    return 'hi'\n"
        "@app.route('/items/<int:item_id>', methods=['GET', 'POST'])\n"
        "def item(item_id):\n"
        "    return 'x'\n",
        encoding="utf-8",
    )
    result = run_cli("routes", "--app", "demo_app:app", cwd=str(tmp_path))
    assert result.returncode == 0, result.stderr
    assert "/items/<int:item_id>" in result.stdout
    assert "END" in result.stdout.upper()


def test_routes_command_missing_app(tmp_path):
    result = run_cli("routes", "--app", "nope_module:app", cwd=str(tmp_path))
    assert result.returncode != 0
    assert "Could not import" in result.stderr


def test_routes_command_without_spec(tmp_path):
    result = run_cli("routes", cwd=str(tmp_path))
    assert result.returncode != 0
    assert "No application found" in result.stderr


def test_new_scaffolds_project(tmp_path):
    target = tmp_path / "mysite"
    result = run_cli("new", str(target))
    assert result.returncode == 0, result.stderr
    for relative in (
        "app.py",
        "templates/base.html",
        "templates/index.html",
        "static/style.css",
        "tests/test_app.py",
        "pyproject.toml",
        "README.md",
    ):
        assert (target / relative).is_file(), relative
    assert "MyFramework" in (target / "app.py").read_text(encoding="utf-8")


def test_new_refuses_non_empty_directory(tmp_path):
    target = tmp_path / "existing"
    target.mkdir()
    (target / "keep.txt").write_text("x", encoding="utf-8")
    result = run_cli("new", str(target))
    assert result.returncode != 0
    assert "not empty" in result.stderr


def test_generated_project_imports_and_runs(tmp_path):
    target = tmp_path / "site2"
    assert run_cli("new", str(target)).returncode == 0
    script = f"""
import sys
sys.path.insert(0, {str(target)!r})
from app import app

client = app.test_client()
assert client.get("/").status_code == 200, client.get("/").text
assert client.get("/hello/ada").json == {{"message": "Hello, ada!"}}
print("OK")
"""
    env = dict(os.environ)
    env["PYTHONPATH"] = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    result = subprocess.run(
        [sys.executable, "-c", script], capture_output=True, text=True, env=env, timeout=60
    )
    assert result.returncode == 0, result.stderr
    assert "OK" in result.stdout


def test_parser_defaults():
    parser = build_parser()
    args = parser.parse_args(["run"])
    assert args.host == "127.0.0.1"
    assert args.port == 8000
    assert args.debug is False
    assert args.func.__name__ == "cmd_run"


def test_load_app_from_environment(tmp_path, monkeypatch):
    (tmp_path / "env_app.py").write_text(
        "from myframework import App\napp = App(__name__)\n", encoding="utf-8"
    )
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("MYFRAMEWORK_APP", "env_app:app")
    monkeypatch.syspath_prepend(str(tmp_path))
    app = load_app()
    assert app is not None
    assert hasattr(app, "route")


def test_main_version(capsys):
    assert main(["version"]) == 0
    captured = capsys.readouterr()
    assert "myframework" in captured.out


# ---------------------------------------------------------------------------
# in-process tests (faster and cover the branches subprocess tests miss)
# ---------------------------------------------------------------------------


def _write_app(directory, name="app_mod.py", body=None):
    body = body or (
        "from myframework import App\n"
        "app = App(__name__)\n"
        "@app.route('/')\n"
        "def index():\n"
        "    return 'ok'\n"
    )
    (directory / name).write_text(body, encoding="utf-8")


def test_import_path_module_colon_attribute(tmp_path, monkeypatch):
    from myframework.cli import _import_path

    _write_app(tmp_path)
    monkeypatch.syspath_prepend(str(tmp_path))
    app = _import_path("app_mod:app")
    assert hasattr(app, "route")


def test_import_path_dotted_attribute(tmp_path, monkeypatch):
    from myframework.cli import _import_path

    _write_app(tmp_path)
    monkeypatch.syspath_prepend(str(tmp_path))
    app = _import_path("app_mod.app")
    assert hasattr(app, "route")


def test_import_path_calls_create_app(tmp_path, monkeypatch):
    from myframework.cli import _import_path

    (tmp_path / "factory_mod.py").write_text(
        "from myframework import App\ndef create_app():\n    return App(__name__)\n",
        encoding="utf-8",
    )
    monkeypatch.syspath_prepend(str(tmp_path))
    assert hasattr(_import_path("factory_mod:create_app"), "route")


def test_import_path_finds_conventional_names(tmp_path, monkeypatch):
    from myframework.cli import _import_path

    (tmp_path / "conventional.py").write_text(
        "from myframework import App\napplication = App(__name__)\n", encoding="utf-8"
    )
    monkeypatch.syspath_prepend(str(tmp_path))
    assert hasattr(_import_path("conventional"), "route")


def test_import_path_errors_are_explained(tmp_path, monkeypatch):
    from myframework.cli import _import_path

    (tmp_path / "empty_mod.py").write_text("VALUE = 1\n", encoding="utf-8")
    monkeypatch.syspath_prepend(str(tmp_path))

    with pytest.raises(SystemExit) as info:
        _import_path("empty_mod")
    assert "does not define" in str(info.value)

    with pytest.raises(SystemExit) as info:
        _import_path("empty_mod:missing")
    assert "has no attribute" in str(info.value)

    with pytest.raises(SystemExit) as info:
        _import_path("empty_mod:")
    assert "Missing attribute" in str(info.value)

    with pytest.raises(SystemExit) as info:
        _import_path("no_such_module_anywhere")
    assert "Could not import" in str(info.value)

    with pytest.raises(SystemExit) as info:
        _import_path("empty_mod.missing")
    assert "has no attribute" in str(info.value)


def test_load_app_uses_app_py_in_cwd(tmp_path, monkeypatch):
    from myframework.cli import load_app

    _write_app(tmp_path, name="app.py")
    monkeypatch.chdir(tmp_path)
    monkeypatch.syspath_prepend(str(tmp_path))
    monkeypatch.delenv("MYFRAMEWORK_APP", raising=False)
    assert hasattr(load_app(), "route")


def test_load_app_without_anything_raises(tmp_path, monkeypatch):
    from myframework.cli import load_app

    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("MYFRAMEWORK_APP", raising=False)
    with pytest.raises(SystemExit) as info:
        load_app()
    assert "No application found" in str(info.value)


def test_cmd_routes_prints_the_map(tmp_path, monkeypatch, capsys):
    from myframework.cli import build_parser

    _write_app(tmp_path)
    monkeypatch.syspath_prepend(str(tmp_path))
    parser = build_parser()
    args = parser.parse_args(["routes", "--app", "app_mod:app"])
    assert args.func(args) == 0
    out = capsys.readouterr().out
    assert "rules)" in out
    assert "/" in out
    assert "index" in out


def test_cmd_version_prints_version(capsys):
    from myframework import __version__
    from myframework.cli import build_parser

    args = build_parser().parse_args(["version"])
    assert args.func(args) == 0
    assert __version__ in capsys.readouterr().out


def test_cmd_run_forwards_arguments(monkeypatch, tmp_path):
    from myframework import App
    from myframework.cli import build_parser, cmd_run

    app = App(__name__, TESTING=True, static_dir=False)
    monkeypatch.setattr("myframework.cli.load_app", lambda spec=None: app)
    captured = {}
    monkeypatch.setattr(
        app,
        "run",
        lambda **kwargs: captured.update(kwargs),
    )
    args = build_parser().parse_args(["run", "--port", "9001", "--debug", "--no-threads"])
    assert cmd_run(args) == 0
    assert captured["port"] == 9001
    assert captured["debug"] is True
    assert captured["threaded"] is False
    assert app.config["DEBUG"] is True


def test_cmd_run_reload_defaults_to_debug(monkeypatch):
    from myframework import App
    from myframework.cli import main

    app = App(__name__, TESTING=True, static_dir=False)
    monkeypatch.setattr("myframework.cli.load_app", lambda spec=None: app)
    captured = {}
    monkeypatch.setattr(app, "run", lambda **kwargs: captured.update(kwargs))

    assert main(["run"]) == 0
    assert captured["reload"] is False

    captured.clear()
    assert main(["run", "--debug"]) == 0
    assert captured["reload"] is True

    captured.clear()
    assert main(["run", "--no-reload"]) == 0
    assert captured["reload"] is False


def test_cmd_new_prints_next_steps(tmp_path, capsys):
    from myframework.cli import build_parser

    target = tmp_path / "site"
    args = build_parser().parse_args(["new", str(target)])
    assert args.func(args) == 0
    out = capsys.readouterr().out
    assert "Created project" in out
    assert "Next steps" in out
    assert (target / "templates" / "index.html").is_file()


def test_cmd_new_refuses_to_overwrite(tmp_path):
    from myframework.cli import build_parser

    target = tmp_path / "site"
    target.mkdir()
    (target / "app.py").write_text("custom", encoding="utf-8")
    args = build_parser().parse_args(["new", str(target)])
    with pytest.raises(SystemExit) as info:
        args.func(args)
    assert "not empty" in str(info.value)
    # Nothing was overwritten.
    assert (target / "app.py").read_text(encoding="utf-8") == "custom"


def test_parser_rejects_unknown_command(capsys):
    from myframework.cli import main

    with pytest.raises(SystemExit) as info:
        main(["nonsense"])
    assert info.value.code == 2


def test_generated_project_is_a_valid_package(tmp_path):
    """The scaffold must be installable and testable as documented."""
    from myframework.cli import build_parser

    target = tmp_path / "site"
    args = build_parser().parse_args(["new", str(target)])
    assert args.func(args) == 0

    tomllib = pytest.importorskip("tomllib")
    config = tomllib.loads((target / "pyproject.toml").read_text(encoding="utf-8"))
    assert config["build-system"]["build-backend"] == "setuptools.build_meta"
    assert config["project"]["requires-python"].startswith(">=3.1")
    assert "myframework" in " ".join(config["project"]["dependencies"])
    # `pythonpath = ["."]` is what makes a bare `pytest` find app.py.
    assert config["tool"]["pytest"]["ini_options"]["pythonpath"] == ["."]
    assert config["tool"]["setuptools"]["py-modules"] == ["app"]

    readme = (target / "README.md").read_text(encoding="utf-8")
    assert "myframework run" in readme
    assert "pytest" in readme
