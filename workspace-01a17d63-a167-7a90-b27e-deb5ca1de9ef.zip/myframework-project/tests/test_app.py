"""Integration tests for :class:`myframework.app.App` — the request lifecycle."""

from __future__ import annotations

import logging

import pytest
from myframework import (
    App,
    Response,
    abort,
    jsonify,
    redirect,
    render_template,
    request,
    url_for,
)
from myframework.exceptions import HTTPException, SecurityError


@pytest.fixture
def application() -> App:
    app = App(__name__, TESTING=True, PROPAGATE_EXCEPTIONS=False)
    app.config["MAX_CONTENT_LENGTH"] = 10_000

    @app.route("/")
    def index():
        return "<h1>home</h1>"

    @app.route("/hello/<name>")
    def hello(name: str):
        return f"<h1>Hello {name}</h1>"

    @app.route("/count/<int:value>")
    def count(value: int):
        return {"value": value}

    @app.route("/json")
    def json_route():
        return {"ok": True, "items": [1, 2, 3]}

    @app.route("/tuple")
    def tuple_route():
        return "created", 201

    @app.route("/tuple-headers")
    def tuple_headers():
        return "ok", 202, {"X-Reason": "because"}

    @app.route("/none")
    def none_route():
        return None

    @app.route("/status-object")
    def status_object():
        return Response("custom", status=418)

    @app.route("/methods", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
    def methods():
        return request.method

    @app.route("/space/<path:rest>")
    def space(rest: str):
        return {"rest": rest}

    @app.route("/echo", methods=["POST"])
    def echo():
        return jsonify(
            json=request.get_json(silent=True),
            form=request.form.to_dict(),
            raw=request.get_data(as_text=True),
            content_type=request.content_type,
        )

    @app.route("/users/me")
    def me():
        return "me"

    @app.route("/users/<username>")
    def user(username: str):
        return f"user {username}"

    @app.errorhandler(404)
    def not_found(error):
        return f"missing: {error.description}", 404

    @app.errorhandler(ValueError)
    def value_error(error):
        return {"error": str(error)}, 400

    return app


# ---------------------------------------------------------------------------
# dispatch and return values
# ---------------------------------------------------------------------------


def test_str_return_is_html(application):
    response = application.test_client().get("/")
    assert response.status_code == 200
    assert response.headers["Content-Type"] == "text/html; charset=utf-8"
    assert response.text == "<h1>home</h1>"


def test_dynamic_segments_are_converted(application):
    client = application.test_client()
    assert client.get("/hello/ada").text == "<h1>Hello ada</h1>"
    assert client.get("/count/7").json == {"value": 7}


def test_dict_return_is_json(application):
    response = application.test_client().get("/json")
    assert response.headers["Content-Type"].startswith("application/json")
    assert response.json == {"ok": True, "items": [1, 2, 3]}


def test_tuple_returns(application):
    client = application.test_client()
    created = client.get("/tuple")
    assert created.status_code == 201
    assert created.text == "created"
    with_headers = client.get("/tuple-headers")
    assert with_headers.status_code == 202
    assert with_headers.headers["X-Reason"] == "because"


def test_none_returns_empty_200(application):
    response = application.test_client().get("/none")
    assert response.status_code == 200
    assert response.data == b""


def test_response_object_passes_through(application):
    response = application.test_client().get("/status-object")
    assert response.status_code == 418
    assert response.text == "custom"


def test_path_converter_spans_slashes(application):
    assert application.test_client().get("/space/a/b/c").json == {"rest": "a/b/c"}


def test_url_decoding_happens_once(application):
    assert (
        application.test_client().get("/hello/Ada%20Lovelace").text == "<h1>Hello Ada Lovelace</h1>"
    )


def test_query_string_and_headers_are_available(application):
    @application.route("/inspect")
    def inspect_view():
        return {
            "q": request.args.get("q"),
            "all": request.args.getlist("q"),
            "header": request.headers.get("X-Test"),
        }

    response = application.test_client().get(
        "/inspect?q=1&q=2", headers={"X-Test": "value", "Host": "example.test"}
    )
    assert response.json == {"q": "1", "all": ["1", "2"], "header": "value"}


# ---------------------------------------------------------------------------
# HTTP methods
# ---------------------------------------------------------------------------


def test_all_declared_methods_work(application):
    client = application.test_client()
    for method in ("GET", "POST", "PUT", "PATCH", "DELETE"):
        response = client.open("/methods", method=method)
        assert response.status_code == 200, method
        assert response.text == method


def test_undeclared_method_returns_405_with_allow(application):
    response = application.test_client().post("/")
    assert response.status_code == 405
    assert "GET" in response.headers["Allow"]
    assert "HEAD" in response.headers["Allow"]
    assert "OPTIONS" in response.headers["Allow"]


def test_head_has_no_body_but_same_headers(application):
    client = application.test_client()
    get_response = client.get("/")
    head_response = client.head("/")
    assert head_response.status_code == 200
    assert head_response.data == b""
    assert head_response.headers["Content-Length"] == get_response.headers["Content-Length"]


def test_options_is_answered_automatically(application):
    response = application.test_client().open("/methods", method="OPTIONS")
    assert response.status_code == 204
    allow = response.headers["Allow"]
    for method in ("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"):
        assert method in allow


def test_options_can_be_overridden(application):
    @application.route("/custom-options", methods=["OPTIONS"])
    def options_view():
        return "", 200, {"Allow": "GET, OPTIONS"}

    assert application.test_client().open("/custom-options", method="OPTIONS").status_code == 200


def test_trailing_slash_redirect(application):
    @application.route("/about/")
    def about():
        return "about"

    response = application.test_client().get("/about")
    assert response.status_code == 308
    assert response.headers["Location"] == "/about/"
    followed = application.test_client().get("/about", follow_redirects=True)
    assert followed.status_code == 200
    assert followed.text == "about"


# ---------------------------------------------------------------------------
# routing precedence
# ---------------------------------------------------------------------------


def test_static_segment_beats_variable(application):
    assert application.test_client().get("/users/me").text == "me"
    assert application.test_client().get("/users/ada").text == "user ada"


def test_more_specific_route_wins(application):
    @application.route("/files/<filename>")
    def file_short(filename: str):
        return "short"

    @application.route("/files/readme/<filename>")
    def file_long(filename: str):
        return "long"

    assert application.test_client().get("/files/readme/x").text == "long"
    assert application.test_client().get("/files/x").text == "short"


def test_unknown_route_uses_custom_404(application):
    response = application.test_client().get("/nope")
    assert response.status_code == 404
    assert response.text.startswith("missing:")


# ---------------------------------------------------------------------------
# request bodies
# ---------------------------------------------------------------------------


def test_json_body(application):
    response = application.test_client().post("/echo", json={"a": 1})
    assert response.json["json"] == {"a": 1}
    assert response.json["content_type"] == "application/json"


def test_form_body(application):
    response = application.test_client().post("/echo", data={"a": "1", "b": "2"})
    assert response.json["form"] == {"a": "1", "b": "2"}


def test_raw_body(application):
    response = application.test_client().post(
        "/echo", data=b"raw bytes", content_type="application/octet-stream"
    )
    assert response.json["raw"] == "raw bytes"


def test_broken_json_is_silent_with_get_json(application):
    response = application.test_client().post(
        "/echo", data="{not json", content_type="application/json"
    )
    assert response.status_code == 200
    assert response.json["json"] is None


def test_oversized_body_is_rejected(application):
    application.config["MAX_CONTENT_LENGTH"] = 10
    response = application.test_client().post("/echo", data=b"x" * 100)
    assert response.status_code == 413


# ---------------------------------------------------------------------------
# hooks
# ---------------------------------------------------------------------------


def test_before_request_can_short_circuit(application):
    calls = []

    @application.route("/blocked")
    def blocked():
        return "should not run"

    @application.before_request
    def block():
        calls.append("before")
        if request.path == "/blocked":
            return "blocked!", 403
        return None

    client = application.test_client()
    assert client.get("/blocked").status_code == 403
    assert client.get("/").status_code == 200
    assert calls == ["before", "before"]


def test_before_request_abort(application):
    @application.before_request
    def guard():
        if request.headers.get("X-Key") != "secret":
            abort(401, "No key provided")

    response = application.test_client().get("/")
    assert response.status_code == 401
    assert "No key provided" in response.text
    assert application.test_client().get("/", headers={"X-Key": "secret"}).status_code == 200


def test_hook_order_before_and_after(application):
    events = []

    @application.before_request
    def first():
        events.append("before-1")

    @application.before_request
    def second():
        events.append("before-2")

    @application.after_request
    def after_one(response):
        events.append("after-1")
        response.headers["X-One"] = "1"
        return response

    @application.after_request
    def after_two(response):
        events.append("after-2")
        return response

    client = application.test_client()
    client.get("/")
    # before hooks run in registration order, after hooks in reverse order.
    assert events == ["before-1", "before-2", "after-2", "after-1"]


def test_after_request_mutations_are_sent(application):
    @application.after_request
    def add_header(response):
        response.headers["X-After"] = "yes"
        return response

    assert application.test_client().get("/").headers["X-After"] == "yes"


def test_after_request_must_return_a_response(application):
    @application.after_request
    def broken(response):
        return None

    response = application.test_client().get("/")
    assert response.status_code == 500


def test_teardown_runs_even_on_error(application):
    seen = []

    @application.teardown_request
    def teardown(error):
        seen.append(type(error).__name__ if error else None)

    @application.route("/explode")
    def explode():
        raise RuntimeError("boom")

    client = application.test_client()
    client.get("/")
    client.get("/explode")
    assert seen == [None, "RuntimeError"]


def test_teardown_errors_are_logged_not_raised(application, caplog):
    @application.teardown_request
    def teardown(error):
        raise ValueError("teardown failure")

    with caplog.at_level(logging.ERROR):
        response = application.test_client().get("/")
    assert response.status_code == 200
    assert "teardown" in caplog.text.lower()


def test_context_processor_values_reach_the_template(application):
    from myframework.templates import DictLoader, Environment

    application._template_env = Environment(
        loader=DictLoader({"page.html": "{{ value }} {{ injected }} {{ url_for('index') }}"})
    )

    @application.context_processor
    def inject():
        return {"injected": "from-processor"}

    @application.route("/page")
    def page():
        return render_template("page.html", value="hello")

    assert application.test_client().get("/page").text == "hello from-processor /"


# ---------------------------------------------------------------------------
# error handling
# ---------------------------------------------------------------------------


def test_exception_handler_by_class(application):
    @application.route("/value-error")
    def value_error_route():
        raise ValueError("bad value")

    response = application.test_client().get("/value-error")
    assert response.status_code == 400
    assert response.json == {"error": "bad value"}


def test_exception_handler_by_status_code(application):
    @application.route("/teapot")
    def teapot():
        abort(418, "short and stout")

    response = application.test_client().get("/teapot")
    assert response.status_code == 418
    assert "short and stout" in response.text


def test_exception_handler_inheritance(application):
    class CustomError(Exception):
        pass

    class MoreSpecific(CustomError):
        pass

    @application.errorhandler(CustomError)
    def handle_custom(error):
        return "custom handled", 502

    @application.route("/custom")
    def custom():
        raise MoreSpecific("x")

    assert application.test_client().get("/custom").status_code == 502


def test_unhandled_exception_returns_500(application):
    @application.route("/boom")
    def boom():
        raise RuntimeError("kaboom")

    response = application.test_client().get("/boom")
    assert response.status_code == 500
    assert "kaboom" not in response.text  # never leak internals outside debug


def test_http_exception_response_is_rendered(application):
    @application.route("/gone")
    def gone():
        abort(410)

    response = application.test_client().get("/gone")
    assert response.status_code == 410
    assert "410" in response.text


def test_propagate_exceptions_flag():
    app = App(__name__, TESTING=True, PROPAGATE_EXCEPTIONS=True)

    @app.route("/")
    def index():
        raise RuntimeError("visible")

    with pytest.raises(RuntimeError, match="visible"):
        app.test_client().get("/")


def test_trap_http_exceptions_flag():
    app = App(__name__, TESTING=True, PROPAGATE_EXCEPTIONS=True, TRAP_HTTP_EXCEPTIONS=True)

    @app.route("/")
    def index():
        abort(404, "nope")

    with pytest.raises(HTTPException):
        app.test_client().get("/")


def test_debug_mode_shows_traceback():
    app = App(__name__, DEBUG=True, PROPAGATE_EXCEPTIONS=True)

    @app.route("/")
    def index():
        raise RuntimeError("debug-visible")

    with pytest.raises(RuntimeError):
        app.test_client().get("/")

    app.config["PROPAGATE_EXCEPTIONS"] = False
    response = app.test_client().get("/")
    assert response.status_code == 500
    assert "debug-visible" in response.text


def test_error_handler_for_404_can_return_json(application):
    @application.errorhandler(405)
    def handle_405(error):
        return {"error": "method not allowed"}, 405

    response = application.test_client().delete("/json")
    assert response.status_code == 405
    assert response.json == {"error": "method not allowed"}


# ---------------------------------------------------------------------------
# url_for
# ---------------------------------------------------------------------------


def test_url_for_inside_a_view(application):
    @application.route("/links")
    def links():
        return {
            "static": url_for("index"),
            "dynamic": url_for("hello", name="ada"),
            "query": url_for("index", page=2),
            "external": url_for("index", _external=True),
        }

    payload = application.test_client().get("/links").json
    assert payload["static"] == "/"
    assert payload["dynamic"] == "/hello/ada"
    assert payload["query"] == "/?page=2"
    assert payload["external"].startswith("http://")


def test_url_for_unknown_endpoint(application):
    from myframework.exceptions import RoutingError

    @application.route("/bad-link")
    def bad_link():
        return url_for("does-not-exist")

    response = application.test_client().get("/bad-link")
    assert response.status_code == 500

    with application.test_request_context("/"):
        with pytest.raises(RoutingError):
            url_for("does-not-exist")


def test_url_for_respects_script_name():
    app = App(__name__, TESTING=True)

    @app.route("/")
    def index():
        return url_for("index")

    with app.test_request_context("/", environ_overrides={"SCRIPT_NAME": "/app"}):
        assert url_for("index") == "/app/"


# ---------------------------------------------------------------------------
# decorators and registration helpers
# ---------------------------------------------------------------------------


def test_route_decorators_for_each_method():
    app = App(__name__, TESTING=True)

    @app.get("/thing")
    def get_thing():
        return "get"

    @app.post("/thing")
    def post_thing():
        return "post"

    @app.put("/thing")
    def put_thing():
        return "put"

    @app.patch("/thing")
    def patch_thing():
        return "patch"

    @app.delete("/thing")
    def delete_thing():
        return "delete"

    client = app.test_client()
    assert client.get("/thing").text == "get"
    assert client.post("/thing").text == "post"
    assert client.put("/thing").text == "put"
    assert client.patch("/thing").text == "patch"
    assert client.delete("/thing").text == "delete"


def test_add_url_rule_with_explicit_endpoint():
    app = App(__name__, TESTING=True)

    def view():
        return "ok"

    app.add_url_rule("/explicit", endpoint="explicit", view_func=view)
    assert app.test_client().get("/explicit").text == "ok"


def test_add_url_rule_requires_endpoint():
    app = App(__name__, TESTING=True)
    with pytest.raises(TypeError):
        app.add_url_rule("/no-endpoint")


def test_custom_converter_registration():
    from myframework.routing import BaseConverter

    app = App(__name__, TESTING=True)

    @app.converter("hex")
    class HexConverter(BaseConverter):
        regex = "[0-9a-f]+"

        def to_python(self, value: str) -> int:
            return int(value, 16)

        def to_url(self, value) -> str:  # type: ignore[no-untyped-def]
            return format(int(value), "x")

    @app.route("/<hex:value>")
    def hex_view(value: int):
        return {"value": value}

    client = app.test_client()
    assert client.get("/ff").json == {"value": 255}
    with app.test_request_context("/"):
        assert url_for("hex_view", value=255) == "/ff"


def test_methods_must_be_a_list_or_string(application):
    from myframework.exceptions import RoutingError

    with pytest.raises((TypeError, RoutingError)):
        application.route("/x", methods=42)  # type: ignore[arg-type]


def test_routes_with_the_same_rule_need_different_endpoints(application):
    def same():
        return "same"

    application.add_url_rule("/same", endpoint="same", view_func=same)
    with pytest.raises(Exception):
        application.add_url_rule("/same", endpoint="same", view_func=same)


# ---------------------------------------------------------------------------
# app attributes and configuration
# ---------------------------------------------------------------------------


def test_app_metadata():
    app = App(__name__, TESTING=True)
    assert app.name == __name__
    assert app.import_name == __name__
    assert app.root_path
    assert isinstance(repr(app), str)
    assert "App" in repr(app)


def test_config_attributes_are_typed():
    app = App(__name__, TESTING=True)
    assert app.config["TESTING"] is True
    assert app.testing is True
    app.debug = True
    assert app.config["DEBUG"] is True


def test_unknown_config_attribute_raises():
    app = App(__name__, TESTING=True)
    with pytest.raises(AttributeError):
        _ = app.not_a_setting


def test_invalid_config_value_is_rejected():
    with pytest.raises(Exception):
        App(__name__, MAX_CONTENT_LENGTH="not a number")


def test_app_has_a_logger(application, caplog):
    with caplog.at_level(logging.INFO):
        application.logger.info("hello logs")
    assert "hello logs" in caplog.text


def test_describe_lists_routes(application):
    description = application.describe()
    assert "/hello/<name>" in description
    assert "hello" in description


def test_static_files_are_served_from_the_configured_directory(tmp_path):
    (tmp_path / "hello.txt").write_text("static content", encoding="utf-8")
    app = App(__name__, TESTING=True, static_dir=str(tmp_path))
    response = app.test_client().get("/static/hello.txt")
    assert response.status_code == 200
    assert response.text == "static content"


def test_static_route_can_be_disabled():
    app = App(__name__, TESTING=True, static_dir=False)
    assert "static" not in [rule.endpoint for rule in app.url_map]
    assert app.config["STATIC_DIR"] is None


def test_static_url_path_is_configurable(tmp_path):
    (tmp_path / "a.txt").write_text("a", encoding="utf-8")
    app = App(__name__, TESTING=True, static_dir=str(tmp_path), STATIC_URL_PATH="/assets")
    assert app.test_client().get("/assets/a.txt").text == "a"
    assert app.test_client().get("/static/a.txt").status_code == 404


def test_static_traversal_is_blocked(tmp_path):
    (tmp_path / "public.txt").write_text("ok", encoding="utf-8")
    (tmp_path.parent / "secret.txt").write_text("secret", encoding="utf-8")
    app = App(__name__, TESTING=True, static_dir=str(tmp_path))
    for path in (
        "/static/../secret.txt",
        "/static/%2e%2e/secret.txt",
        "/static/..%2fsecret.txt",
        "/static/subdir/../../secret.txt",
    ):
        response = app.test_client().get(path)
        assert response.status_code in (400, 403, 404), path
        assert b"secret" not in response.data


def test_static_handler_rejects_null_bytes(tmp_path):
    (tmp_path / "file.txt").write_text("x", encoding="utf-8")
    app = App(__name__, TESTING=True, static_dir=str(tmp_path))
    with pytest.raises(SecurityError):
        app.static_files.handle("file\x00.txt", {})


# ---------------------------------------------------------------------------
# templates
# ---------------------------------------------------------------------------


def test_render_template_without_directory_raises():
    app = App(__name__, TESTING=True)
    with app.app_context():
        from myframework.exceptions import TemplateNotFound

        with pytest.raises(TemplateNotFound):
            render_template("missing.html")


def test_render_template_string_inside_view(application):
    @application.route("/inline")
    def inline():
        return application.render_template_string("hi {{ name }}", name="ada")

    assert application.test_client().get("/inline").text == "hi ada"


def test_template_globals_and_filters(application):
    from myframework.templates import DictLoader, Environment

    application._template_env = Environment(
        loader=DictLoader({"t.html": "{{ shout('ada') }}|{{ 'x'|twice }}"})
    )

    @application.template_global("shout")
    def shout(value):
        return value.upper()

    @application.template_filter("twice")
    def twice(value):
        return value * 2

    @application.route("/globals")
    def globals_route():
        return render_template("t.html")

    assert application.test_client().get("/globals").text == "ADA|xx"


# ---------------------------------------------------------------------------
# WSGI plumbing
# ---------------------------------------------------------------------------


def test_app_is_a_wsgi_callable(application):
    captured = {}

    def start_response(status, headers, exc_info=None):
        captured["status"] = status
        captured["headers"] = headers
        return lambda data: None

    from myframework.wsgi import make_environ

    body = b"".join(application(make_environ(path="/"), start_response))
    assert captured["status"] == "200 OK"
    assert body == b"<h1>home</h1>"
    assert dict(captured["headers"])["Content-Type"] == "text/html; charset=utf-8"


def test_wsgi_app_property_is_reused(application):
    assert application.wsgi_app is application.wsgi_app


def test_use_rebuilds_the_pipeline(application):
    from myframework.middleware import HeaderMiddleware

    application.use(HeaderMiddleware(headers={"X-Added": "1"}))
    assert application.test_client().get("/").headers["X-Added"] == "1"


def test_preferred_host_is_enforced():
    app = App(__name__, TESTING=True, PREFERRED_HOST="example.com")

    @app.route("/")
    def index():
        return "ok"

    assert app.test_client().get("/", headers={"Host": "example.com"}).status_code == 200
    assert app.test_client().get("/", headers={"Host": "evil.test"}).status_code == 400


def test_run_arguments_are_forwarded(monkeypatch):
    app = App(__name__, TESTING=True)
    captured = {}

    def fake_run(app_obj, host, port, **kwargs):
        captured.update({"host": host, "port": port, **kwargs})

    monkeypatch.setattr("myframework.devserver.run_dev_server", fake_run)
    app.run(host="1.2.3.4", port=1234, debug=True, reload=False)
    assert captured["host"] == "1.2.3.4"
    assert captured["port"] == 1234
    assert captured["debug"] is True


# ---------------------------------------------------------------------------
# test helpers
# ---------------------------------------------------------------------------


def test_test_request_context(application):
    with application.test_request_context("/hello/ada?x=1", method="GET"):
        assert request.path == "/hello/ada"
        assert request.args["x"] == "1"
        assert request.method == "GET"


def test_make_response_conversion_table(application):
    with application.test_request_context("/"):
        rv = application.make_response("text")
        assert isinstance(rv, Response)
        assert application.make_response({"a": 1}).is_json
        assert application.make_response(("x", 204)).status_code == 204
        assert application.make_response(Response("y")).text == "y"
        with pytest.raises(TypeError):
            application.make_response(object())


def test_wsgi_callable_return_value_is_wrapped(application):
    def raw(environ, start_response):
        start_response("200 OK", [("Content-Type", "text/plain")])
        return [b"raw-wsgi"]

    @application.route("/raw")
    def raw_view():
        return raw

    response = application.test_client().get("/raw")
    assert response.text == "raw-wsgi"
    assert response.headers["Content-Type"] == "text/plain"


def test_streaming_view(application):
    @application.route("/stream")
    def stream():
        def generate():
            yield from (b"one ", b"two ", b"three")

        from myframework import stream_response

        return stream_response(generate())

    response = application.test_client().get("/stream")
    assert response.data == b"one two three"
    assert "Content-Length" not in response.headers


def test_app_context_is_available_without_request():
    app = App(__name__, TESTING=True, TEMPLATE_DIR=None)

    with app.app_context():
        from myframework import current_app

        assert current_app.name == __name__


def test_request_body_is_only_read_once(application):
    @application.route("/twice", methods=["POST"])
    def twice():
        first = request.get_data()
        second = request.get_data()
        return {"same": first == second, "length": len(first)}

    response = application.test_client().post("/twice", data=b"payload")
    assert response.json == {"same": True, "length": 7}


def test_multipart_upload(application):
    @application.route("/upload", methods=["POST"])
    def upload():
        file = request.files.get("doc")
        assert file is not None
        return {
            "name": file.filename,
            "content": file.read().decode(),
            "form": request.form.get("title"),
        }

    response = application.test_client().post(
        "/upload",
        files={"doc": ("notes.txt", b"file body")},
        form={"title": "Title"},
    )
    assert response.json == {"name": "notes.txt", "content": "file body", "form": "Title"}


def test_request_with_no_content_type_has_empty_form(application):
    response = application.test_client().post("/echo", data=b"raw")
    assert response.json["form"] == {}


def test_json_body_is_cached(application):
    @application.route("/cached", methods=["POST"])
    def cached():
        return {"first": request.get_json(), "second": request.get_json()}

    payload = application.test_client().post("/cached", json={"a": 1}).json
    assert payload["first"] == payload["second"] == {"a": 1}


def test_redirect_view(application):
    @application.route("/go")
    def go():
        return redirect("/")

    response = application.test_client().get("/go")
    assert response.status_code == 302
    assert response.headers["Location"] == "/"


def test_cookies_roundtrip_through_the_client(application):
    @application.route("/set")
    def set_cookie():
        response = Response("set")
        response.set_cookie("token", "abc", httponly=True)
        return response

    @application.route("/read")
    def read_cookie():
        return {"token": request.cookies.get("token")}

    client = application.test_client()
    client.get("/set")
    assert client.get("/read").json == {"token": "abc"}


def test_large_upload_is_rejected_before_reading(application):
    application.config["MAX_CONTENT_LENGTH"] = 5
    response = application.test_client().post(
        "/echo", data=b"x" * 50, content_type="application/octet-stream"
    )
    assert response.status_code == 413


def test_json_response_from_tuple_with_headers(application):
    @application.route("/created")
    def created():
        return {"id": 1}, 201, {"Location": "/items/1"}

    response = application.test_client().get("/created")
    assert response.status_code == 201
    assert response.headers["Location"] == "/items/1"
    assert response.json == {"id": 1}
