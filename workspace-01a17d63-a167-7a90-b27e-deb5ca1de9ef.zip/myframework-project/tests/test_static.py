"""Tests for static file serving and path-traversal protection."""

from __future__ import annotations

import os
import time

import pytest
from myframework import App
from myframework.exceptions import NotFound, SecurityError
from myframework.static import StaticFiles, safe_join, send_file


@pytest.fixture
def static_dir(tmp_path):
    directory = tmp_path / "static"
    directory.mkdir()
    (directory / "style.css").write_text("body { color: red; }", encoding="utf-8")
    (directory / "app.js").write_text("console.log(1);", encoding="utf-8")
    (directory / "data.json").write_text('{"a": 1}', encoding="utf-8")
    (directory / "payload.exe").write_bytes(b"MZ binary")
    (directory / "sub").mkdir()
    (directory / "sub" / "deep.txt").write_text("deep", encoding="utf-8")
    (tmp_path / "secret.txt").write_text("secret", encoding="utf-8")
    return directory


@pytest.fixture
def static_app(static_dir) -> App:
    app = App(__name__, static_dir=str(static_dir), TESTING=True)

    @app.route("/")
    def index():
        return "ok"

    return app


# -- safe_join ---------------------------------------------------------------
def test_safe_join_accepts_regular_file(static_dir):
    path = safe_join(str(static_dir), "style.css")
    assert os.path.isfile(path)
    assert path.endswith("style.css")


def test_safe_join_accepts_nested_file(static_dir):
    assert os.path.isfile(safe_join(str(static_dir), "sub/deep.txt"))


def test_safe_join_accepts_leading_slash(static_dir):
    assert safe_join(str(static_dir), "/style.css").endswith("style.css")


@pytest.mark.parametrize(
    "path",
    [
        "../secret.txt",
        "../../etc/passwd",
        "sub/../../secret.txt",
        "..%2Fsecret.txt",
        "%2e%2e/secret.txt",
        "sub/%2e%2e/%2e%2e/secret.txt",
        "..\\secret.txt",
        "style.css\x00.txt",
    ],
)
def test_safe_join_rejects_traversal(static_dir, path):
    with pytest.raises((SecurityError, NotFound)):
        safe_join(str(static_dir), path)


def test_safe_join_rejects_directory(static_dir):
    with pytest.raises(NotFound):
        safe_join(str(static_dir), "")


def test_safe_join_blocks_symlink_escape(static_dir, tmp_path):
    os.symlink(tmp_path / "secret.txt", static_dir / "escape.txt")
    with pytest.raises(SecurityError):
        safe_join(str(static_dir), "escape.txt")


# -- HTTP behaviour ----------------------------------------------------------
def test_serves_css(static_app):
    response = static_app.test_client().get("/static/style.css")
    assert response.status_code == 200
    assert response.mimetype == "text/css"
    assert response.text == "body { color: red; }"
    assert response.headers["Content-Length"] == str(len("body { color: red; }"))


def test_serves_javascript(static_app):
    response = static_app.test_client().get("/static/app.js")
    assert response.status_code == 200
    assert "javascript" in response.mimetype


def test_serves_nested_file(static_app):
    response = static_app.test_client().get("/static/sub/deep.txt")
    assert response.status_code == 200
    assert response.text == "deep"


def test_missing_static_file_404(static_app):
    assert static_app.test_client().get("/static/nope.css").status_code == 404


@pytest.mark.parametrize(
    "path",
    [
        "/static/../secret.txt",
        "/static/%2e%2e/secret.txt",
        "/static/..%2Fsecret.txt",
        "/static/sub/../../secret.txt",
        "/static/..%5Csecret.txt",
    ],
)
def test_traversal_attempts_are_blocked(static_app, path):
    response = static_app.test_client().get(path)
    assert response.status_code in (400, 403, 404)
    assert "secret" not in response.text


def test_executable_is_served_as_download(static_app):
    response = static_app.test_client().get("/static/payload.exe")
    assert response.status_code == 200
    assert response.mimetype == "application/octet-stream"


def test_etag_and_conditional_request(static_app):
    client = static_app.test_client()
    first = client.get("/static/style.css")
    etag = first.headers["ETag"]
    assert etag
    second = client.get("/static/style.css", headers={"If-None-Match": etag})
    assert second.status_code == 304
    assert second.data == b""


def test_last_modified_conditional_request(static_app):
    client = static_app.test_client()
    first = client.get("/static/style.css")
    last_modified = first.headers["Last-Modified"]
    second = client.get("/static/style.css", headers={"If-Modified-Since": last_modified})
    assert second.status_code == 304


def test_cache_control_header(static_app):
    response = static_app.test_client().get("/static/style.css")
    assert "max-age" in response.headers["Cache-Control"]


def test_send_file_returns_404_for_missing(tmp_path):
    with pytest.raises(NotFound):
        send_file(str(tmp_path / "nope.txt"))


def test_static_directory_can_be_missing():
    app = App(__name__, static_dir="/definitely/not/here", TESTING=True)
    assert app.test_client().get("/static/anything.css").status_code == 404


def test_static_url_path_is_configurable(static_dir):
    app = App(__name__, static_dir=str(static_dir), STATIC_URL_PATH="/assets", TESTING=True)
    assert app.test_client().get("/assets/style.css").status_code == 200
    assert app.test_client().get("/static/style.css").status_code == 404


def test_static_files_standalone_wsgi_app(static_dir):
    from conftest import call_wsgi

    static = StaticFiles(str(static_dir), url_path="/s")
    status, headers, body = call_wsgi(static, "/s/style.css")
    assert status == "200 OK"
    assert body == b"body { color: red; }"

    status, headers, body = call_wsgi(static, "/s/../secret.txt")
    assert status.startswith(("403", "404"))


def test_head_request_on_static_file(static_app):
    response = static_app.test_client().head("/static/style.css")
    assert response.status_code == 200
    assert response.data == b""
    assert int(response.headers["Content-Length"]) > 0


def test_file_is_streamed_in_chunks(tmp_path):
    big = tmp_path / "big.bin"
    big.write_bytes(b"x" * (200 * 1024))
    response = send_file(str(big))
    chunks = list(response.wsgi({"REQUEST_METHOD": "GET"}, lambda *args: None))
    assert len(chunks) >= 3


def test_static_response_is_closed(static_app):
    response = static_app.test_client().get("/static/style.css")
    assert response.status_code == 200


def test_mtime_change_updates_etag(static_app, static_dir):
    client = static_app.test_client()
    first = client.get("/static/style.css").headers["ETag"]
    path = static_dir / "style.css"
    path.write_text("body { color: blue; }", encoding="utf-8")
    os.utime(path, (time.time() + 5, time.time() + 5))
    second = client.get("/static/style.css").headers["ETag"]
    assert first != second
