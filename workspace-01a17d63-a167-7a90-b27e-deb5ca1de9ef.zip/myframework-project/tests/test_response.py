"""Tests for :mod:`myframework.response` — the response object and helpers."""

from __future__ import annotations

import io
import json

import pytest
from myframework import Response, abort, jsonify, redirect, stream_response
from myframework.exceptions import HTTPException
from myframework.wsgi import make_environ


def call(response, method="GET", path="/"):
    """Run a response through the WSGI interface and collect status/headers/body."""
    captured = {}

    def start_response(status, headers, exc_info=None):
        captured["status"] = status
        captured["headers"] = headers
        return lambda data: None

    environ = make_environ(path=path, method=method)
    body = b"".join(response(environ, start_response))
    return captured["status"], dict(captured["headers"]), body


def header_pairs(response, method="GET"):
    captured = {}

    def start_response(status, headers, exc_info=None):
        captured["status"] = status
        captured["headers"] = headers
        return lambda data: None

    b"".join(response(make_environ(path="/", method=method), start_response))
    return captured["headers"]


# ---------------------------------------------------------------------------
# status codes
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "value, expected",
    [
        (200, "200 OK"),
        (204, "204 NO CONTENT"),
        (418, "418 I'M A TEAPOT"),
        ("404 Not Found", "404 NOT FOUND"),
        ("500 Internal Server Error", "500 INTERNAL SERVER ERROR"),
        ("201", "201 CREATED"),
    ],
)
def test_status_forms(value, expected):
    assert call(Response("x", status=value))[0] == expected


def test_status_code_and_phrase_properties():
    response = Response(status="418 I'm a teapot")
    assert response.status_code == 418
    assert response.status == "418 I'M A TEAPOT"
    response.status_code = 500
    assert response.status == "500 INTERNAL SERVER ERROR"
    response.status = "202 ACCEPTED"
    assert response.status_code == 202


def test_invalid_status_rejected():
    with pytest.raises(ValueError):
        Response(status="not a status")
    with pytest.raises(ValueError):
        Response(status="99 TOO LOW")
    with pytest.raises(TypeError):
        Response(status=200.5)  # type: ignore[arg-type]


def test_unknown_status_code_gets_generic_phrase():
    assert Response(status=599).status.startswith("599 ")


# ---------------------------------------------------------------------------
# bodies
# ---------------------------------------------------------------------------


def test_text_body_is_encoded_with_charset():
    status, headers, body = call(Response("héllo"))
    assert body == "héllo".encode()
    assert headers["Content-Type"] == "text/html; charset=utf-8"
    assert headers["Content-Length"] == str(len(body))


def test_bytes_body_keeps_content_type():
    status, headers, body = call(Response(b"\x00\x01binary", content_type="image/png"))
    assert body == b"\x00\x01binary"
    assert headers["Content-Type"] == "image/png"


def test_get_data_and_set_data():
    response = Response("abc")
    assert response.get_data() == b"abc"
    assert response.get_data(as_text=True) == "abc"
    assert response.text == "abc"
    response.set_data("xyz")
    assert response.text == "xyz"
    assert response.headers["Content-Length"] == "3"
    response.set_data(b"\xff")
    assert response.get_data() == b"\xff"


def test_body_type_is_validated():
    with pytest.raises(TypeError):
        Response({"a": 1})  # type: ignore[arg-type]
    with pytest.raises(TypeError):
        Response(42)  # type: ignore[arg-type]


def test_iterable_body_is_streamed():
    def chunks():
        yield b"a"
        yield b"b"
        yield b"c"

    status, headers, body = call(Response(chunks(), direct_passthrough=True))
    assert body == b"abc"
    assert "Content-Length" not in headers


def test_streaming_response_helper():
    response = stream_response(iter([b"x", b"y"]), mimetype="text/plain")
    assert isinstance(response, Response)
    assert call(response)[2] == b"xy"
    assert response.headers["Content-Type"] == "text/plain; charset=utf-8"


def test_streaming_generator_can_be_closed():
    closed = []

    def chunks():
        try:
            yield b"data"
        finally:
            closed.append(True)

    response = stream_response(chunks())
    list(response(make_environ(path="/"), lambda s, h, e=None: None))
    response.close()
    assert closed == [True]


def test_generator_is_not_consumed_twice():
    calls = []

    def chunks():
        calls.append(1)
        yield b"once"

    response = Response(chunks(), direct_passthrough=True)
    assert call(response)[2] == b"once"
    with pytest.raises(RuntimeError):
        call(response)


# ---------------------------------------------------------------------------
# headers
# ---------------------------------------------------------------------------


def test_headers_are_case_insensitive_but_preserve_case():
    response = Response("x")
    response.headers["X-Custom"] = "1"
    assert response.headers["x-custom"] == "1"
    assert ("X-Custom", "1") in header_pairs(response)
    response.headers["x-CUSTOM"] = "2"
    assert len([key for key, _ in header_pairs(response) if key.lower() == "x-custom"]) == 1


def test_repeated_headers_are_sent_separately():
    response = Response("x")
    response.headers.add("Set-Cookie", "a=1")
    response.headers.add("Set-Cookie", "b=2")
    cookies = [value for key, value in header_pairs(response) if key == "Set-Cookie"]
    assert cookies == ["a=1", "b=2"]


def test_getlist_and_remove():
    response = Response("x")
    response.headers.add("X-Multi", "a")
    response.headers.add("X-Multi", "b")
    assert response.headers.getlist("X-Multi") == ["a", "b"]
    del response.headers["X-Multi"]
    assert "X-Multi" not in response.headers
    assert response.headers.get("Missing", "fallback") == "fallback"


def test_non_latin1_header_raises():
    response = Response("x")
    response.headers["X-Bad"] = "héllo ✓"
    with pytest.raises((UnicodeEncodeError, ValueError)):
        call(response)


def test_latin1_header_is_preserved():
    response = Response("x")
    response.headers["X-Ok"] = "café"
    status, headers, _ = call(response)
    assert headers["X-Ok"] == "café"
    assert headers["X-Ok"].encode("latin-1") == b"caf\xe9"


def test_content_type_helpers():
    response = Response("x")
    assert response.mimetype == "text/html"
    assert response.charset == "utf-8"
    response.mimetype = "application/json"
    assert response.headers["Content-Type"] == "application/json; charset=utf-8"
    response.content_type = "text/plain; charset=iso-8859-1"
    assert response.mimetype == "text/plain"


def test_json_content_type_has_no_charset_problem():
    response = jsonify({"a": 1})
    assert response.headers["Content-Type"].startswith("application/json")
    status, headers, body = call(response)
    assert json.loads(body) == {"a": 1}


# ---------------------------------------------------------------------------
# HEAD handling
# ---------------------------------------------------------------------------


def test_head_request_drops_the_body_but_keeps_headers():
    response = Response("hello world")
    length = response.headers["Content-Length"]
    status, headers, body = call(response, method="HEAD")
    assert body == b""
    assert headers["Content-Length"] == length == "11"
    assert status == "200 OK"


# ---------------------------------------------------------------------------
# JSON
# ---------------------------------------------------------------------------


def test_jsonify_dict_and_kwargs():
    assert json.loads(call(jsonify({"a": 1}))[2]) == {"a": 1}
    assert json.loads(call(jsonify(a=1, b=[1, 2]))[2]) == {"a": 1, "b": [1, 2]}


def test_jsonify_multiple_positional_args_becomes_a_list():
    assert json.loads(call(jsonify(1, 2))[2]) == [1, 2]


def test_jsonify_rejects_mixed_args():
    with pytest.raises(TypeError):
        jsonify({"a": 1}, b=2)


def test_jsonify_status_and_headers():
    response = jsonify({"ok": True}, status=201, headers={"X-Thing": "1"})
    assert response.status_code == 201
    assert response.headers["X-Thing"] == "1"


def test_json_response_parses_back():
    response = jsonify({"a": [1, 2], "b": "text"})
    assert response.get_json() == {"a": [1, 2], "b": "text"}
    assert response.json == {"a": [1, 2], "b": "text"}
    assert response.is_json is True


def test_jsonify_supports_non_ascii_and_dates():
    import datetime

    payload = {"name": "café ✓", "when": datetime.date(2026, 10, 27)}
    body = call(jsonify(payload))[2].decode("utf-8")
    assert "café ✓" in body
    assert json.loads(body)["when"] == "2026-10-27"


def test_jsonify_escapes_scripts_by_default():
    body = call(jsonify({"html": "</script><b>"}))[2].decode()
    assert "</script>" not in body


def test_non_json_body_returns_none_from_get_json():
    assert Response("plain").get_json() is None


# ---------------------------------------------------------------------------
# cookies
# ---------------------------------------------------------------------------


def test_set_cookie_defaults():
    response = Response("x")
    response.set_cookie("session", "abc")
    value = response.headers.get("Set-Cookie")
    assert value == "session=abc; Path=/; SameSite=Lax"


def test_set_cookie_explicit_flags():
    response = Response("x")
    response.set_cookie(
        "session",
        "abc",
        max_age=60,
        secure=True,
        httponly=True,
        samesite="Strict",
        path="/app",
        domain="example.com",
    )
    value = response.headers.get("Set-Cookie")
    assert "Max-Age=60" in value
    assert "Secure" in value
    assert "HttpOnly" in value
    assert "SameSite=Strict" in value
    assert "Path=/app" in value
    assert "Domain=example.com" in value


def test_delete_cookie_expires_it():
    response = Response("x")
    response.delete_cookie("session")
    value = response.headers.get("Set-Cookie")
    assert "Max-Age=0" in value
    assert "expires=" in value.lower()
    assert "session=" in value


def test_samesite_none_requires_secure():
    with pytest.raises(ValueError):
        Response("x").set_cookie("a", "b", samesite="None")
    Response("x").set_cookie("a", "b", samesite="None", secure=True)


def test_invalid_cookie_name_rejected():
    with pytest.raises(ValueError):
        Response("x").set_cookie("bad name", "v")
    with pytest.raises(ValueError):
        Response("x").set_cookie("", "v")


def test_cookie_value_is_quoted_when_needed():
    response = Response("x")
    response.set_cookie("thing", "a b;c")
    value = response.headers.get("Set-Cookie")
    assert value.startswith('thing="')
    assert value.endswith('"; Path=/; SameSite=Lax')


# ---------------------------------------------------------------------------
# helpers: redirect / abort
# ---------------------------------------------------------------------------


def test_redirect_default_and_custom_code():
    response = redirect("/next")
    assert response.status_code == 302
    assert response.headers["Location"] == "/next"
    assert redirect("/next", code=301).status_code == 301
    assert redirect("/next", code=308).status_code == 308


def test_redirect_escapes_html_in_body():
    response = redirect("/x?a=<script>alert(1)</script>")
    body = response.get_data(as_text=True)
    assert "<script>" not in body
    assert "%3Cscript%3E" in response.headers["Location"]
    assert '<a href="/x%3Fa%3D%3Cscript%3E' in body


def test_abort_raises_http_exception():
    with pytest.raises(HTTPException) as info:
        abort(404)
    assert info.value.code == 404
    assert info.value.description

    with pytest.raises(HTTPException) as info:
        abort(403, "nope")
    assert info.value.description == "nope"


def test_abort_unknown_code_rejected():
    with pytest.raises(LookupError):
        abort(999)


def test_abort_inside_view_becomes_response():
    from myframework import App

    app = App(__name__, TESTING=True)

    @app.route("/")
    def index():
        abort(418)

    response = app.test_client().get("/")
    assert response.status_code == 418


# ---------------------------------------------------------------------------
# caching helpers
# ---------------------------------------------------------------------------


def test_cache_control_helper():
    response = Response("x")
    response.cache_control(max_age=60, public=True)
    assert response.headers["Cache-Control"] == "public, max-age=60"

    response = Response("x")
    response.cache_control(no_cache=True, no_store=True, must_revalidate=True)
    value = response.headers["Cache-Control"]
    assert "no-cache" in value
    assert "no-store" in value
    assert "must-revalidate" in value


def test_expires_and_etag_helpers():
    response = Response("x")
    response.set_etag("abc123")
    assert response.headers["ETag"] == '"abc123"'
    assert response.get_etag() == "abc123"
    response.set_expires(60)
    assert response.headers["Expires"].endswith("GMT")
    response.set_expires(0)
    assert "1970" in response.headers["Expires"]


def test_add_vary():
    response = Response("x")
    response.add_vary("Accept")
    response.add_vary("Accept-Encoding")
    assert response.headers["Vary"] == "Accept, Accept-Encoding"


# ---------------------------------------------------------------------------
# WSGI contract
# ---------------------------------------------------------------------------


def test_response_is_itself_a_wsgi_callable():
    response = Response("hi")
    status, headers, body = call(response)
    assert status == "200 OK"
    assert isinstance(headers, dict)
    assert body == b"hi"


def test_start_response_headers_are_strings():
    response = Response("hi")
    response.headers.add("Set-Cookie", "a=1")
    for key, value in header_pairs(response):
        assert isinstance(key, str)
        assert isinstance(value, str)
    for key, value in header_pairs(response):
        key.encode("latin-1")
        value.encode("latin-1")


def test_file_like_body_is_closed():
    handle = io.BytesIO(b"file content")
    response = Response(handle, direct_passthrough=True)
    assert call(response)[2] == b"file content"
    response.close()
    assert handle.closed
