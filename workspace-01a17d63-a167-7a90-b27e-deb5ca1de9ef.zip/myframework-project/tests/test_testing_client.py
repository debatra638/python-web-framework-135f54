"""Tests for the test client itself (it is part of the public API)."""

from __future__ import annotations

import pytest
from myframework import App, jsonify, redirect


@pytest.fixture
def app() -> App:
    app = App(__name__, TESTING=True, PROPAGATE_EXCEPTIONS=False)

    @app.route("/")
    def index():
        return "<h1>home</h1>"

    @app.route("/redirect")
    def redirect_view():
        return redirect("/")

    @app.route("/redirect-chain")
    def chain():
        return redirect("/redirect")

    @app.route("/login", methods=["POST"])
    def login():
        from myframework import request

        if request.form.get("user") == "ada":
            response = jsonify(ok=True)
            response.set_cookie("user", "ada", httponly=True)
            return response
        return {"ok": False}, 401

    @app.route("/whoami")
    def whoami():
        from myframework import request

        return {"user": request.cookies.get("user")}

    @app.route("/logout")
    def logout():
        response = jsonify(ok=True)
        response.delete_cookie("user")
        return response

    @app.route("/upload", methods=["POST"])
    def upload():
        from myframework import request

        file = request.files.get("doc")
        return {"filename": getattr(file, "filename", None), "title": request.form.get("title")}

    @app.route("/method", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
    def method():
        from myframework import request

        return {"method": request.method}

    return app


def test_verb_helpers(app):
    client = app.test_client()
    assert client.get("/method").json == {"method": "GET"}
    assert client.post("/method").json == {"method": "POST"}
    assert client.put("/method").json == {"method": "PUT"}
    assert client.patch("/method").json == {"method": "PATCH"}
    assert client.delete("/method").json == {"method": "DELETE"}
    assert client.options("/method").json == {"method": "OPTIONS"}
    assert client.head("/").status_code == 200


def test_cookies_are_remembered_and_cleared(app):
    client = app.test_client()
    assert client.post("/login", form={"user": "ada"}).status_code == 200
    assert client.get("/whoami").json == {"user": "ada"}
    client.get("/logout")
    assert client.get("/whoami").json == {"user": None}


def test_failed_login_sets_no_cookie(app):
    client = app.test_client()
    assert client.post("/login", form={"user": "bob"}).status_code == 401
    assert client.get("/whoami").json == {"user": None}


def test_use_cookies_disabled(app):
    client = app.test_client(use_cookies=False)
    client.post("/login", form={"user": "ada"})
    assert client.get("/whoami").json == {"user": None}


def test_follow_redirects(app):
    client = app.test_client()
    response = client.get("/redirect", follow_redirects=True)
    assert response.status_code == 200
    assert response.text == "<h1>home</h1>"
    assert len(response.history) == 1
    assert response.history[0].status_code == 302


def test_follow_redirect_chain(app):
    response = app.test_client().get("/redirect-chain", follow_redirects=True)
    assert response.status_code == 200
    assert len(response.history) == 2


def test_client_default_follow_redirects(app):
    client = app.test_client()

    client.follow_redirects = True
    assert client.get("/redirect").status_code == 200


def test_multipart_upload_via_client(app):
    response = app.test_client().post(
        "/upload",
        files={"doc": ("notes.txt", b"content")},
        form={"title": "hello"},
    )
    assert response.json == {"filename": "notes.txt", "title": "hello"}


def test_json_and_form_bodies(app):
    client = app.test_client()
    assert client.post("/login", json={"user": "ada"}).status_code == 401
    assert client.post("/login", data={"user": "ada"}).status_code == 200
    assert (
        client.post(
            "/login", data="user=ada&", content_type="application/x-www-form-urlencoded"
        ).status_code
        == 200
    )


def test_raw_bytes_and_text_bodies(app):
    client = app.test_client()
    assert client.post("/method", data=b"raw").json == {"method": "POST"}
    assert client.post("/method", data="text").json == {"method": "POST"}


def test_query_string_forms(app):
    client = app.test_client()
    assert client.get("/method?x=1").status_code == 200
    assert client.get("/method", query_string={"x": "1"}).status_code == 200
    assert client.get("/method", query_string="x=1").status_code == 200


def test_absolute_url_is_honoured(app):
    response = app.test_client().get("https://example.com/method")
    assert response.status_code == 200
    assert response.request is not None
    assert response.request.host == "example.com"
    assert response.request.scheme == "https"


def test_response_assertions(app):
    client = app.test_client()
    client.get("/").assert_status(200).assert_ok().assert_contains("home")
    client.get("/").assert_content_type("text/html")
    client.get("/redirect").assert_redirects("/")
    with pytest.raises(AssertionError):
        client.get("/").assert_status(404)
    with pytest.raises(AssertionError):
        client.get("/").assert_contains("nope")


def test_response_helpers(app):
    response = app.test_client().get("/")
    assert response.location is None
    assert repr(response).startswith("<TestResponse 200")


def test_client_context_manager(app):
    with app.test_client() as client:
        client.post("/login", form={"user": "ada"})
    assert len(client.cookies) == 0


def test_client_repr(app):
    assert "Client" in repr(app.test_client())


def test_default_environ_overrides(app):
    client = app.test_client()
    client.default_environ_overrides["HTTP_X_TEST"] = "1"

    @app.route("/env")
    def env_view():
        from myframework import request

        return {"value": request.headers.get("X-Test")}

    assert client.get("/env").json == {"value": "1"}
