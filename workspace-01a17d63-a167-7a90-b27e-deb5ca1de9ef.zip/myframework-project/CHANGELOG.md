# Changelog

All notable changes to this project are documented here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project adheres to
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added — distribution and onboarding

- `python -m myframework` works as an alias for the console script (`myframework/__main__.py`).
- `docs/installation.md` (wheel, sdist, editable, offline/air-gapped, type checking,
  uninstalling, releasing), `docs/quickstart.md` (end-to-end tutorial) and `docs/api.md`
  (reference generated from the docstrings by `scripts/build_api_docs.py`).
- `scripts/verify_install.sh`: builds the artifacts, installs them into a throwaway venv
  and exercises the test client, `myframework routes`, `myframework run` over real HTTP,
  a plain WSGI server, `myframework new` plus the generated project's tests, and an sdist
  install — i.e. the whole experience of a developer who has never seen the source.
- `tests/test_packaging.py`: guards the library contract (metadata present and single-sourced,
  every `__all__` name importable, `py.typed` shipped, no runtime dependencies, entry points
  loadable, docs/API reference in sync, README links intact).
- `MANIFEST.in`: the sdist now ships `tests/conftest.py` (previously missing, which made the
  packaged test suite unrunnable), all tests, `examples/`, `docs/`, `scripts/`, `CHANGELOG.md`
  and the CI configuration; build/dist output and caches are excluded.

### Fixed

- `myframework new` generated a project where a bare `pytest` failed with
  `ModuleNotFoundError: No module named 'app'` and `pip install -e .` did not build. The
  scaffold now ships `[build-system]`, `py-modules = ["app"]`, `pythonpath = ["."]` and a
  `>=3.10` requirement, and its README documents the offline install path.

### Changed

- The version is single-sourced: `pyproject.toml` uses `dynamic = ["version"]` from
  `myframework.__version__`, so metadata and code can no longer drift.
- Removed the placeholder `example.invalid` project URLs from the metadata; real
  `[project.urls]` entries belong in `pyproject.toml` before the first PyPI upload.
- `scripts/check.sh` now also verifies `docs/api.md` is current, validates the built
  artifacts with `twine check`, and finishes with the install rehearsal.

## [0.1.0] — 2026-10-27

First public release: a complete, installable framework with native WSGI support and no
runtime dependencies.

### Added

**HTTP engine**
- `Request` built from the WSGI environ: method, path (percent-decoded), query string,
  headers (case-insensitive), cookies, `MultiDict` query/form values, JSON parsing,
  urlencoded and multipart bodies with `FileStorage` uploads.
- `Response` (also a WSGI application): text/bytes/streaming bodies, status as `int` or
  `"418 I'M A TEAPOT"`, case-insensitive headers, cookies with explicit flags,
  `Cache-Control`, `ETag`, `Last-Modified`, automatic `Content-Length`, `HEAD` handling.
- `jsonify`, `redirect`, `abort`, `make_response`, `stream_response`.
- `HTTPException` hierarchy (`NotFound`, `MethodNotAllowed`, `PayloadTooLarge`, …) that
  renders escaped error pages with correct headers (`Allow` for 405).

**Routing**
- Decorator and `add_url_rule` registration; `get/post/put/patch/delete` shortcuts.
- Converters: `string`, `path`, `int`, `float`, `uuid`, `any(...)`, plus custom converters
  via `@app.converter("name")`.
- Specificity-based matching (`/users/me` beats `/users/<username>`), automatic `HEAD` and
  `OPTIONS`, complete `Allow` headers when several endpoints share a URL, `308`
  trailing-slash redirects, `defaults` support.
- `url_for` with query strings, `_external`, `_scheme`, `_anchor`, and template access.

**WSGI (PEP 3333)**
- `App` instances are WSGI callables; `app.wsgi_app`, `wsgi_application`, `middleware_chain`,
  `validate_response`, `serve_wsgiref`, `make_environ`.
- Contract tests for status lines, header lists, byte iterables, `start_response` calls,
  streaming `close()`, and integration tests against `wsgiref` and Gunicorn.

**Applications**
- `before_request` / `after_request` / `teardown_request` hooks, `context_processor`,
  `errorhandler` for status codes and exception classes, custom template filters/globals.
- `request` / `g` / `current_app` proxies backed by `contextvars`.
- Threaded development server with startup banner, request logging and an auto-reloader;
  `myframework run|routes|new|version` CLI; project scaffolding.

**Templates**
- Original engine: `{{ }}`, `{% if/elif/else %}`, `{% for/else %}` with loop helpers,
  `{% block %}` + `{{ super() }}`, `{% extends %}`, `{% include %}` (+ `ignore missing`),
  `{% set %}`, `{% raw %}`, comments, whitespace control, ~30 filters.
- Expressions parsed with `ast` and evaluated by an allow-list interpreter (no `eval`),
  autoescaping on by default, strict undefined handling with helpful messages.
- `FileSystemLoader` (traversal-safe), `DictLoader`, `ChoiceLoader`.

**Static files**
- Traversal-safe `safe_join`, streaming `send_file`, `StaticFiles` (also a WSGI app),
  `ETag`/`Last-Modified` conditional requests, cache headers, download-only types.

**Configuration**
- `Config` dict with attribute access, defaults, `from_env("MYFRAMEWORK_")`, `from_file`
  (JSON/TOML), `from_object`, typed coercion and validation errors.

**Middleware**
- `WSGIMiddleware` base with `process_environ`/`process_response` hooks, `MiddlewareStack`,
  `RequestIDMiddleware`, `AccessLogMiddleware`, `HeaderMiddleware`,
  `SecurityHeadersMiddleware`, `CORSMiddleware`, `TrustedHostMiddleware`, `ProxyFix`,
  `HTTPSRedirectMiddleware`.

**Tooling**
- `pyproject.toml` (setuptools), console script, `py.typed`, optional `dev`/`servers` extras.
- 446 pytest tests (unit, WSGI contract, Gunicorn/dev-server integration, security,
  CLI/scaffolding, examples), ruff lint+format config, strict mypy, GitHub Actions CI,
  `scripts/check.sh` running every check including a wheel build and clean-venv install.
- Documentation: README, `docs/architecture.md`, `docs/security.md`, `docs/deployment.md`,
  three runnable examples.

### Known limitations

- No sessions, authentication, CSRF, rate limiting or HTTPS handling (documented in
  `docs/security.md`).
- No blueprints, macros/custom template tags, HTTP range requests, ASGI/WebSocket support.
- Filters bind like Python's `|`; parenthesise when mixing with arithmetic.
- `SECRET_KEY` is reserved for future session support and currently unused.
