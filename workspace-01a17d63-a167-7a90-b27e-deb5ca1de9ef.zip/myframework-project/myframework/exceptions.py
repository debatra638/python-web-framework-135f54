"""Exception types raised and handled by MyFramework.

The module is deliberately dependency-free so that every other module in the
package can import from it without creating cycles.

Two families of exceptions live here:

``HTTPException``
    Exceptions that map onto an HTTP status code.  Raising one from a view
    function aborts the request and produces a well-formed response (either the
    default plain-text body or a registered error handler).

Plain Python exceptions
    Raised for programming errors (bad routes, bad templates, bad
    configuration).  They are never converted into a user visible HTTP error
    unless debug mode is enabled, in which case they are shown inside the
    traceback page.
"""

from __future__ import annotations

from collections.abc import Iterable
from http import HTTPStatus
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:  # pragma: no cover - typing only
    from .response import Response

__all__ = [
    "BadGateway",
    "BadRequest",
    "ConfigurationError",
    "Conflict",
    "Forbidden",
    "FrameworkException",
    "HTTPException",
    "InternalServerError",
    "MethodNotAllowed",
    "NotFound",
    "NotImplementedResponse",
    "PayloadTooLarge",
    "RequestEntityTooLarge",
    "RequestRedirect",
    "RoutingError",
    "SecurityError",
    "ServiceUnavailable",
    "TemplateError",
    "TemplateNotFound",
    "TemplateRuntimeError",
    "TemplateSyntaxError",
    "Unauthorized",
    "UndefinedError",
    "UnsupportedMediaType",
    "default_status_text",
]


def default_status_text(code: int) -> str:
    """Return the canonical reason phrase for *code*.

    Uses :mod:`http` from the standard library and falls back to an empty
    string for unknown extension codes, which is valid per RFC 7230.
    """
    try:
        return HTTPStatus(code).phrase
    except ValueError:
        return ""


class FrameworkException(Exception):
    """Base class for every exception defined by MyFramework."""


class HTTPException(FrameworkException):
    """An exception that is also a valid HTTP response.

    Parameters
    ----------
    code:
        HTTP status code, e.g. ``404``.
    description:
        Human readable, safe-to-expose description.  It is rendered inside the
        default error page, therefore it must never contain unescaped user
        input (the renderer escapes it anyway).
    name:
        Optional response body title.  Defaults to the status reason phrase.
    headers:
        Extra response headers, e.g. ``Allow`` for ``405``.
    """

    code: int = 500
    description: str = "An unexpected error occurred."

    def __init__(
        self,
        code: int | str | None = None,
        description: str | None = None,
        name: str | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        if isinstance(code, str) and description is None:
            # Convenience: ``NotFound("no such user")`` means the description.
            description = code
            code = None
        if code is not None:
            if not isinstance(code, int):
                raise TypeError(f"HTTPException code must be an int, got {type(code).__name__}.")
            self.code = code
        if description is not None:
            self.description = description
        self.name = name if name is not None else default_status_text(self.code)
        self.headers = dict(headers or {})
        super().__init__(f"{self.code} {self.name}: {self.description}")

    def __str__(self) -> str:
        return f"{self.code} {self.name}: {self.description}"

    def get_headers(self) -> list[tuple[str, str]]:
        """Return the headers this exception adds to its response."""
        return list(self.headers.items())

    def get_body(self) -> str:
        """Return the default (escaped) HTML body for this error."""
        from .utils import escape  # local import: utils has no dependencies

        return (
            f'<!doctype html>\n<html lang="en"><head><meta charset="utf-8">'
            f"<title>{self.code} {escape(self.name)}</title></head>\n"
            f"<body><h1>{self.code} {escape(self.name)}</h1>"
            f"<p>{escape(self.description)}</p></body></html>\n"
        )

    def get_response(self) -> Response:
        """Build a :class:`~myframework.response.Response` for this error."""
        from .response import Response

        response = Response(
            self.get_body(),
            status=self.code,
            mimetype="text/html; charset=utf-8",
        )
        for key, value in self.get_headers():
            response.headers.add(key, value)
        return response


class BadRequest(HTTPException):
    code = 400
    description = "The browser (or proxy) sent a request that this server could not understand."


class Unauthorized(HTTPException):
    code = 401
    description = "The server could not verify that you are authorized to access this resource."


class Forbidden(HTTPException):
    code = 403
    description = "You do not have permission to access this resource."


class NotFound(HTTPException):
    code = 404
    description = "The requested URL was not found on this server."


class MethodNotAllowed(HTTPException):
    """Raised when the URL exists but does not accept the request method."""

    code = 405
    description = "The method is not allowed for the requested URL."

    def __init__(
        self,
        valid_methods: Iterable[str] | None = None,
        description: str | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        self.valid_methods = sorted({m.upper() for m in (valid_methods or ())})
        super().__init__(description=description, headers=headers)

    def get_headers(self) -> list[tuple[str, str]]:
        headers = super().get_headers()
        if self.valid_methods:
            headers.append(("Allow", ", ".join(self.valid_methods)))
        return headers


class Conflict(HTTPException):
    code = 409
    description = "The request conflicts with the current state of the resource."


class PayloadTooLarge(HTTPException):
    """The request body exceeded ``MAX_CONTENT_LENGTH``."""

    code = 413
    description = "The request body is larger than this server is willing to process."


#: Backwards friendly alias (RFC 7231 renamed 413 to Payload Too Large).
RequestEntityTooLarge = PayloadTooLarge


class UnsupportedMediaType(HTTPException):
    code = 415
    description = "The request media type is not supported by this server."


class InternalServerError(HTTPException):
    code = 500
    description = (
        "The server encountered an internal error and was unable to complete your request."
    )


class NotImplementedResponse(HTTPException):
    code = 501
    description = "The server does not support the functionality required to fulfill the request."


class BadGateway(HTTPException):
    code = 502
    description = "The server received an invalid response from an upstream server."


class ServiceUnavailable(HTTPException):
    code = 503
    description = "The server is temporarily unable to handle the request."


class RoutingError(FrameworkException):
    """Base class for errors raised by the routing engine itself."""


class RequestRedirect(HTTPException):
    """A routing result that asks the client to retry on a different URL.

    Used for canonical trailing-slash redirects (``/about/`` -> ``/about``).
    """

    code = 308

    def __init__(self, new_path: str, code: int = 308) -> None:
        self.code = code
        self.new_path = new_path
        super().__init__(description=f"Redirecting to {new_path}")

    @property
    def new_url(self) -> str:
        """Alias of :attr:`new_path` (kept for readability in client code)."""
        return self.new_path

    def get_response(self) -> Response:
        from .response import redirect

        return redirect(self.new_path, code=self.code)


class ConfigurationError(FrameworkException):
    """Raised when the application configuration is invalid."""


class TemplateError(FrameworkException):
    """Base class for template engine errors."""


class TemplateNotFound(TemplateError):
    """The requested template does not exist in the loader search path."""

    def __init__(self, name: str, searched: Iterable[str] = ()) -> None:
        self.name = name
        self.searched = list(searched)
        message = f"Template {name!r} not found."
        if self.searched:
            message += " Searched: " + ", ".join(self.searched)
        super().__init__(message)


class TemplateSyntaxError(TemplateError):
    """The template source is not valid."""

    def __init__(self, message: str, name: str = "<string>", lineno: int = 0) -> None:
        self.name = name
        self.lineno = lineno
        self.message = message
        location = f"{name}:{lineno}" if lineno else name
        super().__init__(f"{location}: {message}")


class TemplateRuntimeError(TemplateError):
    """An error occurred while rendering (e.g. unknown filter)."""


class UndefinedError(TemplateRuntimeError):
    """A template used a variable that does not exist."""


class SecurityError(FrameworkException):
    """Raised when a request attempts an unsafe file or path operation."""


# Keep a small typed helper for internal use.
def is_http_exception(value: Any) -> bool:
    """Return ``True`` when *value* is an :class:`HTTPException` instance."""
    return isinstance(value, HTTPException)
