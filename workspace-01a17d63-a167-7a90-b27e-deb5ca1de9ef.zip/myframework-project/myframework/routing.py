"""URL routing: rules, converters, the rule map, and URL building.

The engine is intentionally small but predictable:

* Rules are compiled to regular expressions once, at registration time.
* Matching prefers the *most specific* rule: fewer wildcards first, then more
  literal characters, then registration order.  This means ``/users/me`` always
  wins over ``/users/<username>`` regardless of decorator order.
* Methods are checked after a path match so a wrong method yields ``405`` with
  a correct ``Allow`` header instead of a misleading ``404``.
* A trailing-slash mismatch produces a ``308`` redirect to the canonical URL
  instead of a silent 404 (controlled by ``strict_slashes``).

Note on decoding: the dispatcher matches the *decoded* path (``Request.path``).
Percent-encoded slashes therefore cannot be used to smuggle extra segments
past a converter, because decoding happens before matching and the resulting
segments are matched literally.  Filesystem access is additionally guarded by
:func:`myframework.static.safe_join`.
"""

from __future__ import annotations

import re
import uuid as _uuid
from collections.abc import Callable, Iterable, Iterator, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from .exceptions import MethodNotAllowed, NotFound, RequestRedirect, RoutingError
from .utils import url_quote

__all__ = [
    "HTTP_METHODS",
    "BaseConverter",
    "ConverterRegistry",
    "Map",
    "Rule",
    "default_converters",
    "parse_rule",
]

#: Methods a route may be registered for.
HTTP_METHODS = frozenset(
    {"GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "TRACE", "CONNECT"}
)

#: Methods that always get an automatic ``Allow`` entry.
AUTOMATIC_METHODS = frozenset({"HEAD", "OPTIONS"})


class BaseConverter:
    """Base class for URL converters.

    Subclasses set :attr:`regex` and may override :meth:`to_python` /
    :meth:`to_url` to translate between the URL representation and the Python
    value handed to the view function.
    """

    regex = "[^/]+"
    weight = 100

    def __init__(self, args: Sequence[str] | None = None) -> None:
        self.args = list(args or [])
        self._pattern_cache: str | None = None

    def to_python(self, value: str) -> Any:
        """Convert the URL fragment into the value passed to the view."""
        return value

    def to_url(self, value: Any) -> str:
        """Convert a Python value into a URL fragment."""
        return url_quote(value, safe="")

    def __repr__(self) -> str:  # pragma: no cover - debugging convenience
        return f"<{type(self).__name__} {self.regex!r}>"

    def get_pattern(self) -> str:
        """The regex fragment used for this converter."""
        return self.regex

    def __eq__(self, other: object) -> bool:
        return type(self) is type(other) and self.args == getattr(other, "args", None)

    def __hash__(self) -> int:
        return hash((type(self).__name__, tuple(self.args)))


class StringConverter(BaseConverter):
    """Matches a single path segment (the default converter)."""

    regex = "[^/]+"


class UnicodeConverter(StringConverter):
    """Alias of :class:`StringConverter` kept for API symmetry."""


class IntegerConverter(BaseConverter):
    """Matches an integer and converts it to ``int``."""

    regex = r"\d+"
    weight = 50

    def to_python(self, value: str) -> int:
        return int(value)

    def to_url(self, value: Any) -> str:
        if isinstance(value, bool) or not isinstance(value, (int, str)):
            raise ValueError(f"{value!r} is not a valid integer for a URL.")
        return str(int(value))


class FloatConverter(BaseConverter):
    """Matches a positive decimal number and converts it to ``float``."""

    regex = r"\d+\.\d+"
    weight = 60

    def to_python(self, value: str) -> float:
        return float(value)

    def to_url(self, value: Any) -> str:
        return repr(float(value))


class PathConverter(BaseConverter):
    """Matches across ``/`` boundaries (``<path:filename>``)."""

    regex = "[^/].*?"
    weight = 200

    def to_url(self, value: Any) -> str:
        # Slashes are meaningful in a path, so they stay unencoded.
        return url_quote(value, safe="/")


class UUIDConverter(BaseConverter):
    """Matches a RFC 4122 UUID and converts it to :class:`uuid.UUID`."""

    regex = r"[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}"
    weight = 40

    def to_python(self, value: str) -> _uuid.UUID:
        return _uuid.UUID(value)

    def to_url(self, value: Any) -> str:
        return str(_uuid.UUID(str(value)))


class AnyConverter(BaseConverter):
    """Matches one of a fixed set of values (``<any(apple,pear):fruit>``)."""

    def __init__(self, args: Sequence[str] | None = None) -> None:
        super().__init__(args)
        if not self.args:
            raise ValueError("any() requires at least one argument.")
        for item in self.args:
            if not item or "/" in item:
                raise ValueError(f"any() items must be non-empty and contain no '/': {item!r}")

    def get_pattern(self) -> str:
        return "|".join(re.escape(item) for item in self.args)

    def to_url(self, value: Any) -> str:
        return url_quote(value, safe="")


#: Converters available out of the box.
default_converters: dict[str, type[BaseConverter]] = {
    "string": StringConverter,
    "unicode": UnicodeConverter,
    "int": IntegerConverter,
    "float": FloatConverter,
    "path": PathConverter,
    "uuid": UUIDConverter,
    "any": AnyConverter,
}


class ConverterRegistry:
    """A mutable mapping of converter names, seeded with the defaults.

    Applications may register custom converters::

        @app.converter("slug")
        class SlugConverter(BaseConverter):
            regex = r"[a-z0-9-]+"
    """

    def __init__(self, converters: Mapping[str, type[BaseConverter]] | None = None) -> None:
        self._converters: dict[str, type[BaseConverter]] = dict(default_converters)
        if converters:
            self._converters.update(converters)

    def __getitem__(self, name: str) -> type[BaseConverter]:
        try:
            return self._converters[name]
        except KeyError:
            available = ", ".join(sorted(self._converters))
            raise RoutingError(
                f"Unknown URL converter {name!r}. Available converters: {available}."
            ) from None

    def __contains__(self, name: object) -> bool:
        return name in self._converters

    def register(self, name: str, converter: type[BaseConverter]) -> None:
        """Register (or replace) a converter class."""
        if not isinstance(name, str) or not name.isidentifier():
            raise RoutingError(f"Converter name must be a valid identifier, got {name!r}.")
        if not (isinstance(converter, type) and issubclass(converter, BaseConverter)):
            raise RoutingError("Converters must be subclasses of BaseConverter.")
        self._converters[name] = converter

    def __iter__(self) -> Iterator[str]:
        return iter(self._converters)

    def __len__(self) -> int:
        return len(self._converters)

    def copy(self) -> ConverterRegistry:
        """Return an independent copy of the registry."""
        return ConverterRegistry(self._converters)


_PART_RE = re.compile(
    r"<(?:(?P<converter>[a-zA-Z_][a-zA-Z0-9_]*)(?:\((?P<args>.*?)\))?:)?(?P<name>[a-zA-Z_][a-zA-Z0-9_]*)>"
)

RulePart = tuple[Any, ...]


def parse_rule(rule: str, converters: ConverterRegistry) -> list[RulePart]:
    """Split a rule into ``("literal", text)`` and ``("dynamic", name, converter)`` parts.

    Raises
    ------
    RoutingError
        On malformed rules (unbalanced ``<>``, duplicate variable names, ...).
    """
    if not isinstance(rule, str):
        raise RoutingError(f"Rule must be a string, got {type(rule).__name__}.")
    if not rule.startswith("/"):
        raise RoutingError(f"Rule {rule!r} must start with a leading '/'.")
    parts: list[RulePart] = []
    position = 0
    seen_names: set[str] = set()

    def check_literal(literal: str) -> None:
        if "<" in literal or ">" in literal:
            raise RoutingError(f"Malformed rule {rule!r}: unbalanced angle brackets.")

    while position < len(rule):
        match = _PART_RE.search(rule, position)
        if match is None:
            literal = rule[position:]
            check_literal(literal)
            if literal:
                parts.append(("literal", literal))
            break
        literal = rule[position : match.start()]
        check_literal(literal)
        if literal:
            parts.append(("literal", literal))
        name = match.group("name")
        if name in seen_names:
            raise RoutingError(f"Duplicate variable name {name!r} in rule {rule!r}.")
        seen_names.add(name)
        converter_name = match.group("converter") or "string"
        converter_cls = converters[converter_name]
        raw_args = match.group("args")
        args = [item.strip() for item in raw_args.split(",")] if raw_args else []
        try:
            converter = converter_cls(args)
        except (TypeError, ValueError) as exc:
            raise RoutingError(f"Invalid converter in rule {rule!r}: {exc}") from exc
        parts.append(("dynamic", name, converter))
        position = match.end()

    if not parts:
        parts.append(("literal", "/"))
    return parts


@dataclass
class Rule:
    """A single URL rule bound to an endpoint name and a set of methods."""

    rule: str
    endpoint: str
    methods: frozenset[str] = field(default_factory=frozenset)
    defaults: dict[str, Any] = field(default_factory=dict)
    strict_slashes: bool = True
    parts: list[RulePart] = field(default_factory=list)
    regex: re.Pattern[str] | None = None
    build_only: bool = False
    _order: int = 0

    def __post_init__(self) -> None:
        if not self.endpoint:
            raise RoutingError("A rule needs a non-empty endpoint name.")

    def compile(self) -> re.Pattern[str]:
        """Compile (or return the cached) regular expression for this rule."""
        if self.regex is not None:
            return self.regex
        pattern_parts: list[str] = []
        for part in self.parts:
            if part[0] == "literal":
                pattern_parts.append(re.escape(part[1]))
            else:
                _kind, name, converter = part[:3]
                pattern_parts.append(f"(?P<{name}>{converter.get_pattern()})")
        pattern = "^" + "".join(pattern_parts) + "$"
        self.regex = re.compile(pattern, re.UNICODE)
        return self.regex

    # -- matching ---------------------------------------------------------
    def match(self, path: str) -> dict[str, Any] | None:
        """Match *path* and return converted arguments, or ``None``."""
        match = self.compile().match(path)
        if match is None and not self.strict_slashes and path != "/":
            # ``strict_slashes=False`` accepts both spellings of the URL.
            alternative = path[:-1] if path.endswith("/") else path + "/"
            match = self.compile().match(alternative)
        if match is None:
            return None
        values: dict[str, Any] = {}
        for key, raw in match.groupdict().items():
            converter = self._converter_for(key)
            try:
                values[key] = converter.to_python(raw) if converter else raw
            except (ValueError, TypeError) as exc:
                raise NotFound() from exc
        merged = dict(self.defaults)
        merged.update(values)
        return merged

    def _converter_for(self, name: str) -> BaseConverter | None:
        for part in self.parts:
            if part[0] == "dynamic" and part[1] == name:
                converter: BaseConverter = part[2]
                return converter
        return None

    @property
    def allowed_methods(self) -> frozenset[str]:
        """Methods this rule accepts (``HEAD`` is implied by ``GET``)."""
        methods = set(self.methods)
        if "GET" in methods:
            methods.add("HEAD")
        methods.add("OPTIONS")
        return frozenset(methods)

    # -- building ---------------------------------------------------------
    def build(
        self, values: Mapping[str, Any], append_unknown: bool = True
    ) -> tuple[str, list[tuple[str, str]]]:
        """Build a path from *values*; leftover values become a query string."""
        remaining = dict(values)
        chunks: list[str] = []
        for part in self.parts:
            if part[0] == "literal":
                chunks.append(part[1])
            else:
                _kind, name, converter = part[:3]
                if name in remaining:
                    value = remaining.pop(name)
                elif name in self.defaults:
                    value = self.defaults[name]
                else:
                    raise RoutingError(
                        f"Cannot build URL for endpoint {self.endpoint!r}: "
                        f"missing value for {name!r}."
                    )
                if value is None:
                    raise RoutingError(
                        f"Cannot build URL for endpoint {self.endpoint!r}: {name!r} is None."
                    )
                chunks.append(converter.to_url(value))
        query: list[tuple[str, str]] = []
        if append_unknown:
            for key, value in remaining.items():
                if value is None:
                    continue
                if isinstance(value, (list, tuple)):
                    query.extend((str(key), str(item)) for item in value)
                else:
                    query.append((str(key), str(value)))
        return "".join(chunks), query

    def __repr__(self) -> str:  # pragma: no cover - debugging convenience
        return f"<Rule {self.rule!r} -> {self.endpoint!r} methods={sorted(self.methods)}>"


@dataclass
class MatchResult:
    """The outcome of :meth:`Map.match`."""

    rule: Rule | None
    arguments: dict[str, Any]
    redirect_path: str | None = None
    allowed_methods: frozenset[str] = frozenset()


class Map:
    """A collection of :class:`Rule` objects with matching and building logic."""

    def __init__(self, converters: ConverterRegistry | None = None) -> None:
        self.converters = converters or ConverterRegistry()
        self._rules: list[Rule] = []
        self._rules_by_endpoint: dict[str, list[Rule]] = {}
        self._sorted: list[Rule] | None = None
        self._order = 0

    # -- registration -----------------------------------------------------
    def add(
        self,
        rule: str,
        endpoint: str,
        methods: Iterable[str] | None = None,
        defaults: Mapping[str, Any] | None = None,
        strict_slashes: bool | None = None,
        build_only: bool = False,
    ) -> Rule:
        """Register a rule and return it."""
        if not isinstance(rule, str):
            raise RoutingError(f"Rule must be a string, got {type(rule).__name__}.")
        if rule == "":
            raise RoutingError("Rule must not be empty; use '/' for the site root.")
        if "?" in rule or "#" in rule:
            raise RoutingError(f"Rule {rule!r} must not contain a query string or fragment.")
        parts = parse_rule(rule, self.converters)

        normalised_methods = self._normalise_methods(methods)
        for existing in self._rules_by_endpoint.get(endpoint, []):
            if existing.rule == rule and existing.methods == normalised_methods:
                raise RoutingError(
                    f"Endpoint {endpoint!r} is already registered for rule {rule!r} "
                    f"with methods {sorted(normalised_methods)}."
                )

        self._order += 1
        new_rule = Rule(
            rule=rule,
            endpoint=endpoint,
            methods=normalised_methods,
            defaults=dict(defaults or {}),
            strict_slashes=True if strict_slashes is None else strict_slashes,
            parts=parts,
            build_only=build_only,
            _order=self._order,
        )
        new_rule.compile()
        self._rules.append(new_rule)
        self._rules_by_endpoint.setdefault(endpoint, []).append(new_rule)
        self._sorted = None
        return new_rule

    @staticmethod
    def _normalise_methods(methods: Iterable[str] | None) -> frozenset[str]:
        if methods is None:
            return frozenset({"GET"})
        if isinstance(methods, str):
            methods = [methods]
        normalised = {str(method).upper() for method in methods}
        if not normalised:
            raise RoutingError("At least one HTTP method is required.")
        unknown = normalised - HTTP_METHODS
        if unknown:
            raise RoutingError(
                f"Unknown HTTP method(s): {', '.join(sorted(unknown))}. "
                f"Supported: {', '.join(sorted(HTTP_METHODS))}."
            )
        if "GET" in normalised:
            # A GET endpoint can always answer HEAD (RFC 9110 §9.3.2).
            normalised.add("HEAD")
        return frozenset(normalised)

    # -- matching ---------------------------------------------------------
    def _sorted_rules(self) -> list[Rule]:
        if self._sorted is None:

            def sort_key(item: tuple[int, Rule]) -> tuple[int, int, int]:
                index, rule = item
                dynamic = sum(1 for part in rule.parts if part[0] == "dynamic")
                literal = sum(len(part[1]) for part in rule.parts if part[0] == "literal")
                return (dynamic, -literal, index)

            self._sorted = [rule for _index, rule in sorted(enumerate(self._rules), key=sort_key)]
        return self._sorted

    def match(self, path: str, method: str = "GET") -> MatchResult:
        """Match *path*/*method*.

        Returns a :class:`MatchResult`; ``rule is None`` plus ``redirect_path``
        means the client should be redirected, and ``rule is None`` without a
        redirect means nothing matched at all.

        Several rules may share the same URL with different methods (e.g. a
        ``GET`` and a ``POST`` handler); all of them are considered before a
        ``405`` is reported, so the ``Allow`` header is complete.
        """
        method = method.upper()
        redirect_candidates: list[str] = []
        allowed: set[str] = set()
        for rule in self._sorted_rules():
            if rule.build_only:
                continue
            arguments = rule.match(path)
            if arguments is not None:
                if method in rule.allowed_methods:
                    return MatchResult(rule=rule, arguments=arguments)
                allowed |= rule.allowed_methods
                continue
            if rule.strict_slashes:
                alternative = self._slash_alternative(path)
                if alternative is not None and rule.match(alternative) is not None:
                    if method in rule.allowed_methods:
                        redirect_candidates.append(alternative)
                    else:
                        allowed |= rule.allowed_methods
        if allowed:
            return MatchResult(rule=None, arguments={}, allowed_methods=frozenset(allowed))
        if redirect_candidates:
            return MatchResult(rule=None, arguments={}, redirect_path=redirect_candidates[0])
        return MatchResult(rule=None, arguments={})

    @staticmethod
    def _slash_alternative(path: str) -> str | None:
        if path == "/":
            return None
        if path.endswith("/"):
            return path[:-1] or "/"
        return path + "/"

    def resolve(self, path: str, method: str = "GET") -> tuple[Rule, dict[str, Any]]:
        """Match or raise ``NotFound`` / ``MethodNotAllowed`` / ``RequestRedirect``."""
        result = self.match(path, method)
        if result.redirect_path is not None:
            raise RequestRedirect(result.redirect_path)
        if result.rule is None:
            if result.allowed_methods:
                raise MethodNotAllowed(result.allowed_methods)
            raise NotFound()
        return result.rule, result.arguments

    # -- building ---------------------------------------------------------
    def build(
        self,
        endpoint: str,
        values: Mapping[str, Any] | None = None,
        append_unknown: bool = True,
        url_prefix: str = "",
    ) -> str:
        """Build a URL path for *endpoint* (``PATH_INFO`` form, no host)."""
        values = dict(values or {})
        rules = self._rules_by_endpoint.get(endpoint)
        if not rules:
            known = ", ".join(sorted(self._rules_by_endpoint)) or "<none>"
            raise RoutingError(
                f"Could not build URL for endpoint {endpoint!r}: no such endpoint. "
                f"Known endpoints: {known}."
            )
        errors: list[str] = []
        for rule in rules:
            try:
                path, query = rule.build(values, append_unknown=append_unknown)
            except (RoutingError, ValueError) as exc:
                errors.append(str(exc))
                continue
            if query:
                from urllib.parse import urlencode

                path = f"{path}?{urlencode(query)}"
            return url_prefix + path
        raise RoutingError(
            f"Could not build URL for endpoint {endpoint!r} with values {values!r}. "
            + "; ".join(errors)
        )

    def __iter__(self) -> Iterator[Rule]:
        return iter(self._rules)

    def __len__(self) -> int:
        return len(self._rules)

    def __repr__(self) -> str:  # pragma: no cover - debugging convenience
        return f"<Map {len(self._rules)} rules>"


# Re-exported for convenience in user code: ``from myframework.routing import route``.
def route(
    rule: str,
    methods: Iterable[str] | None = None,
    defaults: Mapping[str, Any] | None = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """A framework-independent decorator that tags a view function.

    The application picks the tagged functions up when they are registered::

        @app.route("/")            # convenience wrapper around this helper
        def index(): ...
    """

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        routes: list[Any] | None = getattr(func, "__myframework_routes__", None)
        if routes is None:
            routes = []
            func.__myframework_routes__ = routes  # type: ignore[attr-defined]
        routes.append((rule, methods, defaults))
        return func

    return decorator
