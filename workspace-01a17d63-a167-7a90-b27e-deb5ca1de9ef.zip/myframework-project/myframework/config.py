"""Configuration system: defaults, environment variables and config files.

Configuration is a plain ``dict`` with attribute access, which keeps it easy to
inspect, dump and override in tests.  Three sources are supported and applied
in this order (later wins):

1. The framework defaults in :data:`DEFAULTS`.
2. A configuration file (:meth:`Config.from_file`, JSON or TOML) or an object
   of module-level constants (:meth:`Config.from_object`).
3. Environment variables (:meth:`Config.from_env`), e.g.
   ``MYFRAMEWORK_DEBUG=1``.

All keys are documented in ``README.md``; the ones that change behaviour most
are ``DEBUG``, ``MAX_CONTENT_LENGTH``, ``STATIC_DIR``, ``TEMPLATE_DIR`` and
``PREFERRED_URL_SCHEME``.
"""

from __future__ import annotations

import json
import os
import sys
from collections.abc import Iterable, Iterator, Mapping, MutableMapping
from typing import Any

from .exceptions import ConfigurationError

__all__ = ["DEFAULTS", "Config", "ConfigAttribute", "load_config"]


#: Framework defaults.  Every key can be overridden by the application.
DEFAULTS: dict[str, Any] = {
    # -- debugging / behaviour -------------------------------------------
    "DEBUG": False,
    "TESTING": False,
    "PROPAGATE_EXCEPTIONS": None,  # None -> same as TESTING or DEBUG
    "TRAP_HTTP_EXCEPTIONS": False,
    "TRAP_BAD_REQUEST_ERRORS": False,
    "PREFERRED_URL_SCHEME": "http",
    "APPLICATION_ROOT": "/",
    "SERVER_NAME": None,
    # -- request limits ---------------------------------------------------
    "MAX_CONTENT_LENGTH": 16 * 1024 * 1024,  # 16 MiB
    "MAX_FORM_MEMORY_SIZE": 512 * 1024,  # per form field, in memory
    # -- static files -----------------------------------------------------
    "STATIC_DIR": None,  # None -> "<app root>/static"
    "STATIC_URL_PATH": "/static",
    "SEND_FILE_MAX_AGE": 3600,  # seconds; 0 disables caching headers
    "STRICT_SLASHES": True,
    # -- templates --------------------------------------------------------
    "TEMPLATE_DIR": None,  # None -> "<app root>/templates"
    "TEMPLATES_AUTO_RELOAD": None,  # None -> same as DEBUG
    "EXPLAIN_TEMPLATE_LOADING": False,
    "TEMPLATE_UNDEFINED": "strict",  # "strict" or "lenient"
    # -- security ---------------------------------------------------------
    "SECRET_KEY": None,
    "SESSION_COOKIE_NAME": "session",
    "SESSION_COOKIE_SECURE": False,
    "SESSION_COOKIE_HTTPONLY": True,
    "SESSION_COOKIE_SAMESITE": "Lax",
    "TRUSTED_HOSTS": None,  # None -> accept any Host header
    "PREFERRED_HOST": None,
    # -- logging ----------------------------------------------------------
    "LOG_LEVEL": "INFO",
    "ACCESS_LOG": True,
    "SECRET_KEY_FALLBACKS": (),
}

#: Keys whose values are boolean-ish when read from the environment.
_BOOL_KEYS = {
    "DEBUG",
    "TESTING",
    "TRAP_HTTP_EXCEPTIONS",
    "TRAP_BAD_REQUEST_ERRORS",
    "TEMPLATES_AUTO_RELOAD",
    "EXPLAIN_TEMPLATE_LOADING",
    "ACCESS_LOG",
    "SESSION_COOKIE_SECURE",
    "SESSION_COOKIE_HTTPONLY",
    "STRICT_SLASHES",
}
_INT_KEYS = {"MAX_CONTENT_LENGTH", "MAX_FORM_MEMORY_SIZE", "SEND_FILE_MAX_AGE"}

_TRUTHY = {"1", "true", "yes", "on", "y", "t"}
_FALSY = {"0", "false", "no", "off", "n", "f", ""}


def _coerce(key: str, raw: str) -> Any:
    """Coerce an environment string into the type implied by *key*."""
    if key in _BOOL_KEYS:
        lowered = raw.strip().lower()
        if lowered in _TRUTHY:
            return True
        if lowered in _FALSY:
            return False
        raise ConfigurationError(f"Invalid boolean for {key}: {raw!r}")
    if key in _INT_KEYS:
        try:
            return int(raw)
        except ValueError:
            raise ConfigurationError(f"Invalid integer for {key}: {raw!r}") from None
    if key == "TRUSTED_HOSTS" or key == "SECRET_KEY_FALLBACKS":
        return [item.strip() for item in raw.split(",") if item.strip()]
    return raw


class Config(MutableMapping[str, Any]):
    """Application configuration.

    >>> config = Config()
    >>> config["DEBUG"]
    False
    >>> config.DEBUG = True
    >>> config.DEBUG
    True
    """

    def __init__(
        self,
        defaults: Mapping[str, Any] | None = None,
        overrides: Mapping[str, Any] | None = None,
    ) -> None:
        self._data: dict[str, Any] = dict(DEFAULTS)
        if defaults:
            self._data.update(defaults)
        if overrides:
            self.update(overrides)

    # -- mapping protocol -------------------------------------------------
    def __getitem__(self, key: str) -> Any:
        try:
            return self._data[key]
        except KeyError:
            raise KeyError(
                f"Unknown configuration key {key!r}. Known keys: {', '.join(sorted(self._data))}."
            ) from None

    def __setitem__(self, key: str, value: Any) -> None:
        self._data[str(key)] = value

    def __delitem__(self, key: str) -> None:
        del self._data[key]

    def __iter__(self) -> Iterator[str]:
        return iter(self._data)

    def __len__(self) -> int:
        return len(self._data)

    def __contains__(self, key: object) -> bool:
        return key in self._data

    def __getattr__(self, name: str) -> Any:
        # Only called when normal attribute lookup fails.
        if name.startswith("_"):
            raise AttributeError(name)
        try:
            return self._data[name]
        except KeyError:
            raise AttributeError(
                f"Configuration has no attribute {name!r}. Known keys: "
                f"{', '.join(sorted(self._data))}."
            ) from None

    def __setattr__(self, name: str, value: Any) -> None:
        if name.startswith("_"):
            object.__setattr__(self, name, value)
        else:
            self._data[name] = value

    def __repr__(self) -> str:
        public = {key: value for key, value in self._data.items() if "SECRET" not in key}
        return f"Config({public!r})"

    # -- loading ----------------------------------------------------------
    def update(self, *args: Any, **kwargs: Any) -> None:
        """Update the configuration from a mapping, pairs, or keyword arguments."""
        for mapping in args:
            if hasattr(mapping, "items"):
                for key, value in mapping.items():
                    self._data[str(key).upper()] = value
            else:
                for key, value in mapping:
                    self._data[str(key).upper()] = value
        for key, value in kwargs.items():
            self._data[str(key).upper()] = value

    def from_mapping(self, *args: Any, **kwargs: Any) -> list[str]:
        """Like :meth:`update` but returns the names of the keys that changed."""
        before = dict(self._data)
        self.update(*args, **kwargs)
        return [key for key in self._data if before.get(key, object()) != self._data[key]]

    def from_object(self, obj: Any) -> None:
        """Load upper-case attributes from a module or class."""
        if isinstance(obj, str):
            obj = self._import_object(obj)
        for name in dir(obj):
            if name.isupper():
                self._data[name] = getattr(obj, name)

    def from_env(
        self, prefix: str = "MYFRAMEWORK_", environ: Mapping[str, str] | None = None
    ) -> list[str]:
        """Load settings from environment variables such as ``MYFRAMEWORK_DEBUG=1``."""
        environ = os.environ if environ is None else environ
        changed: list[str] = []
        for key, raw in environ.items():
            if not key.startswith(prefix):
                continue
            name = key[len(prefix) :].upper()
            self._data[name] = _coerce(name, raw)
            changed.append(name)
        return changed

    def from_file(self, path: str | os.PathLike[str]) -> None:
        """Load a JSON or TOML configuration file.

        ``.json`` files are read with the standard library.  TOML requires
        Python 3.11+ (or the ``tomli`` backport on older versions).
        """
        file_path = os.fspath(path)
        if not os.path.isfile(file_path):
            raise ConfigurationError(f"Configuration file not found: {file_path}")
        suffix = os.path.splitext(file_path)[1].lower()
        if suffix == ".json":
            with open(file_path, encoding="utf-8") as handle:
                try:
                    data = json.load(handle)
                except json.JSONDecodeError as exc:
                    raise ConfigurationError(f"Invalid JSON in {file_path}: {exc}") from None
        elif suffix == ".toml":
            data = self._load_toml(file_path)
        else:
            raise ConfigurationError(
                f"Unsupported configuration file type {suffix!r}; use .json or .toml."
            )
        if not isinstance(data, dict):
            raise ConfigurationError(f"Configuration file {file_path} must contain an object.")
        # Allow an optional [myframework] table in TOML files.
        if "myframework" in data and isinstance(data["myframework"], dict):
            data = data["myframework"]
        self.update(data)

    @staticmethod
    def _load_toml(file_path: str) -> dict[str, Any]:
        try:
            if sys.version_info >= (3, 11):
                import tomllib
            else:  # pragma: no cover - exercised only on Python < 3.11
                import tomli as tomllib  # type: ignore[import-not-found]
        except ImportError:  # pragma: no cover
            raise ConfigurationError(
                "Reading TOML configuration requires Python 3.11+ or 'pip install tomli'."
            ) from None
        with open(file_path, "rb") as handle:
            try:
                parsed: dict[str, Any] = tomllib.load(handle)
                return parsed
            except tomllib.TOMLDecodeError as exc:
                raise ConfigurationError(f"Invalid TOML in {file_path}: {exc}") from None

    @staticmethod
    def _import_object(path: str) -> Any:
        import importlib

        module_name, _, attribute = path.rpartition(".")
        if not module_name:
            # A plain module name: use the module itself.
            try:
                return importlib.import_module(path)
            except ImportError as exc:
                raise ConfigurationError(
                    f"Cannot import configuration module {path!r}: {exc}"
                ) from None
        try:
            module = importlib.import_module(module_name)
        except ImportError as exc:
            raise ConfigurationError(
                f"Cannot import configuration module {module_name!r}: {exc}"
            ) from None
        try:
            return getattr(module, attribute)
        except AttributeError:
            raise ConfigurationError(
                f"Module {module_name!r} has no attribute {attribute!r}."
            ) from None

    # -- helpers ----------------------------------------------------------
    def setdefault(self, key: str, default: Any = None) -> Any:
        return self._data.setdefault(key, default)

    def copy(self) -> Config:
        """Return an independent copy."""
        return Config(overrides=self._data)

    def get_bool(self, key: str, default: bool = False) -> bool:
        """Read a boolean setting."""
        value = self._data.get(key, default)
        return bool(value)

    def get_int(self, key: str, default: int = 0) -> int:
        """Read an integer setting, raising on invalid values."""
        value = self._data.get(key, default)
        try:
            return int(value)
        except (TypeError, ValueError):
            raise ConfigurationError(
                f"Configuration {key} must be an integer, got {value!r}."
            ) from None

    def get_list(self, key: str) -> list[str]:
        """Read a comma separated or list-like setting as a list of strings."""
        value = self._data.get(key)
        if value is None:
            return []
        if isinstance(value, str):
            return [item.strip() for item in value.split(",") if item.strip()]
        if isinstance(value, Iterable):
            return [str(item) for item in value]
        return [str(value)]

    def as_dict(self, hide_secrets: bool = True) -> dict[str, Any]:
        """Return a plain dict, optionally masking secret values."""
        result = dict(self._data)
        if hide_secrets:
            for key in list(result):
                if "SECRET" in key or "PASSWORD" in key or "TOKEN" in key:
                    result[key] = "***" if result[key] else None
        # Make the dict JSON friendly for the /debug page and logs.
        for key, value in result.items():
            if isinstance(value, (set, frozenset, tuple)):
                result[key] = list(value)
        return result


class ConfigAttribute:
    """Descriptor exposing a :class:`Config` key as an attribute on an app.

    >>> class Fake:
    ...     config = Config()
    ...     debug = ConfigAttribute("DEBUG")
    >>> Fake().debug
    False
    """

    def __init__(self, key: str) -> None:
        self.key = key
        self.__doc__ = f"Configuration value for {key}."

    def __get__(self, obj: Any, owner: type | None = None) -> Any:
        if obj is None:
            return self
        return obj.config[self.key]

    def __set__(self, obj: Any, value: Any) -> None:
        obj.config[self.key] = value


def load_config(
    overrides: Mapping[str, Any] | None = None,
    env_prefix: str | None = None,
    file: str | os.PathLike[str] | None = None,
    obj: Any = None,
) -> Config:
    """Build a :class:`Config` from the usual sources in the documented order."""
    config = Config()
    if obj is not None:
        config.from_object(obj)
    if file is not None:
        config.from_file(file)
    if env_prefix is not None:
        config.from_env(env_prefix)
    if overrides:
        config.update(overrides)
    return config
