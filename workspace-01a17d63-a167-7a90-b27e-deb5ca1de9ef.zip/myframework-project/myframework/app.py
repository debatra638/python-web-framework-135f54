"""The application object: routing, dispatch, hooks, errors and the WSGI entry point.

Request lifecycle
-----------------
1. The WSGI server calls ``app(environ, start_response)``.
2. A :class:`~myframework.request.Request` is built and a context is pushed so
   the ``request``/``g``/``current_app`` proxies work.
3. URL matching (405/404/redirect decisions happen here).
4. ``before_request`` hooks run in registration order; a non-``None`` return
   value short-circuits the view.
5. The view runs and its return value is converted with
   :func:`~myframework.response.make_response`.
6. ``after_request`` hooks run in reverse order, then ``teardown_request``.
7. Exceptions are converted by registered error handlers, ``HTTPException``
   instances, or a safe ``500`` page (a traceback page in debug mode).

Everything in this class is thread-safe for read-only use after startup; the
per-request state lives in :mod:`contextvars`, so one ``App`` instance can be
shared by a multi-threaded or multi-process server.
"""

from __future__ import annotations

import logging
import os
import sys
import traceback
from collections.abc import Callable, Iterable, Iterator, Mapping
from contextlib import contextmanager
from typing import Any

from .config import Config, ConfigAttribute
from .exceptions import (
    BadRequest,
    ConfigurationError,
    FrameworkException,
    HTTPException,
    InternalServerError,
    NotFound,
    PayloadTooLarge,
    RequestRedirect,
    RoutingError,
    SecurityError,
    TemplateNotFound,
)
from .globals import AppContext, RequestContext, current_app, g, request
from .middleware import WSGIMiddleware
from .request import Request
from .response import Response, jsonify, make_response, redirect
from .routing import BaseConverter, Map, Rule
from .static import StaticFiles
from .templates import DictLoader, FileSystemLoader
from .templates import Environment as TemplateEnvironment
from .utils import escape
from .wsgi import Environ, StartResponse, WSGIApp

__all__ = ["App"]

ErrorHandler = Callable[..., Any]
ViewFunction = Callable[..., Any]

_HTTP_METHODS_WITHOUT_BODY = frozenset({"GET", "HEAD", "OPTIONS", "TRACE"})


class App:
    """A MyFramework application — also a WSGI application.

    Parameters
    ----------
    import_name:
        The ``__name__`` of the module that creates the app.  Used to locate
        ``static/`` and ``templates/`` next to it, and for the logger name.
    static_dir / template_dir:
        Override the directories detected from ``import_name``.
    config:
        Mapping of configuration overrides, applied on top of the defaults.
    **config_overrides:
        Convenience form, e.g. ``App(__name__, DEBUG=True)``.
    """

    #: Class used to build request objects (override to subclass).
    request_class = Request
    #: Class used to build response objects.
    response_class = Response

    debug = ConfigAttribute("DEBUG")
    testing = ConfigAttribute("TESTING")

    def __init__(
        self,
        import_name: str | None = None,
        *,
        static_dir: str | os.PathLike[str] | bool | None = None,
        template_dir: str | os.PathLike[str] | None = None,
        config: Mapping[str, Any] | None = None,
        **config_overrides: Any,
    ) -> None:
        self.import_name = import_name or "__main__"
        self.root_path = self._detect_root_path(self.import_name)
        self.config = Config()
        if config:
            self.config.update(config)
        if config_overrides:
            self.config.update(config_overrides)
        self.serve_static = True
        if static_dir is False:
            # Explicitly disable the built-in static handler.
            self.serve_static = False
            self.config["STATIC_DIR"] = None
        elif static_dir is not None:
            self.config["STATIC_DIR"] = os.fspath(str(static_dir))
        if template_dir is not None:
            self.config["TEMPLATE_DIR"] = os.fspath(template_dir)
        # ``None`` means "use the conventional directory next to the app module".
        if self.serve_static and self.config.get("STATIC_DIR") is None:
            self.config["STATIC_DIR"] = os.path.join(self.root_path, "static")
        if self.config.get("TEMPLATE_DIR") is None:
            self.config["TEMPLATE_DIR"] = os.path.join(self.root_path, "templates")

        self.url_map = Map()
        self.view_functions: dict[str, ViewFunction] = {}
        self.before_request_funcs: list[ViewFunction] = []
        self.after_request_funcs: list[ViewFunction] = []
        self.teardown_request_funcs: list[ViewFunction] = []
        self.error_handlers: dict[Any, ErrorHandler] = {}
        self.context_processors: list[Callable[[], Mapping[str, Any]]] = []
        self._middlewares: list[Any] = []
        self._wsgi_pipeline: WSGIApp | None = None
        self._template_env: TemplateEnvironment | None = None

        self.logger = logging.getLogger(f"myframework.app.{self.import_name}")
        self._configure_logging()

        self._validate_config()
        self._register_static_route()

    # -- construction helpers ---------------------------------------------
    @staticmethod
    def _detect_root_path(import_name: str) -> str:
        module = sys.modules.get(import_name)
        filename = getattr(module, "__file__", None)
        if isinstance(filename, str) and filename:
            return os.path.dirname(os.path.abspath(filename))
        return os.getcwd()

    def _configure_logging(self) -> None:
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(
                logging.Formatter("[%(asctime)s] %(levelname)s in %(name)s: %(message)s")
            )
            self.logger.addHandler(handler)
        level_name = str(self.config.get("LOG_LEVEL", "INFO")).upper()
        level = getattr(logging, level_name, None)
        if not isinstance(level, int):
            raise ConfigurationError(
                f"Invalid LOG_LEVEL {level_name!r}; use DEBUG, INFO, WARNING, ERROR or CRITICAL."
            )
        self.logger.setLevel(level)

    def _validate_config(self) -> None:
        max_length = self.config.get("MAX_CONTENT_LENGTH")
        if max_length is not None and (not isinstance(max_length, int) or max_length < 0):
            raise ConfigurationError("MAX_CONTENT_LENGTH must be a non-negative int or None.")
        static_url = self.config.get("STATIC_URL_PATH")
        if not isinstance(static_url, str) or not static_url.startswith("/"):
            raise ConfigurationError("STATIC_URL_PATH must be a string starting with '/'.")
        if self.config.get("TEMPLATE_UNDEFINED") not in ("strict", "lenient"):
            raise ConfigurationError("TEMPLATE_UNDEFINED must be 'strict' or 'lenient'.")

    def _register_static_route(self) -> None:
        if getattr(self, "serve_static", True) is False:
            return
        url_path = str(self.config["STATIC_URL_PATH"]).rstrip("/") or "/static"
        self.config["STATIC_URL_PATH"] = url_path

        def _static(filename: str) -> Response:
            static_files = self.static_files
            try:
                return static_files.handle(filename, request.environ)
            except SecurityError:
                # Do not disclose why the path was rejected.
                raise NotFound() from None

        self.add_url_rule(
            f"{url_path}/<path:filename>",
            endpoint="static",
            view_func=_static,
        )

    # -- configuration ----------------------------------------------------
    @property
    def name(self) -> str:
        """The application's import name."""
        return self.import_name

    @property
    def static_files(self) -> StaticFiles:
        """The :class:`~myframework.static.StaticFiles` handler for ``STATIC_DIR``."""
        directory = self.config.get("STATIC_DIR")
        return StaticFiles(
            directory,
            url_path=str(self.config["STATIC_URL_PATH"]),
            max_age=self.config.get_int("SEND_FILE_MAX_AGE", 3600),
        )

    @property
    def template_env(self) -> TemplateEnvironment:
        """The template environment (created on first use)."""
        if self._template_env is None:
            directory = self.config.get("TEMPLATE_DIR")
            # Without a directory we still build an environment so that
            # ``render_template_string`` works; file templates raise a clear
            # TemplateNotFound with an empty search list.
            loader = FileSystemLoader(directory) if directory else DictLoader({})
            auto_reload = self.config.get("TEMPLATES_AUTO_RELOAD")
            self._template_env = TemplateEnvironment(
                loader=loader,
                autoescape=True,
                undefined=str(self.config.get("TEMPLATE_UNDEFINED", "strict")),
                auto_reload=bool(self.debug if auto_reload is None else auto_reload),
                globals={
                    "url_for": self.url_for,
                    "config": self.config,
                    "g": g,
                    "app": self,
                },
            )
        return self._template_env

    # -- routing ----------------------------------------------------------
    def route(
        self,
        rule: str,
        methods: Iterable[str] | None = None,
        endpoint: str | None = None,
        defaults: Mapping[str, Any] | None = None,
        strict_slashes: bool | None = None,
    ) -> Callable[[ViewFunction], ViewFunction]:
        """Decorator registering a view function for *rule*.

        >>> app = App(__name__)                        # doctest: +SKIP
        >>> @app.route("/", methods=["GET"])           # doctest: +SKIP
        ... def index():
        ...     return "<h1>Hello</h1>"
        """
        if methods is not None and not isinstance(methods, (str, list, tuple, set, frozenset)):
            raise TypeError(
                f"methods must be a list of strings or a string, got {type(methods).__name__}."
            )

        def decorator(func: ViewFunction) -> ViewFunction:
            self.add_url_rule(
                rule,
                endpoint=endpoint or func.__name__,
                view_func=func,
                methods=methods,
                defaults=defaults,
                strict_slashes=strict_slashes,
            )
            return func

        return decorator

    def add_url_rule(
        self,
        rule: str,
        endpoint: str | None = None,
        view_func: ViewFunction | None = None,
        methods: Iterable[str] | None = None,
        defaults: Mapping[str, Any] | None = None,
        strict_slashes: bool | None = None,
    ) -> Rule:
        """Register a URL rule (the non-decorator form of :meth:`route`)."""
        if methods is not None and not isinstance(methods, (str, list, tuple, set, frozenset)):
            raise TypeError(
                f"methods must be a list of strings or a string, got {type(methods).__name__}."
            )
        if endpoint is None:
            if view_func is None:
                raise TypeError("add_url_rule needs an endpoint name or a view function.")
            endpoint = view_func.__name__
        if view_func is not None:
            existing = self.view_functions.get(endpoint)
            if existing is not None and existing is not view_func:
                raise RoutingError(
                    f"Endpoint {endpoint!r} is already bound to {existing!r}; "
                    "provide a unique endpoint name."
                )
            self.view_functions[endpoint] = view_func
        if strict_slashes is None:
            strict_slashes = bool(self.config.get("STRICT_SLASHES", True))
        return self.url_map.add(
            rule,
            endpoint=endpoint,
            methods=methods,
            defaults=defaults,
            strict_slashes=strict_slashes,
        )

    def get(self, rule: str, **kwargs: Any) -> Callable[[ViewFunction], ViewFunction]:
        """Shortcut for ``@app.route(rule, methods=["GET"])``."""
        return self.route(rule, methods=["GET"], **kwargs)

    def post(self, rule: str, **kwargs: Any) -> Callable[[ViewFunction], ViewFunction]:
        """Shortcut for ``@app.route(rule, methods=["POST"])``."""
        return self.route(rule, methods=["POST"], **kwargs)

    def put(self, rule: str, **kwargs: Any) -> Callable[[ViewFunction], ViewFunction]:
        """Shortcut for ``@app.route(rule, methods=["PUT"])``."""
        return self.route(rule, methods=["PUT"], **kwargs)

    def patch(self, rule: str, **kwargs: Any) -> Callable[[ViewFunction], ViewFunction]:
        """Shortcut for ``@app.route(rule, methods=["PATCH"])``."""
        return self.route(rule, methods=["PATCH"], **kwargs)

    def delete(self, rule: str, **kwargs: Any) -> Callable[[ViewFunction], ViewFunction]:
        """Shortcut for ``@app.route(rule, methods=["DELETE"])``."""
        return self.route(rule, methods=["DELETE"], **kwargs)

    def url_for(
        self,
        endpoint: str,
        *,
        _external: bool = False,
        _scheme: str | None = None,
        _anchor: str | None = None,
        **values: Any,
    ) -> str:
        """Build the URL for *endpoint*.

        Extra keyword arguments become query-string parameters, or are consumed
        by the rule's converters.  ``_external=True`` produces an absolute URL
        (requires a request context or ``SERVER_NAME``).
        """
        path = self.url_map.build(endpoint, values)
        from .globals import get_current_request, has_request_context

        if has_request_context():
            # URLs are generated relative to where the app is mounted.
            script_name = get_current_request().script_name.rstrip("/")
            if script_name:
                path = f"{script_name}{path}"
        if _anchor:
            path = f"{path}#{_anchor}"
        if not _external:
            return path
        scheme = _scheme or str(self.config.get("PREFERRED_URL_SCHEME", "http"))
        from .globals import get_current_request, has_request_context

        if has_request_context():
            active = get_current_request()
            host = active.host
            script = active.script_name
        else:
            server_name = self.config.get("SERVER_NAME")
            if not server_name:
                raise RuntimeError(
                    "url_for(_external=True) needs a request context or the SERVER_NAME setting."
                )
            host = str(server_name)
            script = str(self.config.get("APPLICATION_ROOT", "/")).rstrip("/")
        return f"{scheme}://{host}{script}{path}"

    def converter(self, name: str) -> Callable[[type[BaseConverter]], type[BaseConverter]]:
        """Register a custom URL converter under *name*."""

        def decorator(cls: type[BaseConverter]) -> type[BaseConverter]:
            self.url_map.converters.register(name, cls)
            return cls

        return decorator

    # -- hooks ------------------------------------------------------------
    def before_request(self, func: ViewFunction) -> ViewFunction:
        """Register a function that runs before the view (in order)."""
        self.before_request_funcs.append(func)
        return func

    def after_request(self, func: ViewFunction) -> ViewFunction:
        """Register a function that receives and returns the response (reverse order)."""
        self.after_request_funcs.append(func)
        return func

    def teardown_request(self, func: ViewFunction) -> ViewFunction:
        """Register a function that always runs at the end of the request."""
        self.teardown_request_funcs.append(func)
        return func

    def context_processor(
        self, func: Callable[[], Mapping[str, Any]]
    ) -> Callable[[], Mapping[str, Any]]:
        """Register a callable whose return value is added to every template context."""
        self.context_processors.append(func)
        return func

    def errorhandler(self, code_or_exception: Any) -> Callable[[ErrorHandler], ErrorHandler]:
        """Register an error handler for a status code or exception class.

        >>> app = App(__name__)                       # doctest: +SKIP
        >>> @app.errorhandler(404)                    # doctest: +SKIP
        ... def not_found(error):
        ...     return "Nothing here", 404
        """

        def decorator(func: ErrorHandler) -> ErrorHandler:
            self.register_error_handler(code_or_exception, func)
            return func

        return decorator

    def register_error_handler(self, code_or_exception: Any, func: ErrorHandler) -> None:
        """Register an error handler without using the decorator."""
        if isinstance(code_or_exception, int):
            self.error_handlers[code_or_exception] = func
            return
        if isinstance(code_or_exception, type) and issubclass(code_or_exception, Exception):
            self.error_handlers[code_or_exception] = func
            return
        raise TypeError(
            "errorhandler expects an HTTP status code (int) or an exception class, "
            f"got {code_or_exception!r}."
        )

    def register_error_handler_instance(self, exc: HTTPException, func: ErrorHandler) -> None:
        """Register a handler for the exact class of *exc*."""
        self.register_error_handler(type(exc), func)

    def template_filter(
        self, name: str | None = None
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        """Register a template filter, e.g. ``@app.template_filter("slug")``."""

        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            self.template_env.filters[name or func.__name__] = func
            return func

        return decorator

    def template_global(self, name: str | None = None) -> Callable[[Any], Any]:
        """Register a template global (function or value)."""

        def decorator(value: Any) -> Any:
            key = name or str(getattr(value, "__name__", ""))
            self.template_env.globals[key] = value
            return value

        return decorator

    def use(self, middleware: Any) -> Any:
        """Add a WSGI middleware layer.

        Accepts a :class:`~myframework.middleware.WSGIMiddleware` instance, a
        subclass (instantiated for you), or a factory ``middleware(app) -> app``.
        Middleware is applied so the first one added is the outermost layer.
        """
        self._middlewares.append(middleware)
        self._wsgi_pipeline = None
        return middleware

    # -- WSGI -------------------------------------------------------------
    @property
    def wsgi_app(self) -> WSGIApp:
        """The WSGI callable for this application (middleware included)."""
        if self._wsgi_pipeline is None:
            self._wsgi_pipeline = self._build_pipeline()
        return self._wsgi_pipeline

    def _build_pipeline(self) -> WSGIApp:
        app: WSGIApp = self._dispatch_wsgi
        for middleware in reversed(self._middlewares):
            candidate = middleware() if isinstance(middleware, type) else middleware
            if isinstance(candidate, WSGIMiddleware):
                if candidate.app is None:
                    candidate.app = app  # bind the layer we built so far
                app = candidate.__call__
            elif callable(candidate):
                app = candidate(app)
            else:  # pragma: no cover - defensive
                raise TypeError(
                    f"{middleware!r} is not valid WSGI middleware. Pass an instance of "
                    "WSGIMiddleware, a subclass, or a callable factory."
                )
        return app

    def __call__(self, environ: Environ, start_response: StartResponse) -> Iterable[bytes]:
        """WSGI entry point (PEP 3333)."""
        return self.wsgi_app(environ, start_response)

    def _dispatch_wsgi(self, environ: Environ, start_response: StartResponse) -> Iterable[bytes]:
        request = self.request_class(
            environ,
            max_content_length=self.config.get("MAX_CONTENT_LENGTH"),
        )
        context = RequestContext(self, request)
        context.push()
        try:
            response = self.full_dispatch_request(request)
            return response.wsgi(environ, start_response)
        finally:
            # The response body is produced after this returns; streaming
            # generators must therefore capture request data before yielding.
            context.pop()

    # -- dispatch ---------------------------------------------------------
    def full_dispatch_request(self, request: Request) -> Response:
        """Run the whole request pipeline and always return a response."""
        error: BaseException | None = None
        try:
            self._check_preferred_host(request)
            self._match_request(request)
            response = self.preprocess_request(request)
            if response is None:
                response = self.dispatch_request(request)
        except Exception as exc:
            error = exc
            response = self.handle_user_exception(exc, request)
        try:
            response = self.process_response(response, request)
        except Exception as exc:
            error = error or exc
            response = self.handle_user_exception(exc, request)
        finally:
            self.do_teardown_request(error)
        return response

    def _check_preferred_host(self, request: Request) -> None:
        preferred = self.config.get("PREFERRED_HOST")
        if not preferred:
            return
        host = request.host.split(":")[0].lower()
        if host != str(preferred).lower():
            self.logger.warning("Rejected request with unexpected Host header %r", request.host)
            raise BadRequest("The Host header is not valid for this application.")

    def _match_request(self, request: Request) -> None:
        rule, arguments = self.url_map.resolve(request.path, request.method)
        request.url_rule = rule
        request.endpoint = rule.endpoint
        request.view_args = arguments

    def preprocess_request(self, request: Request) -> Response | None:
        """Run ``before_request`` hooks; the first response returned wins."""
        for func in self.before_request_funcs:
            result = self._call_hook(func)
            if result is not None:
                return make_response(result)
        return None

    def _call_hook(self, func: ViewFunction) -> Any:
        import inspect

        try:
            signature = inspect.signature(func)
        except (TypeError, ValueError):  # pragma: no cover - builtins
            return func()
        parameters = [
            p
            for p in signature.parameters.values()
            if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)
        ]
        return func(request) if parameters else func()

    def dispatch_request(self, request: Request) -> Response:
        """Call the view function for the matched route."""
        assert request.endpoint is not None
        view = self.view_functions.get(request.endpoint)
        if view is None:  # pragma: no cover - guarded by routing
            raise NotFound(f"No view function registered for endpoint {request.endpoint!r}.")
        rule: Rule | None = getattr(request, "url_rule", None)

        if request.method == "OPTIONS" and rule is not None and "OPTIONS" not in rule.methods:
            response = self.response_class(status=204)
            response.headers["Allow"] = ", ".join(sorted(rule.allowed_methods))
            return response

        return self.make_response(view(**request.view_args), request)

    def make_response(self, value: Any, request: Request | None = None) -> Response:
        """Convert a view return value into a :class:`Response`."""
        response = make_response(value)
        if not isinstance(response, Response):  # pragma: no cover - defensive
            raise FrameworkException(f"Could not convert {value!r} into a Response.")
        return response

    def process_response(self, response: Response, request: Request) -> Response:
        """Run ``after_request`` hooks (reverse order) and default headers."""
        for func in reversed(self.after_request_funcs):
            result = self._call_hook_with(func, response)
            if result is None:
                raise FrameworkException(
                    f"after_request hook {func!r} returned None; it must return the response."
                )
            response = result if isinstance(result, Response) else self.make_response(result)
        if "X-Content-Type-Options" not in response.headers:
            response.headers["X-Content-Type-Options"] = "nosniff"
        return response

    def _call_hook_with(self, func: ViewFunction, response: Response) -> Any:
        import inspect

        try:
            signature = inspect.signature(func)
        except (TypeError, ValueError):  # pragma: no cover - builtins
            return func(response)
        parameters = [
            p
            for p in signature.parameters.values()
            if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)
        ]
        if not parameters:
            return func()
        return func(response) if len(parameters) == 1 else func(response, request)

    def do_teardown_request(self, error: BaseException | None = None) -> None:
        """Run ``teardown_request`` hooks, swallowing nothing but logging errors."""
        for func in reversed(self.teardown_request_funcs):
            try:
                self._call_hook_with_teardown(func, error)
            except Exception:
                self.logger.exception("Error in teardown_request hook %r", func)

    def _call_hook_with_teardown(self, func: ViewFunction, error: BaseException | None) -> None:
        import inspect

        try:
            signature = inspect.signature(func)
        except (TypeError, ValueError):  # pragma: no cover - builtins
            func()
            return
        parameters = [
            p
            for p in signature.parameters.values()
            if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)
        ]
        if not parameters:
            func()
        else:
            func(error)

    # -- errors -----------------------------------------------------------
    def handle_user_exception(self, exc: Exception, request: Request) -> Response:
        """Turn an exception raised during dispatch into a response."""
        if isinstance(exc, RequestRedirect):
            return exc.get_response()

        trap_http = bool(self.config.get("TRAP_HTTP_EXCEPTIONS", False))
        trap_bad_request = bool(self.config.get("TRAP_BAD_REQUEST_ERRORS", False))
        if isinstance(exc, HTTPException):
            if not trap_http and not (trap_bad_request and self._is_bad_request(exc)):
                return self.handle_http_exception(exc)
        elif trap_bad_request and self._is_bad_request(exc):
            pass

        handler = self._find_error_handler(exc)
        if handler is not None:
            return self.finalize_request(handler(exc), request)
        return self.handle_exception(exc)

    @staticmethod
    def _is_bad_request(exc: BaseException) -> bool:
        if isinstance(exc, (BadRequest, PayloadTooLarge)):
            return True
        if isinstance(exc, HTTPException):
            return 400 <= exc.code < 500
        return isinstance(exc, (ValueError, UnicodeError))

    def handle_http_exception(self, exc: HTTPException) -> Response:
        """Render an :class:`HTTPException` with a registered handler if present."""
        handler = self._find_error_handler(exc)
        if handler is not None:
            return make_response(handler(exc))
        return exc.get_response()

    def _find_error_handler(self, exc: BaseException) -> ErrorHandler | None:
        for klass in type(exc).__mro__:
            handler = self.error_handlers.get(klass)
            if handler is not None:
                return handler
        if isinstance(exc, HTTPException):
            return self.error_handlers.get(exc.code)
        return None

    def handle_exception(self, exc: Exception) -> Response:
        """Handle an unhandled exception (500) with logging and safe output."""
        if not isinstance(exc, HTTPException):
            self.log_exception(exc)
        propagate = self.config.get("PROPAGATE_EXCEPTIONS")
        if propagate is None:
            propagate = bool(self.debug or self.testing)
        if propagate:
            raise exc
        if isinstance(exc, HTTPException):
            # Only reached when TRAP_HTTP_EXCEPTIONS is on.
            return exc.get_response()
        if self.debug:
            return self._debug_response(exc)
        return InternalServerError().get_response()

    def log_exception(self, exc: BaseException) -> None:
        """Log an exception with its traceback (or the request id, if any)."""
        request_id = None
        from .globals import get_current_request, has_request_context

        if has_request_context():
            request_id = get_current_request().environ.get("myframework.request_id")
        prefix = f"[request {request_id}] " if request_id else ""
        self.logger.error("%sUnhandled exception: %s", prefix, exc, exc_info=True)

    def _debug_response(self, exc: BaseException) -> Response:
        """A readable traceback page — only ever produced in debug mode."""
        trace = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        details = ""
        try:
            from .globals import get_current_request, has_request_context

            if has_request_context():
                req = get_current_request()
                details = (
                    "<h2>Request</h2><pre>"
                    + escape(f"{req.method} {req.full_path}\n{req.url}")
                    + "</pre>"
                )
        except Exception:  # pragma: no cover - best effort
            details = ""
        body = (
            "<!doctype html><html><head><meta charset='utf-8'>"
            "<title>500 Internal Server Error — debug</title>"
            "<style>body{font-family:monospace;margin:2rem;line-height:1.5}"
            "pre{background:#f6f8fa;padding:1rem;overflow:auto;border-radius:6px}"
            "h1{color:#b3001b}</style></head><body>"
            f"<h1>{escape(type(exc).__name__)}</h1><p>{escape(str(exc))}</p>"
            f"{details}<h2>Traceback</h2><pre>{escape(trace)}</pre>"
            "<p>This page is only shown because DEBUG is enabled.</p></body></html>"
        )
        response = self.response_class(body, status=500, mimetype="text/html; charset=utf-8")
        response.headers["X-Debug-Mode"] = "true"
        return response

    def finalize_request(self, value: Any, request: Request | None = None) -> Response:
        """Convert a handler's return value into a response."""
        return self.make_response(value, request)

    # -- templates --------------------------------------------------------
    def render_template(self, template_name: str, **context: Any) -> str:
        """Render a template file with the request context and processors.

        Raises
        ------
        TemplateNotFound
            With the searched paths, so a typo is easy to diagnose.
        """
        environment = self.template_env
        variables: dict[str, Any] = {
            "request": request,
            "config": self.config,
            "g": g,
            "url_for": self.url_for,
        }
        for processor in self.context_processors:
            produced = processor()
            if produced:
                variables.update(produced)
        variables.update(context)
        try:
            template = environment.get_template(template_name)
        except TemplateNotFound as exc:
            raise TemplateNotFound(
                template_name, environment.loader.list_templates() if environment.loader else []
            ) from exc
        return template.render(variables)

    def render_template_string(self, source: str, **context: Any) -> str:
        """Render a template given as a string."""
        variables: dict[str, Any] = {
            "request": request,
            "config": self.config,
            "g": g,
            "url_for": self.url_for,
        }
        for processor in self.context_processors:
            produced = processor()
            if produced:
                variables.update(produced)
        variables.update(context)
        return self.template_env.from_string(source).render(variables)

    # -- development helpers ----------------------------------------------
    @contextmanager
    def app_context(self) -> Iterator[AppContext]:
        """Push an application context (no request) for scripts and tests."""
        context = AppContext(self)
        context.push()
        try:
            yield context
        finally:
            context.pop()

    def test_client(self, **overrides: Any) -> Any:
        """Return a :class:`~myframework.testing.Client` bound to this app."""
        from .testing import Client

        return Client(self, **overrides)

    def test_request_context(
        self, path: str = "/", method: str = "GET", **kwargs: Any
    ) -> RequestContext:
        """Push a synthetic request context (useful in tests and shell sessions)."""
        from .testing import make_request

        return RequestContext(self, make_request(self, path=path, method=method, **kwargs))

    def run(
        self,
        host: str = "127.0.0.1",
        port: int = 8000,
        debug: bool | None = None,
        reload: bool | None = None,
        threaded: bool = True,
        quiet: bool = False,
    ) -> None:
        """Start the development server.

        ``debug=True`` enables the debugger page, verbose logs and (unless
        disabled) automatic reloading.  Never use this server in production:
        run ``gunicorn -w 4 "module:app"`` or ``waitress-serve`` instead.
        """
        from .devserver import run_dev_server

        if debug is not None:
            self.config["DEBUG"] = debug
        self._configure_logging()
        run_dev_server(
            self,
            host=host,
            port=port,
            debug=bool(self.debug),
            reload=bool(self.debug if reload is None else reload),
            threaded=threaded,
            quiet=quiet,
        )

    def describe(self) -> str:
        """A human readable summary of the registered routes (used by the CLI)."""
        lines = [f"MyFramework application {self.import_name!r}"]
        for rule in self.url_map:
            methods = ", ".join(sorted(rule.methods))
            lines.append(f"  {rule.rule:<40} {methods:<28} -> {rule.endpoint}")
        return "\n".join(lines)

    def __repr__(self) -> str:
        return f"<App {self.import_name!r} rules={len(self.url_map)}>"


# Re-exported for convenience so `from myframework.app import request, g` works.
__all__ += ["current_app", "g", "jsonify", "redirect", "request"]
