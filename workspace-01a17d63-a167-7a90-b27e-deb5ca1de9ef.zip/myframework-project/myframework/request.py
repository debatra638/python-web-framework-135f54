"""The HTTP request object and the WSGI environment adapter.

A :class:`Request` is a read-only view over the WSGI ``environ`` dictionary
(PEP 3333).  It lazily parses the body when — and only when — the application
asks for it, and it enforces ``MAX_CONTENT_LENGTH`` *before* reading anything
from ``wsgi.input`` so a hostile client cannot make the server buffer an
unbounded payload.

No third-party code is involved: query strings use :mod:`urllib.parse` and
``multipart/form-data`` is parsed with :mod:`email` (the same approach used by
the CPython test suite's WSGI helpers).
"""

from __future__ import annotations

import io
import json as _json
from collections.abc import Iterator, Mapping
from email.parser import BytesParser
from email.policy import default as _email_policy
from typing import Any
from urllib.parse import parse_qsl, urlencode

from .datastructures import FileStorage, Headers, MultiDict
from .exceptions import BadRequest, PayloadTooLarge, UnsupportedMediaType
from .utils import parse_cookie, parse_options_header

__all__ = ["EnvironHeaders", "Request"]

_CONTENT_TYPE_JSON = "application/json"
_CONTENT_TYPE_FORM = "application/x-www-form-urlencoded"
_CONTENT_TYPE_MULTIPART = "multipart/form-data"


class EnvironHeaders(Headers):
    """A read-only :class:`Headers` view built from a WSGI environ.

    Only ``HTTP_*`` keys and the handful of CGI variables that are really
    headers (``CONTENT_TYPE``, ``CONTENT_LENGTH``) are exposed.
    """

    __slots__ = ("environ",)

    def __init__(self, environ: Mapping[str, Any]) -> None:
        object.__setattr__(self, "environ", environ)
        pairs: list[tuple[str, str]] = []
        for key, value in environ.items():
            if not isinstance(value, str):
                continue
            if key.startswith("HTTP_"):
                name = key[5:].replace("_", "-").title()
                pairs.append((name, value))
            elif key in ("CONTENT_TYPE", "CONTENT_LENGTH") and value != "":
                pairs.append((key.replace("_", "-").title(), value))
        # Build the list directly: the ``add``/``set`` helpers are disabled for
        # this read-only view, so ``Headers.__init__`` cannot be reused.
        object.__setattr__(self, "_list", pairs)

    def __setitem__(self, key: str, value: str) -> None:  # pragma: no cover
        raise TypeError("EnvironHeaders is read-only; use the response headers instead.")

    def add(self, key: str, value: str) -> None:  # pragma: no cover
        raise TypeError("EnvironHeaders is read-only; use the response headers instead.")

    def set(self, key: str, value: str) -> None:  # pragma: no cover
        raise TypeError("EnvironHeaders is read-only; use the response headers instead.")


def _decode_wsgi_str(value: str) -> str:
    """Recover the real Unicode value from a PEP 3333 ``str``.

    PEP 3333 stores URL components as latin-1 decoded bytes.  A real UTF-8 path
    such as ``/café`` therefore arrives as ``/cafÃ©``.  We re-decode it, but
    tolerate servers that already gave us proper Unicode.
    """
    try:
        return value.encode("latin-1").decode("utf-8")
    except (UnicodeEncodeError, UnicodeDecodeError):
        return value


class Request:
    """An incoming HTTP request.

    Instances are created by the application (never by user code) and are
    available inside views through the :data:`myframework.request` proxy.

    Attributes
    ----------
    environ:
        The raw WSGI environment, exposed for middleware and integrations.
    endpoint / view_args:
        Filled in by the dispatcher once routing has succeeded.  ``endpoint``
        is the route name and ``view_args`` the captured URL parameters.
    """

    __slots__ = (
        "_args",
        "_body",
        "_cookies",
        "_files",
        "_form",
        "_headers",
        "_json",
        "_json_parsed",
        "endpoint",
        "environ",
        "max_content_length",
        "routing_exception",
        "url_rule",
        "view_args",
    )

    #: Attribute used by the global ``request`` proxy.
    def __init__(
        self,
        environ: Mapping[str, Any],
        max_content_length: int | None = None,
    ) -> None:
        self.environ: dict[str, Any] = dict(environ) if not isinstance(environ, dict) else environ
        self.max_content_length = max_content_length
        self._headers: EnvironHeaders | None = None
        self._args: MultiDict | None = None
        self._form: MultiDict | None = None
        self._files: MultiDict | None = None
        self._body: bytes | None = None
        self._json: Any = None
        self._json_parsed = False
        self._cookies: dict[str, str] | None = None
        self.endpoint: str | None = None
        self.view_args: dict[str, Any] = {}
        self.url_rule: Any = None
        self.routing_exception: Exception | None = None

    # -- construction -----------------------------------------------------
    @classmethod
    def from_environ(
        cls, environ: Mapping[str, Any], max_content_length: int | None = None
    ) -> Request:
        """Build a :class:`Request` from a WSGI environ dictionary."""
        return cls(environ, max_content_length=max_content_length)

    def __repr__(self) -> str:
        return f"<Request {self.method} {self.path!r}>"

    # -- basic metadata ---------------------------------------------------
    @property
    def method(self) -> str:
        """The HTTP method, upper-cased (``GET``, ``POST``, ...)."""
        return str(self.environ.get("REQUEST_METHOD", "GET")).upper()

    @property
    def scheme(self) -> str:
        """``http`` or ``https``."""
        return str(self.environ.get("wsgi.url_scheme", "http"))

    @property
    def is_secure(self) -> bool:
        """``True`` when the request was made over TLS."""
        return self.scheme == "https"

    @property
    def script_name(self) -> str:
        """The mount point of the application (``SCRIPT_NAME``)."""
        return str(self.environ.get("SCRIPT_NAME") or "")

    @property
    def path(self) -> str:
        """The decoded path of the request, without the query string."""
        return _decode_wsgi_str(str(self.environ.get("PATH_INFO") or "/"))

    @property
    def query_string(self) -> bytes:
        """The raw query string as bytes."""
        raw = self.environ.get("QUERY_STRING", "")
        if isinstance(raw, bytes):
            return raw
        return str(raw).encode("latin-1", "replace")

    @property
    def full_path(self) -> str:
        """The path plus ``?query`` (the HTTP request target)."""
        if self.query_string:
            return f"{self.path}?{self.query_string.decode('latin-1')}"
        return self.path

    @property
    def query_string_text(self) -> str:
        """The query string decoded as UTF-8 where possible."""
        return _decode_wsgi_str(self.query_string.decode("latin-1"))

    @property
    def host(self) -> str:
        """The ``Host`` header, falling back to ``SERVER_NAME:SERVER_PORT``."""
        header = self.environ.get("HTTP_HOST")
        if header:
            return str(header)
        server_name = str(self.environ.get("SERVER_NAME", "localhost"))
        server_port = str(self.environ.get("SERVER_PORT", "80"))
        default_port = "443" if self.is_secure else "80"
        return server_name if server_port == default_port else f"{server_name}:{server_port}"

    @property
    def root_url(self) -> str:
        """The origin of the request, e.g. ``https://example.com``."""
        return f"{self.scheme}://{self.host}"

    @property
    def url(self) -> str:
        """The absolute URL of the request, including the query string."""
        return f"{self.root_url}{self.script_name}{self.full_path}"

    @property
    def base_url(self) -> str:
        """The absolute URL of the request without the query string."""
        return f"{self.root_url}{self.script_name}{self.path}"

    @property
    def remote_addr(self) -> str | None:
        """The client address reported by the WSGI server.

        Behind a reverse proxy this is the proxy's address unless the
        :class:`~myframework.middleware.ProxyFix` middleware is installed.
        """
        value = self.environ.get("REMOTE_ADDR")
        return str(value) if value else None

    # -- headers, cookies, args -------------------------------------------
    @property
    def headers(self) -> EnvironHeaders:
        """Read-only mapping of the request headers (case-insensitive)."""
        if self._headers is None:
            self._headers = EnvironHeaders(self.environ)
        return self._headers

    def get_header(self, name: str, default: str | None = None) -> str | None:
        """Return a single header value."""
        try:
            return str(self.headers[name])
        except KeyError:
            return default

    @property
    def cookies(self) -> dict[str, str]:
        """Cookies sent by the client as a plain dictionary."""
        if self._cookies is None:
            self._cookies = parse_cookie(self.headers.get("Cookie"))
        return self._cookies

    @property
    def args(self) -> MultiDict:
        """Parsed query string parameters (``?a=1&a=2`` keeps both values)."""
        if self._args is None:
            self._args = MultiDict(
                parse_qsl(self.query_string_text, keep_blank_values=True, errors="replace")
            )
        return self._args

    @property
    def content_type(self) -> str:
        """The raw ``Content-Type`` header, or ``""``."""
        return str(self.environ.get("CONTENT_TYPE") or "")

    @property
    def mimetype(self) -> str:
        """The media type of the body without parameters, lower-cased."""
        return parse_options_header(self.content_type)[0]

    @property
    def content_length(self) -> int | None:
        """The value of ``Content-Length`` if the client sent a valid one."""
        raw = self.environ.get("CONTENT_LENGTH")
        if raw in (None, ""):
            return None
        try:
            value = int(str(raw))
        except (TypeError, ValueError):
            raise BadRequest("Invalid Content-Length header.") from None
        if value < 0:
            raise BadRequest("Invalid Content-Length header.")
        return value

    @property
    def is_json(self) -> bool:
        """``True`` when the body claims to be JSON."""
        mimetype = self.mimetype
        return mimetype == _CONTENT_TYPE_JSON or mimetype.endswith("+json")

    @property
    def stream(self) -> Any:
        """The raw WSGI input stream.

        Reading it directly bypasses the body cache; prefer :meth:`get_data`.
        """
        return self.environ.get("wsgi.input", io.BytesIO(b""))

    # -- body -------------------------------------------------------------
    def get_data(self, as_text: bool = False, cache: bool = True) -> Any:
        """Return the raw request body.

        Parameters
        ----------
        as_text:
            Decode the body using the charset from ``Content-Type``
            (default UTF-8) and return ``str``.
        cache:
            When ``False`` the stream is consumed without being remembered,
            which keeps large bodies out of memory longer than necessary.

        Raises
        ------
        PayloadTooLarge
            If the body exceeds ``MAX_CONTENT_LENGTH``.
        """
        if self._body is not None:
            body = self._body
        else:
            body = self._read_body()
            if cache:
                self._body = body
        if as_text:
            _main, options = parse_options_header(self.content_type)
            charset = options.get("charset", "utf-8")
            try:
                return body.decode(charset, "replace")
            except LookupError:
                return body.decode("utf-8", "replace")
        return body

    @property
    def data(self) -> bytes:
        """The raw request body as bytes."""
        return self.get_data()  # type: ignore[no-any-return]

    def _read_body(self) -> bytes:
        length = self.content_length
        limit = self.max_content_length
        if length is not None and limit is not None and length > limit:
            raise PayloadTooLarge(
                f"The body of this request exceeds the {limit} byte limit "
                "configured via MAX_CONTENT_LENGTH."
            )
        stream = self.stream
        chunks: list[bytes] = []
        if length is not None:
            remaining = length
            while remaining > 0:
                chunk = stream.read(min(remaining, 64 * 1024))
                if not chunk:
                    break
                chunks.append(chunk)
                remaining -= len(chunk)
        else:
            # No Content-Length: read until EOF but never beyond the limit.
            while True:
                chunk = stream.read(64 * 1024)
                if not chunk:
                    break
                chunks.append(chunk)
                if limit is not None and sum(map(len, chunks)) > limit:
                    raise PayloadTooLarge(
                        f"The body of this request exceeds the {limit} byte limit "
                        "configured via MAX_CONTENT_LENGTH."
                    )
        return b"".join(chunks)

    # -- form / files -----------------------------------------------------
    @property
    def form(self) -> MultiDict:
        """Parsed form fields from a urlencoded or multipart body."""
        self._load_form_data()
        assert self._form is not None
        return self._form

    @property
    def files(self) -> MultiDict:
        """Uploaded files as a :class:`~myframework.datastructures.MultiDict`."""
        self._load_form_data()
        assert self._files is not None
        return self._files

    @property
    def values(self) -> MultiDict:
        """Combined query string and form values (query string wins)."""
        combined = MultiDict(self.args)
        for key, value in self.form.items(multi=True):
            if key not in combined:
                combined.add(key, value)
        return combined

    def _load_form_data(self) -> None:
        if self._form is not None and self._files is not None:
            return
        self._form = MultiDict()
        self._files = MultiDict()
        if self.method in ("GET", "HEAD", "OPTIONS", "TRACE", "DELETE"):
            return
        mimetype = self.mimetype
        if mimetype == _CONTENT_TYPE_MULTIPART:
            self._parse_multipart()
        elif mimetype == _CONTENT_TYPE_FORM:
            _main, options = parse_options_header(self.content_type)
            charset = options.get("charset", "utf-8")
            try:
                text = self.get_data().decode(charset, "replace")
            except LookupError:
                text = self.get_data().decode("utf-8", "replace")
            for key, value in parse_qsl(text, keep_blank_values=True):
                self._form.add(key, value)

    def _parse_multipart(self) -> None:
        boundary = parse_options_header(self.content_type)[1].get("boundary")
        if not boundary:
            raise BadRequest("Invalid multipart request: missing boundary.")
        body = self.get_data()
        assert isinstance(body, bytes)
        # Rebuild a complete MIME message so the stdlib parser can do the work.
        header = f"Content-Type: {self.content_type}\r\nMIME-Version: 1.0\r\n\r\n".encode("latin-1")
        try:
            message = BytesParser(policy=_email_policy).parsebytes(header + body)
        except Exception as exc:  # malformed multipart bodies are client errors
            raise BadRequest(f"Could not parse multipart body: {exc}") from None
        if not message.is_multipart():
            raise BadRequest("Invalid multipart request body.")
        for part in message.iter_parts():
            raw_name = part.get_param("name", header="content-disposition")
            if not raw_name or not isinstance(raw_name, str):
                continue
            name = raw_name
            filename = part.get_filename()
            raw_payload = part.get_payload(decode=True)
            payload = raw_payload if isinstance(raw_payload, bytes) else b""
            assert self._files is not None and self._form is not None
            if filename is not None:
                self._files.add(
                    name,
                    FileStorage(
                        stream=io.BytesIO(payload),
                        filename=filename,
                        name=name,
                        content_type=part.get_content_type(),
                        headers=dict(part.items()),
                    ),
                )
            else:
                charset = part.get_content_charset() or "utf-8"
                try:
                    self._form.add(name, payload.decode(charset, "replace"))
                except LookupError:
                    self._form.add(name, payload.decode("utf-8", "replace"))

    # -- JSON -------------------------------------------------------------
    def get_json(self, force: bool = False, silent: bool = False, cache: bool = True) -> Any:
        """Parse the body as JSON.

        Parameters
        ----------
        force:
            Parse regardless of the ``Content-Type`` header.
        silent:
            Return ``None`` instead of raising when parsing fails.
        cache:
            Reuse an earlier parse result.
        """
        if self._json_parsed and cache:
            return self._json
        if not (force or self.is_json):
            if silent:
                return None
            raise UnsupportedMediaType(
                "The request body must be JSON; send Content-Type: application/json."
            )
        try:
            text = self.get_data(as_text=True)
            parsed = _json.loads(text) if text.strip() else None
        except (ValueError, UnicodeDecodeError) as exc:
            if silent:
                return None
            raise BadRequest(f"Invalid JSON in request body: {exc}") from None
        if cache:
            self._json = parsed
            self._json_parsed = True
        return parsed

    @property
    def json(self) -> Any:
        """The parsed JSON body (``None`` when the body is empty)."""
        return self.get_json(silent=True)

    # -- convenience ------------------------------------------------------
    def get_param(self, key: str, default: str | None = None) -> str | None:
        """Look a value up in the query string, then the form, then JSON."""
        if key in self.args:
            return str(self.args[key])
        if key in self.form:
            return str(self.form[key])
        payload = self.get_json(silent=True)
        if isinstance(payload, dict) and key in payload:
            value = payload[key]
            return value if isinstance(value, str) else str(value)
        return default

    def iter_pairs(self) -> Iterator[tuple[str, str]]:
        """Iterate over ``(key, value)`` pairs of the query string."""
        yield from self.args.items(multi=True)

    def to_dict(self) -> dict[str, Any]:
        """A small debugging summary of the request."""
        return {
            "method": self.method,
            "path": self.path,
            "query_string": self.query_string_text,
            "content_type": self.content_type,
            "content_length": self.content_length,
            "headers": dict(self.headers.items()),
        }

    def urlencoded_form(self) -> str:
        """Return the query string, re-encoded (useful for links)."""
        return urlencode(list(self.args.items(multi=True)))
