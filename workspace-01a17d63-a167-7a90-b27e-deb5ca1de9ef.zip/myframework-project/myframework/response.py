"""HTTP response objects, JSON helpers and redirect/abort utilities.

A :class:`Response` is both a data container and a valid WSGI application, so
it can be returned from a view, handed to middleware, or mounted directly on
any WSGI server:

>>> from myframework.response import Response
>>> def app(environ, start_response):       # doctest: +SKIP
...     return Response("hello").wsgi(environ, start_response)
"""

from __future__ import annotations

import dataclasses
import datetime as _dt
import decimal
import json as _json
import uuid
from collections.abc import Iterable, Iterator, Mapping, Sequence
from http import HTTPStatus
from typing import Any, Union

from .datastructures import Headers, HeaderTypes
from .exceptions import HTTPException
from .utils import dump_cookie, escape, http_date
from .utils import url_quote as _url_quote

__all__ = [
    "Response",
    "abort",
    "jsonify",
    "make_response",
    "redirect",
    "stream_response",
]

# Runtime alias: the forward reference to "Response" rules out ``X | Y`` here.
BodyType = Union[str, bytes, bytearray, Iterable[bytes], "Response", None]


class _JSONEncoder(_json.JSONEncoder):
    """JSON encoder with sensible defaults for common Python objects."""

    def default(self, o: Any) -> Any:
        if isinstance(o, (_dt.datetime, _dt.date, _dt.time)):
            return o.isoformat()
        if isinstance(o, _dt.timedelta):
            return o.total_seconds()
        if isinstance(o, (decimal.Decimal, uuid.UUID)):
            return str(o)
        if dataclasses.is_dataclass(o) and not isinstance(o, type):
            return dataclasses.asdict(o)
        if isinstance(o, (set, frozenset)):
            return sorted(o)
        if hasattr(o, "__html__"):
            return str(o)
        return super().default(o)


def _status_line(status: int | str) -> tuple[int, str]:
    """Normalise ``status`` into ``(code, "code REASON")``."""
    if isinstance(status, str):
        code_text, _, reason = status.strip().partition(" ")
        try:
            code = int(code_text)
        except ValueError:
            raise ValueError(f"Invalid status {status!r}; expected e.g. '404 NOT FOUND'.") from None
        if not 100 <= code <= 999:
            raise ValueError(f"Invalid HTTP status code {code}; must be between 100 and 999.")
        if reason:
            return code, f"{code} {reason.upper()}"
        status = code
    if isinstance(status, bool) or not isinstance(status, int):
        raise TypeError(f"Invalid status {status!r}; expected an int or a status string.")
    if not 100 <= status <= 999:
        raise ValueError(f"Invalid HTTP status code {status}; must be between 100 and 999.")
    try:
        reason = HTTPStatus(status).phrase.upper()
    except ValueError:
        reason = "UNKNOWN"
    return status, f"{status} {reason}"


class Response:
    """An HTTP response.

    Parameters
    ----------
    body:
        ``str`` (encoded with :attr:`charset`), ``bytes``, or an iterable of
        ``bytes`` for streaming.  ``None`` means "no body".
    status:
        An ``int`` such as ``201`` or a full string such as ``"418 I'M A TEAPOT"``.
    headers:
        A mapping or list of pairs.
    mimetype / content_type:
        Set one of them to control the ``Content-Type`` header.  ``mimetype``
        gets ``; charset=...`` appended for text types, ``content_type`` is
        used verbatim.
    direct_passthrough:
        When ``True`` the body iterator is handed to the server untouched
        (used for file streaming) and ``Content-Length`` is not inferred.
    """

    #: Content type used when the caller sets none.
    default_mimetype = "text/html"
    #: Charset used to encode text bodies.
    charset = "utf-8"

    def __init__(
        self,
        body: BodyType = None,
        status: int | str = 200,
        headers: HeaderTypes = None,
        mimetype: str | None = None,
        content_type: str | None = None,
        direct_passthrough: bool = False,
    ) -> None:
        self._iterable: Iterable[bytes] | None = None
        self._body: bytes = b""
        self._stream_sent = False
        self.direct_passthrough = direct_passthrough
        self.headers = Headers(headers)
        self._status_code, self._status_text = _status_line(status)

        if content_type is not None and mimetype is not None:
            raise ValueError("Specify either mimetype or content_type, not both.")
        if content_type is not None:
            self.headers["Content-Type"] = content_type
        elif mimetype is not None:
            self.headers["Content-Type"] = self._content_type_for(mimetype)
        elif "Content-Type" not in self.headers:
            self.headers["Content-Type"] = self._content_type_for(self.default_mimetype)

        self.set_data(body)

    # -- body -------------------------------------------------------------
    #: Media types that get ``; charset=...`` appended automatically.
    _TEXTUAL_PREFIXES = ("text/",)
    _TEXTUAL_TYPES = (
        "application/json",
        "application/xml",
        "application/javascript",
        "application/x-www-form-urlencoded",
        "image/svg+xml",
    )

    @staticmethod
    def _content_type_for(mimetype: str) -> str:
        """Add ``; charset=`` for textual media types, leave binary ones alone."""
        mimetype = mimetype.strip()
        if ";" in mimetype:
            return mimetype
        textual = mimetype.startswith(Response._TEXTUAL_PREFIXES) or any(
            mimetype == known or mimetype.endswith("+" + known.split("/", 1)[1])
            for known in Response._TEXTUAL_TYPES
        )
        return f"{mimetype}; charset={Response.charset}" if textual else mimetype

    def set_data(self, value: BodyType) -> None:
        """Replace the response body."""
        if value is None:
            self._body = b""
            self._iterable = None
        elif isinstance(value, Response):
            self._body = value.get_data()
            self._iterable = None
        elif isinstance(value, str):
            self._body = value.encode(self.charset)
            self._iterable = None
        elif isinstance(value, (bytes, bytearray, memoryview)):
            self._body = bytes(value)
            self._iterable = None
        elif isinstance(value, Iterable):
            if isinstance(value, Mapping):
                raise TypeError(
                    "A dict cannot be a response body. Return it from the view (it becomes "
                    "JSON) or use jsonify(...)."
                )
            self._iterable = value
            self._body = b""
            self.direct_passthrough = True
        else:  # pragma: no cover - defensive
            raise TypeError(f"Cannot use {type(value)!r} as a response body.")
        if self._iterable is None:
            self.headers["Content-Length"] = str(len(self._body))

    def get_data(self, as_text: bool = False) -> Any:
        """Return the full body, joining a streaming iterable if necessary."""
        if self._iterable is not None:
            if self.direct_passthrough:
                raise RuntimeError("Cannot call get_data() on a direct-passthrough response body.")
            self._body = b"".join(self._iterable)
            self._iterable = None
        return self._body.decode(self.charset) if as_text else self._body

    @property
    def data(self) -> bytes:
        """The response body as bytes."""
        return self.get_data()  # type: ignore[no-any-return]

    @property
    def text(self) -> str:
        """The response body decoded with :attr:`charset`."""
        return self.get_data(as_text=True)  # type: ignore[no-any-return]

    # -- status -----------------------------------------------------------
    @property
    def status_code(self) -> int:
        """The numeric status code."""
        return self._status_code

    @status_code.setter
    def status_code(self, value: int) -> None:
        self._status_code, self._status_text = _status_line(value)

    @property
    def status(self) -> str:
        """The full status line, e.g. ``"200 OK"``."""
        return self._status_text

    @status.setter
    def status(self, value: int | str) -> None:
        self._status_code, self._status_text = _status_line(value)

    # -- content type -----------------------------------------------------
    @property
    def mimetype(self) -> str:
        """The media type without parameters."""
        return self.headers.get("Content-Type", "").partition(";")[0].strip().lower()

    @mimetype.setter
    def mimetype(self, value: str) -> None:
        self.headers["Content-Type"] = self._content_type_for(value)

    @property
    def content_type(self) -> str:
        """The full ``Content-Type`` header value."""
        return self.headers.get("Content-Type", "")

    @content_type.setter
    def content_type(self, value: str) -> None:
        self.headers["Content-Type"] = value

    @property
    def is_json(self) -> bool:
        """``True`` when the response is JSON."""
        mimetype = self.mimetype
        return mimetype == "application/json" or mimetype.endswith("+json")

    def get_json(self, silent: bool = True) -> Any:
        """Parse the body as JSON.

        ``silent=True`` (the default) returns ``None`` instead of raising when
        the body is not JSON or is malformed.
        """
        if not self.is_json:
            if silent:
                return None
            raise ValueError("Response is not JSON.")
        try:
            return _json.loads(self.get_data(as_text=True))
        except ValueError:
            if silent:
                return None
            raise

    @property
    def json(self) -> Any:
        """The body parsed as JSON (``None`` when it is not JSON)."""
        if not self.is_json:
            return None
        try:
            return _json.loads(self.get_data(as_text=True))
        except ValueError:
            return None

    # -- cookies ----------------------------------------------------------
    def set_cookie(
        self,
        key: str,
        value: str = "",
        max_age: int | None = None,
        expires: Any = None,
        path: str = "/",
        domain: str | None = None,
        secure: bool = False,
        httponly: bool = False,
        samesite: str | None = "Lax",
    ) -> None:
        """Add a ``Set-Cookie`` header.

        The defaults (``path="/"``, ``samesite="Lax"``) are deliberately
        conservative.  Pass ``httponly=True`` for cookies that JavaScript must
        not read and ``secure=True`` whenever the site is served over HTTPS.
        """
        self.headers.add(
            "Set-Cookie",
            dump_cookie(
                key,
                value,
                max_age=max_age,
                expires=expires,
                path=path,
                domain=domain,
                secure=secure,
                httponly=httponly,
                samesite=samesite,
            ),
        )

    def delete_cookie(
        self,
        key: str,
        path: str = "/",
        domain: str | None = None,
        secure: bool = False,
        httponly: bool = False,
        samesite: str | None = "Lax",
    ) -> None:
        """Expire a cookie on the client."""
        self.set_cookie(
            key,
            "",
            max_age=0,
            expires=0,
            path=path,
            domain=domain,
            secure=secure,
            httponly=httponly,
            samesite=samesite,
        )

    # -- caching ----------------------------------------------------------
    def cache_control(
        self,
        max_age: int | None = None,
        public: bool = False,
        no_cache: bool = False,
        no_store: bool = False,
        must_revalidate: bool = False,
    ) -> None:
        """Set a ``Cache-Control`` header from common directives."""
        directives: list[str] = []
        if public:
            directives.append("public")
        if no_cache:
            directives.append("no-cache")
        if no_store:
            directives.append("no-store")
        if must_revalidate:
            directives.append("must-revalidate")
        if max_age is not None:
            if max_age < 0:
                raise ValueError("max_age must be >= 0")
            directives.append(f"max-age={int(max_age)}")
        self.headers["Cache-Control"] = ", ".join(directives) if directives else "no-store"

    def set_etag(self, value: str) -> None:
        """Set an ``ETag`` header, quoting the value when needed."""
        value = value.strip()
        if not (value.startswith('"') and value.endswith('"')):
            value = f'"{value}"'
        self.headers["ETag"] = value

    def get_etag(self) -> str | None:
        """Return the ``ETag`` value without its quotes."""
        value = self.headers.get("ETag")
        if value is None:
            return None
        return value.strip('"')

    def set_expires(self, expires: float | _dt.datetime | _dt.timedelta | None = None) -> str:
        """Set an ``Expires`` header.

        A number is interpreted as *seconds from now* (like ``Cache-Control:
        max-age``), a ``timedelta`` is added to now and a ``datetime`` is used
        as-is.  ``None`` means "right now" (i.e. already expired).
        """
        moment: Any
        if isinstance(expires, _dt.timedelta):
            moment = _dt.datetime.now(_dt.timezone.utc) + expires
        elif expires is None or expires == 0:
            # ``0`` means "already expired" (the epoch), which is what deleting a
            # cookie needs; ``None`` means the same thing.
            moment = 0
        elif isinstance(expires, (int, float)) and not isinstance(expires, bool):
            moment = _dt.datetime.now(_dt.timezone.utc) + _dt.timedelta(seconds=expires)
        else:
            moment = expires
        header = http_date(moment)
        self.headers["Expires"] = header
        return header

    def add_vary(self, field: str) -> None:
        """Add a field name to the ``Vary`` header without duplicating it."""
        current = self.headers.get("Vary")
        fields = [item.strip() for item in current.split(",")] if current else []
        if field not in fields:
            fields.append(field)
        self.headers["Vary"] = ", ".join(fields)

    def add_etag(self, value: str | None = None) -> str:
        """Set an ``ETag`` header, generating one from the body if needed."""
        import hashlib

        if value is None:
            digest = hashlib.sha1(self.get_data(), usedforsecurity=False).hexdigest()
            value = f'"{digest}"'
        self.headers["ETag"] = value
        return value

    def set_last_modified(self, value: float | _dt.datetime | None = None) -> str:
        """Set a ``Last-Modified`` header (defaults to now)."""
        header = http_date(value)
        self.headers["Last-Modified"] = header
        return header

    # -- WSGI -------------------------------------------------------------
    def _header_pairs(self) -> list[tuple[str, str]]:
        """Return header pairs ready for ``start_response``.

        PEP 3333 requires latin-1 encodable headers.  Rather than silently
        mangling a value that a browser would then mis-decode, non latin-1
        values raise so the bug surfaces in development.
        """
        pairs: list[tuple[str, str]] = []
        for name, value in self.headers.items():
            name.encode("latin-1")
            value.encode("latin-1")
            pairs.append((name, value))
        return pairs

    def wsgi(self, environ: Mapping[str, Any], start_response: Any) -> Iterable[bytes]:
        """Run this response as a WSGI application."""
        if self._iterable is None:
            body = self._body
            if not self.direct_passthrough and "Content-Length" not in self.headers:
                self.headers["Content-Length"] = str(len(body))
            if environ.get("REQUEST_METHOD", "GET").upper() == "HEAD":
                # RFC 7231: HEAD has the same headers as GET but no body.
                start_response(self.status, self._header_pairs())
                return []
            start_response(self.status, self._header_pairs())
            return [body] if body else [b""]
        if "Content-Length" not in self.headers and not self.direct_passthrough:
            body_data = self.get_data()
            assert isinstance(body_data, bytes)
            self.headers["Content-Length"] = str(len(body_data))
        if self._stream_sent:
            raise RuntimeError(
                "This response's streaming body has already been sent; a streaming "
                "response can only be used for one request."
            )
        self._stream_sent = True
        start_response(self.status, self._header_pairs())
        if environ.get("REQUEST_METHOD", "GET").upper() == "HEAD":
            self.close()
            return []
        return _ClosingIterator(self._iterable, self.close)

    def __call__(self, environ: Mapping[str, Any], start_response: Any) -> Iterable[bytes]:
        """Allow a ``Response`` to be used directly as a WSGI application."""
        return self.wsgi(environ, start_response)

    def close(self) -> None:
        """Release resources held by a streaming body."""
        iterable = self._iterable
        close = getattr(iterable, "close", None)
        if callable(close):
            close()

    def __repr__(self) -> str:
        return f"<Response {self.status} {self.mimetype} {len(self._body)} bytes>"


class _ClosingIterator:
    """Wrap an iterable so that ``close()`` on it releases the response."""

    __slots__ = ("_closer", "_iterable", "_iterator")

    def __init__(self, iterable: Iterable[bytes], closer: Any = None) -> None:
        self._iterable = iterable
        self._iterator = iter(iterable)
        self._closer = closer

    def __iter__(self) -> Iterator[bytes]:
        return self._iterator

    def __next__(self) -> bytes:
        return next(self._iterator)

    def close(self) -> None:
        try:
            close = getattr(self._iterable, "close", None)
            if callable(close):
                close()
        finally:
            if self._closer is not None:
                self._closer()


def make_response(
    value: Any, status: int | str | None = None, headers: HeaderTypes = None
) -> Response:
    """Convert a view's return value into a :class:`Response`.

    Accepted forms:

    * ``Response`` objects (returned unchanged, with status/headers applied)
    * ``str``/``bytes`` -> HTML response
    * ``dict``/``list`` -> JSON response
    * ``None`` -> empty ``200`` response
    * ``(body, status)`` and ``(body, status, headers)`` tuples
    * any WSGI callable -> wrapped so middleware still applies
    """
    if isinstance(value, tuple) and 2 <= len(value) <= 3:
        body, second = value[0], value[1]
        third = value[2] if len(value) == 3 else None
        if isinstance(second, (int, str)) and not isinstance(second, bool):
            status = second
            headers = third if third is not None else headers
        else:
            headers = second
            status = third if third is not None else status
        value = body

    if isinstance(value, Response):
        response = value
        if status is not None:
            response.status = status
        if headers:
            for name, header_value in Headers(headers).items():
                response.headers.add(name, header_value)
        return response

    if isinstance(value, (dict, list)):
        return jsonify(value, status=status or 200, headers=headers)

    if value is None:
        value = b""

    if isinstance(value, (str, bytes, bytearray, memoryview)):
        return Response(
            value,
            status=status or 200,
            headers=headers,
            mimetype="text/html",
        )

    if callable(value):
        # A raw WSGI application returned from a view (e.g. a streamed file).
        return _WSGICallableResponse(value, status=status, headers=headers)

    if isinstance(value, Iterable):
        return Response(
            value,
            status=status or 200,
            headers=headers,
            mimetype="text/html",
            direct_passthrough=True,
        )

    raise TypeError(
        f"View returned unsupported type {type(value).__name__!r}. "
        "Return a str, bytes, dict, list, Response, (body, status[, headers]) tuple or None."
    )


class _WSGICallableResponse(Response):
    """Adapt an arbitrary WSGI callable so it can travel through the pipeline."""

    def __init__(
        self, app: Any, status: int | str | None = None, headers: HeaderTypes = None
    ) -> None:
        self._app = app
        self._status_override = status
        self._extra_headers = Headers(headers)
        super().__init__(None, status=status or 200, headers=headers)

    def wsgi(self, environ: Mapping[str, Any], start_response: Any) -> Iterable[bytes]:
        def _capture(status: str, headers: Sequence[tuple[str, str]], exc_info: Any = None) -> Any:
            merged = Headers(headers)
            for name, value in self._extra_headers.items():
                merged.set(name, value)
            if self._status_override is not None:
                status = _status_line(self._status_override)[1]
            start_response(status, merged.to_wsgi_list(), exc_info)
            return lambda data: None

        result: Iterable[bytes] = self._app(environ, _capture)
        return result


def jsonify(
    *args: Any, status: int | str = 200, headers: HeaderTypes = None, **kwargs: Any
) -> Response:
    """Return a JSON response.

    ``jsonify({"a": 1})``, ``jsonify(a=1)`` and ``jsonify(1, 2)`` all work.
    Dict/list values are serialised with the framework's encoder, which knows
    about datetimes, decimals, UUIDs and dataclasses.
    """
    if args and kwargs:
        raise TypeError("jsonify() takes either positional arguments or keyword arguments.")
    if kwargs:
        payload: Any = kwargs
    elif len(args) == 1:
        payload = args[0]
    else:
        payload = list(args)
    body = _json.dumps(payload, cls=_JSONEncoder, ensure_ascii=False, indent=None)
    # ``</script>`` inside a JSON response embedded in HTML must not close the
    # surrounding element, so escape the characters that matter to an HTML parser.
    body = body.replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
    return Response(
        body,
        status=status,
        headers=headers,
        content_type="application/json; charset=utf-8",
    )


def redirect(location: str, code: int = 302, headers: HeaderTypes = None) -> Response:
    """Return a redirect response to *location*.

    The URL is percent-encoded for the ``Location`` header and HTML-escaped in
    the human readable body, so a value built from user input cannot inject
    markup or break the header.
    """
    if not 300 <= code <= 399:
        raise ValueError("Redirects must use a 3xx status code.")
    safe_location = _url_quote(location)
    escaped = escape(safe_location)
    response = Response(
        f"<!doctype html><title>Redirecting</title>"
        f'<h1>Redirecting to <a href="{escaped}">{escaped}</a></h1>',
        status=code,
        headers=headers,
        mimetype="text/html",
    )
    response.headers["Location"] = safe_location
    return response


def abort(code: int, description: str | None = None, *args: Any, **kwargs: Any) -> None:
    """Abort the request by raising :class:`~myframework.exceptions.HTTPException`.

    ``abort(404)``, ``abort(404, "No such user")`` and
    ``abort(MethodNotAllowed(["GET"]))`` are all valid.
    """
    if not isinstance(code, int) or isinstance(code, bool):
        raise LookupError(f"{code!r} is not a valid HTTP status code.")
    try:
        HTTPStatus(code)
    except ValueError:
        raise LookupError(f"{code} is not a recognised HTTP status code.") from None
    kwargs.setdefault("code", code)
    if description is not None:
        kwargs.setdefault("description", description)
    if args:
        raise HTTPException(*args, **kwargs)
    raise HTTPException(**kwargs)


def stream_response(
    iterable: Iterable[bytes],
    status: int | str = 200,
    mimetype: str = "text/plain",
    content_type: str | None = None,
) -> Response:
    """Create a streaming response from an iterable of bytes chunks.

    ``Content-Length`` is *not* set: the length of the stream is unknown up
    front.  Use HTTP chunked transfer encoding (or a
    ``Content-Length`` header you add yourself) if the client needs one.
    """
    return Response(
        iterable,
        status=status,
        mimetype=None if content_type else mimetype,
        content_type=content_type,
    )
