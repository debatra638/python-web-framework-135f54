"""Context-local proxies: ``request``, ``g``, ``current_app`` and friends.

The proxies in this module are backed by :mod:`contextvars`, which makes them
correct for threaded WSGI servers (one value per thread), for
``concurrent.futures`` thread pools and for ``asyncio`` tasks.

A proxy raises :class:`RuntimeError` with an explanatory message when it is
used outside of a request — for example at import time or inside a thread the
application does not know about.
"""

from __future__ import annotations

from collections.abc import Iterator
from contextvars import ContextVar
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:  # pragma: no cover - typing only
    from .app import App
    from .request import Request
    from .response import Response

__all__ = ["LocalProxy", "RequestContext", "current_app", "g", "has_request_context", "request"]


class LocalProxy:
    """Forward every operation to the object returned by *getter*."""

    __slots__ = ("_cast", "_getter", "_name")

    def __init__(self, name: str, getter: Any) -> None:
        object.__setattr__(self, "_name", name)
        object.__setattr__(self, "_getter", getter)

    # -- resolution -------------------------------------------------------
    def _get_current_object(self) -> Any:
        try:
            return self._getter()
        except LookupError:
            raise RuntimeError(
                f"Working outside of a request context: {self._name!r} is only available "
                "while handling a request. Did you access it at import time, in a "
                "background thread, or in a WSGI middleware (which runs before the "
                "context is pushed)?"
            ) from None

    def __getattr__(self, name: str) -> Any:
        return getattr(self._get_current_object(), name)

    def __setattr__(self, name: str, value: Any) -> None:
        setattr(self._get_current_object(), name, value)

    def __delattr__(self, name: str) -> None:
        delattr(self._get_current_object(), name)

    def __getitem__(self, key: Any) -> Any:
        return self._get_current_object()[key]

    def __setitem__(self, key: Any, value: Any) -> None:
        self._get_current_object()[key] = value

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        return self._get_current_object()(*args, **kwargs)

    def __iter__(self) -> Iterator[Any]:
        return iter(self._get_current_object())

    def __len__(self) -> int:
        return len(self._get_current_object())

    def __contains__(self, item: Any) -> bool:
        return item in self._get_current_object()

    def __bool__(self) -> bool:
        try:
            return bool(self._get_current_object())
        except RuntimeError:
            return False

    def __eq__(self, other: object) -> bool:
        if isinstance(other, LocalProxy):
            other = other._get_current_object()
        return bool(self._get_current_object() == other)

    def __ne__(self, other: object) -> bool:
        return not self.__eq__(other)

    def __hash__(self) -> int:
        return hash(self._get_current_object())

    def __str__(self) -> str:
        return str(self._get_current_object())

    def __repr__(self) -> str:
        try:
            return repr(self._get_current_object())
        except RuntimeError:
            return f"<LocalProxy unbound {self._name!r}>"


class _AppGlobals:
    """The ``g`` object: a per-request namespace for storing transient data."""

    __slots__ = ("_values",)

    def __init__(self) -> None:
        object.__setattr__(self, "_values", {})

    def __getattr__(self, name: str) -> Any:
        try:
            return self._values[name]
        except KeyError:
            raise AttributeError(
                f"'g' has no attribute {name!r}. Assign it first, e.g. `g.{name} = value`."
            ) from None

    def __setattr__(self, name: str, value: Any) -> None:
        self._values[name] = value

    def __delattr__(self, name: str) -> None:
        try:
            del self._values[name]
        except KeyError:
            raise AttributeError(name) from None

    def __contains__(self, name: object) -> bool:
        return name in self._values

    def __repr__(self) -> str:  # pragma: no cover - debugging convenience
        return f"<g {self._values!r}>"

    def clear(self) -> None:
        """Remove every value (called automatically when the request ends)."""
        self._values.clear()


#: ``contextvars`` slots.  They hold ``None``/sentinel values when unset.
_request_var: ContextVar[Request | None] = ContextVar("myframework.request", default=None)
_app_var: ContextVar[App | None] = ContextVar("myframework.current_app", default=None)
_g_var: ContextVar[_AppGlobals | None] = ContextVar("myframework.g", default=None)


def has_request_context() -> bool:
    """``True`` when the code is running inside a request."""
    return _request_var.get() is not None


def get_current_request() -> Request:
    """Return the active request or raise :class:`RuntimeError`."""
    request = _request_var.get()
    if request is None:
        raise RuntimeError("No request context is active.")
    return request


def get_current_app() -> App:
    """Return the active application or raise :class:`RuntimeError`."""
    app = _app_var.get()
    if app is None:
        raise RuntimeError(
            "No application context is active. Did you access `current_app` or use an "
            "app-bound helper outside of a request?"
        )
    return app


class RequestContext:
    """Push/pop the current request, application and ``g`` for a request.

    Used by :class:`myframework.App` internally and by ``app.test_request_context``
    in tests.  It is a context manager::

        with RequestContext(app, request):
            ...  # ``request`` and ``g`` work here
    """

    __slots__ = ("_g", "_tokens", "app", "request")

    def __init__(self, app: App, request: Request) -> None:
        self.app = app
        self.request = request
        self._tokens: list[Any] = []
        self._g = _AppGlobals()

    def push(self) -> RequestContext:
        """Activate the context."""
        self._tokens.append(_request_var.set(self.request))
        self._tokens.append(_app_var.set(self.app))
        self._tokens.append(_g_var.set(self._g))
        return self

    def pop(self) -> None:
        """Deactivate the context (in reverse order of :meth:`push`)."""
        for token in reversed(self._tokens):
            try:
                if token.var is _request_var:
                    _request_var.reset(token)
                elif token.var is _app_var:
                    _app_var.reset(token)
                else:
                    _g_var.reset(token)
            except (ValueError, RuntimeError):  # pragma: no cover - defensive
                pass
        self._tokens.clear()

    def __enter__(self) -> RequestContext:
        return self.push()

    def __exit__(self, *exc_info: Any) -> None:
        self.pop()


class AppContext:
    """Push/pop an application context without a request.

    ``current_app``, ``g`` and the template helpers work inside it; ``request``
    does not (there is no request).  Used by ``app.app_context()``.
    """

    __slots__ = ("_g", "_tokens", "app")

    def __init__(self, app: App) -> None:
        self.app = app
        self._tokens: list[Any] = []
        self._g = _AppGlobals()

    def push(self) -> AppContext:
        """Activate the context."""
        self._tokens.append(_app_var.set(self.app))
        self._tokens.append(_g_var.set(self._g))
        return self

    def pop(self) -> None:
        """Deactivate the context."""
        for token in reversed(self._tokens):
            try:
                if token.var is _app_var:
                    _app_var.reset(token)
                else:
                    _g_var.reset(token)
            except (ValueError, RuntimeError):  # pragma: no cover - defensive
                pass
        self._tokens.clear()

    def __enter__(self) -> AppContext:
        return self.push()

    def __exit__(self, *exc_info: Any) -> None:
        self.pop()


def _unbound(name: str) -> Any:
    """Getter used by the proxies: raise ``LookupError`` when nothing is bound."""
    raise LookupError(name)


def _get_request() -> Request:
    value = _request_var.get()
    if value is None:
        raise LookupError("request")
    return value


def _get_app() -> App:
    value = _app_var.get()
    if value is None:
        raise LookupError("current_app")
    return value


def _get_g() -> Any:
    value = _g_var.get()
    if value is None:
        raise LookupError("g")
    return value


#: The current request (proxy).
request: Request = LocalProxy("request", _get_request)  # type: ignore[assignment]
#: The current application (proxy).
current_app: App = LocalProxy("current_app", _get_app)  # type: ignore[assignment]
#: Per-request namespace.
g: Any = LocalProxy("g", _get_g)


def url_for(endpoint: str, **values: Any) -> str:
    """Build a URL for *endpoint* using the active application's rules.

    >>> url_for("user_profile", username="ada")   # doctest: +SKIP
    '/users/ada'
    """
    return get_current_app().url_for(endpoint, **values)


def render_template(template_name: str, **context: Any) -> str:
    """Render a template using the active application's template environment."""
    return get_current_app().render_template(template_name, **context)


def jsonify(*args: Any, **kwargs: Any) -> Response:
    """Shortcut for :func:`myframework.response.jsonify` (no request needed)."""
    from .response import jsonify as _jsonify

    return _jsonify(*args, **kwargs)


def abort(code: int, description: str | None = None) -> None:
    """Shortcut for :func:`myframework.response.abort`."""
    from .response import abort as _abort

    _abort(code, description)


def redirect(location: str, code: int = 302) -> Response:
    """Shortcut for :func:`myframework.response.redirect`."""
    from .response import redirect as _redirect

    return _redirect(location, code)
