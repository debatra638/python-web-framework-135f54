"""The development server.

This is deliberately *not* the WSGI interface: it is a small HTTP server built
on :mod:`wsgiref` (server side of PEP 3333) plus a thread pool and a file
reloader.  It exists so ``myframework run`` works out of the box; it is not
hardened for production traffic — use Gunicorn or Waitress there.

Features
--------
* Threaded request handling (``ThreadingMixIn``) so one slow request does not
  block the rest of your manual testing.
* Coloured-ish startup banner with the registered routes and the URL to open.
* Automatic reload when a ``.py`` file in the project changes (debug only).
  The process is replaced with :func:`os.execv`, which keeps the reloader
  dependency-free and predictable.
* Request logging that is quiet by default for static assets.
"""

from __future__ import annotations

import os
import sys
import threading
import time
from collections.abc import Iterable
from socketserver import ThreadingMixIn
from typing import TYPE_CHECKING, Any
from wsgiref.simple_server import WSGIRequestHandler, WSGIServer, make_server

if TYPE_CHECKING:  # pragma: no cover - typing only
    from .app import App

__all__ = ["DevServerRequestHandler", "Reloader", "ThreadedWSGIServer", "run_dev_server"]


class ThreadedWSGIServer(ThreadingMixIn, WSGIServer):
    """A :class:`wsgiref` server that handles each request in its own thread."""

    daemon_threads = True
    allow_reuse_address = True


class DevServerRequestHandler(WSGIRequestHandler):
    """Request handler that logs a compact, readable access line."""

    #: Set by :func:`run_dev_server`; suppresses per-request logging.
    quiet = False

    def log_message(self, format: str, *args: Any) -> None:
        if self.quiet:
            return
        sys.stderr.write(f" * {self.address_string()} - {format % args}\n")

    def log_error(self, format: str, *args: Any) -> None:
        self.log_message(format, *args)

    def get_environ(self) -> dict[str, Any]:
        environ = super().get_environ()
        # Werkzeug-compatible key so middleware can pick up the peer address.
        environ["REMOTE_ADDR"] = self.client_address[0]
        return environ


class Reloader:
    """Watch the project's Python files and restart the process on change."""

    def __init__(self, roots: Iterable[str], interval: float = 0.6) -> None:
        self.roots = [os.path.abspath(root) for root in roots]
        self.interval = interval
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def _snapshot(self) -> dict[str, float]:
        state: dict[str, float] = {}
        for root in self.roots:
            for dirpath, dirnames, filenames in os.walk(root):
                dirnames[:] = [
                    name
                    for name in dirnames
                    if name not in {".git", "__pycache__", ".venv", "node_modules", ".mypy_cache"}
                ]
                for filename in filenames:
                    if filename.endswith((".py", ".html", ".toml", ".json", ".css", ".js")):
                        path = os.path.join(dirpath, filename)
                        try:
                            state[path] = os.stat(path).st_mtime
                        except OSError:
                            continue
        return state

    def _watch(self) -> None:
        baseline = self._snapshot()
        while not self._stop.wait(self.interval):
            current = self._snapshot()
            if current != baseline:
                changed = sorted(
                    set(current) ^ set(baseline)
                    | {
                        path
                        for path in current.keys() & baseline.keys()
                        if current[path] != baseline[path]
                    }
                )
                sys.stderr.write(
                    "\n * Detected change in "
                    + ", ".join(os.path.basename(path) for path in changed[:5])
                    + "\n * Restarting with reloader\n"
                )
                sys.stderr.flush()
                self._restart()
                return

    @staticmethod
    def _restart() -> None:
        try:
            sys.stdout.flush()
            sys.stderr.flush()
            os.execv(sys.executable, [sys.executable, *sys.argv])
        except OSError as exc:  # pragma: no cover - platform specific
            sys.stderr.write(f" * Reload failed ({exc}); restart manually.\n")

    def start(self) -> None:
        """Start watching in a background daemon thread."""
        self._thread = threading.Thread(
            target=self._watch, name="myframework-reloader", daemon=True
        )
        self._thread.start()

    def stop(self) -> None:
        """Stop watching."""
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2)


def _banner(app: App, host: str, port: int, debug: bool, reload: bool) -> str:
    lines = [
        "",
        "  MyFramework development server",
        f"  App:      {app.import_name!r}",
        f"  Debug:    {'on' if debug else 'off'}    Reloader: {'on' if reload else 'off'}",
        f"  Running:  http://{host}:{port}/",
        "  Routes:",
    ]
    for rule in app.url_map:
        methods = ",".join(sorted(rule.methods))
        lines.append(f"    {rule.rule:<36} [{methods}] -> {rule.endpoint}")
    lines.append("  Press CTRL+C to stop.  Not for production use.")
    lines.append("")
    return "\n".join(lines)


def run_dev_server(
    app: App,
    host: str = "127.0.0.1",
    port: int = 8000,
    debug: bool = False,
    reload: bool = False,
    threaded: bool = True,
    quiet: bool = False,
) -> None:
    """Serve *app* with the development server until interrupted."""
    if reload and not os.environ.get("MYFRAMEWORK_NO_RELOADER"):
        Reloader([app.root_path, os.getcwd()]).start()

    server_class = ThreadedWSGIServer if threaded else WSGIServer
    handler_class = type(
        "BoundDevServerRequestHandler",
        (DevServerRequestHandler,),
        {"quiet": quiet or not debug},
    )

    try:
        httpd = make_server(host, port, app, server_class=server_class, handler_class=handler_class)
    except OSError as exc:
        raise SystemExit(
            f"Cannot bind {host}:{port} ({exc}). Is another server already running on that port?"
        ) from None

    if not quiet:
        sys.stderr.write(_banner(app, host, port, debug, reload))
        sys.stderr.flush()

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        if not quiet:
            sys.stderr.write("\n * Stopping development server\n")
    finally:
        httpd.server_close()
        # Give in-flight threads a moment to finish writing their responses.
        time.sleep(0.05)
