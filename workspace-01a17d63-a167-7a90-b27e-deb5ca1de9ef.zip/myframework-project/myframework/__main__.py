"""Allow ``python -m myframework`` as an alias for the ``myframework`` command.

Handy when the console script is not on ``PATH`` (e.g. ``python -m myframework``
inside a virtual environment created with ``--without-pip`` or on Windows).
"""

from __future__ import annotations

from .cli import main

if __name__ == "__main__":
    raise SystemExit(main())
