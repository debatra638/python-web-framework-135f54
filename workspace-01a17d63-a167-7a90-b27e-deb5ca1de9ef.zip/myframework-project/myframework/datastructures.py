"""Container types used by the request, response and routing layers.

``MultiDict`` models query strings and form bodies, where the same key may
appear more than once.  ``Headers`` models HTTP headers, which are
case-insensitive and may (rarely) repeat.  ``FileStorage`` wraps an uploaded
file part.
"""

from __future__ import annotations

import contextlib
import io
from collections.abc import Iterable, Iterator, Mapping, MutableMapping, Sequence
from typing import Any, Union

__all__ = ["FileStorage", "HeaderTypes", "Headers", "MultiDict"]


class MultiDict(MutableMapping[str, Any]):
    """An ordered, multi-value mapping.

    ``__getitem__`` returns the *first* value for a key (query-string
    semantics: ``?a=1&a=2`` gives ``"1"``), :meth:`getlist` returns all of
    them, and :meth:`to_dict` collapses to one value per key.

    >>> md = MultiDict([("a", "1"), ("b", "2"), ("a", "3")])
    >>> md["a"], md.getlist("a"), md.to_dict()
    ('1', ['1', '3'], {'a': '1', 'b': '2'})
    """

    __slots__ = ("_items",)

    def __init__(
        self,
        mapping: Mapping[str, Any] | Iterable[tuple[str, Any]] | None = None,
    ) -> None:
        # Values are typed ``Any`` because ``files`` stores ``FileStorage``
        # objects while query strings and forms store ``str``.
        self._items: list[tuple[str, Any]] = []
        if mapping is None:
            return
        if isinstance(mapping, MultiDict):
            self._items = list(mapping._items)
        elif hasattr(mapping, "items"):
            for key, value in mapping.items():
                self.add(key, value)
        else:
            for key, value in mapping:
                self.add(key, value)

    # -- mapping protocol -------------------------------------------------
    def __getitem__(self, key: str) -> Any:
        for existing_key, value in self._items:
            if existing_key == key:
                return value
        raise KeyError(key)

    def __setitem__(self, key: str, value: Any) -> None:
        self.setlist(key, [value])

    def __delitem__(self, key: str) -> None:
        before = len(self._items)
        self._items = [(k, v) for k, v in self._items if k != key]
        if len(self._items) == before:
            raise KeyError(key)

    def __iter__(self) -> Iterator[str]:
        seen: set[str] = set()
        for key, _value in self._items:
            if key not in seen:
                seen.add(key)
                yield key

    def __len__(self) -> int:
        return len({key for key, _ in self._items})

    def __contains__(self, key: object) -> bool:
        return any(existing == key for existing, _ in self._items)

    def __repr__(self) -> str:
        return f"{type(self).__name__}({self._items!r})"

    def __eq__(self, other: object) -> bool:
        if isinstance(other, MultiDict):
            return self._items == other._items
        if isinstance(other, Mapping):
            return self.to_dict() == dict(other)
        return NotImplemented

    # -- multi-value API --------------------------------------------------
    def add(self, key: str, value: Any) -> None:
        """Append a value for *key*, keeping any existing ones.

        Non-``str`` values are stored as-is (``FileStorage`` uploads), ``None``
        becomes the empty string.
        """
        self._items.append((str(key), "" if value is None else value))

    def getlist(self, key: str) -> list[Any]:
        """Return every value stored under *key* (empty list when missing)."""
        return [value for existing, value in self._items if existing == key]

    #: Alias used by some frameworks/tests.
    getall = getlist

    def setlist(self, key: str, values: Iterable[Any]) -> None:
        """Replace all values for *key* with *values*."""
        self.__delitem_silent(key)
        for value in values:
            self.add(key, value)

    def __delitem_silent(self, key: str) -> None:
        self._items = [(k, v) for k, v in self._items if k != key]

    def items(self, multi: bool = False) -> Iterator[tuple[str, Any]]:  # type: ignore[override]
        """Iterate over items; with ``multi=True`` repeated keys appear again."""
        if multi:
            yield from self._items
        else:
            seen: set[str] = set()
            for key, value in self._items:
                if key not in seen:
                    seen.add(key)
                    yield key, value

    def lists(self) -> Iterator[tuple[str, list[Any]]]:
        """Iterate over ``(key, [values])`` pairs."""
        for key in self:
            yield key, self.getlist(key)

    def to_dict(self, flat: bool = True) -> dict[str, Any]:
        """Return a plain dict (lists for repeated keys when ``flat=False``)."""
        if flat:
            return dict(self.items())
        return dict(self.lists())

    def copy(self) -> MultiDict:
        """Return a shallow copy."""
        return type(self)(self._items)

    @classmethod
    def fromkeys(cls, keys: Iterable[str], value: Any = "") -> MultiDict:
        return cls((key, value) for key in keys)


# ``Union`` (not ``X | Y``) is required here: this is a runtime alias, and the
# forward reference to "Headers" cannot be combined with ``|`` at runtime.
HeaderTypes = Union[Mapping[str, str], Iterable[tuple[str, str]], "Headers", None]


class Headers(MutableMapping[str, str]):
    """An ordered, case-insensitive header container.

    Iteration yields the header names as they were first set, preserving the
    casing the application used.  Lookups and deletions are case-insensitive.
    """

    __slots__ = ("_list",)

    def __init__(self, headers: HeaderTypes = None) -> None:
        self._list: list[tuple[str, str]] = []
        if headers is None:
            return
        if isinstance(headers, Headers):
            self._list = list(headers._list)
        elif hasattr(headers, "items"):
            for key, value in headers.items():
                self.add(key, value)
        else:
            for key, value in headers:
                self.add(key, value)

    # -- mapping protocol -------------------------------------------------
    def __getitem__(self, key: str) -> Any:
        lower = key.lower()
        for name, value in self._list:
            if name.lower() == lower:
                return value
        raise KeyError(key)

    def __setitem__(self, key: str, value: Any) -> None:
        self.set(key, value)

    def __delitem__(self, key: str) -> None:
        lower = key.lower()
        new_list = [(name, value) for name, value in self._list if name.lower() != lower]
        if len(new_list) == len(self._list):
            raise KeyError(key)
        self._list = new_list

    def __iter__(self) -> Iterator[str]:
        seen: set[str] = set()
        for name, _value in self._list:
            lowered = name.lower()
            if lowered not in seen:
                seen.add(lowered)
                yield name

    def __len__(self) -> int:
        return len({name.lower() for name, _ in self._list})

    def __contains__(self, key: object) -> bool:
        if not isinstance(key, str):
            return False
        lower = key.lower()
        return any(name.lower() == lower for name, _ in self._list)

    def __repr__(self) -> str:
        return f"{type(self).__name__}({self._list!r})"

    # -- header specific API ----------------------------------------------
    def add(self, key: str, value: str) -> None:
        """Append a header without removing existing values."""
        self._list.append((str(key), str(value)))

    def set(self, key: str, value: str) -> None:
        """Replace all values for *key* with a single value."""
        with contextlib.suppress(KeyError):
            del self[key]
        self._list.append((str(key), str(value)))

    def getlist(self, key: str) -> list[str]:
        """Return all values for *key*, case-insensitively."""
        lower = key.lower()
        return [value for name, value in self._list if name.lower() == lower]

    def items(self) -> Iterator[tuple[str, str]]:  # type: ignore[override]
        """Iterate over every ``(name, value)`` pair, including repeats."""
        yield from self._list

    def to_wsgi_list(self) -> list[tuple[str, str]]:
        """Return the raw list of pairs, suitable for ``start_response``."""
        return list(self._list)


class FileStorage:
    """A thin wrapper around an uploaded file part.

    Instances are produced by :attr:`myframework.Request.files`.  The content
    is held in memory because MyFramework caps request bodies at
    ``MAX_CONTENT_LENGTH``, so an upload can never exhaust disk or memory
    silently.
    """

    __slots__ = ("content_type", "filename", "headers", "name", "stream")

    def __init__(
        self,
        stream: io.BytesIO,
        filename: str | None = None,
        name: str | None = None,
        content_type: str | None = None,
        headers: Mapping[str, str] | None = None,
    ) -> None:
        self.stream = stream
        self.filename = filename
        self.name = name
        self.content_type = content_type or "application/octet-stream"
        self.headers = dict(headers or {})

    @property
    def content_length(self) -> int:
        """Size of the uploaded content in bytes."""
        position = self.stream.tell()
        self.stream.seek(0, io.SEEK_END)
        size = self.stream.tell()
        self.stream.seek(position)
        return size

    def read(self, size: int = -1) -> bytes:
        """Read from the underlying stream."""
        return self.stream.read(size)

    @property
    def data(self) -> bytes:
        """The whole uploaded payload."""
        position = self.stream.tell()
        self.stream.seek(0)
        payload = self.stream.read()
        self.stream.seek(position)
        return payload

    def save(self, destination: Any) -> None:
        """Write the upload to a path or a writable binary file object."""
        payload = self.data
        if hasattr(destination, "write"):
            destination.write(payload)
        else:
            with open(destination, "wb") as handle:
                handle.write(payload)

    def __repr__(self) -> str:
        return f"<FileStorage {self.filename!r} ({self.content_length} bytes)>"


def is_sequence(value: Any) -> bool:
    """Return ``True`` for non-string sequences (used by response coercion)."""
    return isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray))
