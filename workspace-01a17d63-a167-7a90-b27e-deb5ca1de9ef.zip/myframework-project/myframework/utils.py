"""Small, dependency-free helpers shared across MyFramework.

Everything here is pure standard library so that any module in the package can
import it.  The two most important items are :class:`Markup` (the "already
safe HTML" marker used by the template engine and by ``|safe``) and
:func:`escape` (HTML escaping with the same semantics as Jinja's ``e`` filter).
"""

from __future__ import annotations

import datetime as _dt
import mimetypes
import re
from collections.abc import Iterable
from email.utils import formatdate, parsedate_to_datetime
from http.cookies import SimpleCookie
from typing import Any
from urllib.parse import quote as _url_quote

__all__ = [
    "Markup",
    "dump_cookie",
    "encode_header",
    "escape",
    "guess_mimetype",
    "http_date",
    "is_safe_html",
    "parse_cookie",
    "parse_http_date",
    "parse_options_header",
    "to_bytes",
    "to_unicode",
    "url_quote",
]

_HTML_ESCAPE_TABLE = {
    ord("&"): "&amp;",
    ord("<"): "&lt;",
    ord(">"): "&gt;",
    ord("'"): "&#39;",
    ord('"'): "&#34;",
}


class Markup(str):
    """A string that is already safe to insert into HTML.

    The template engine does not escape instances of this class, which is what
    makes ``{{ value|safe }}`` and the output of the ``url_for`` helper work.
    """

    __slots__ = ()

    def __html__(self) -> Markup:
        return self

    def __repr__(self) -> str:  # pragma: no cover - debugging convenience
        return f"Markup({str.__repr__(self)})"


def escape(value: Any) -> Markup:
    """HTML-escape *value* (``&``, ``<``, ``>``, ``'`` and ``"``).

    ``None`` becomes an empty string, which matches Jinja's behaviour and keeps
    templates free of ``None`` leaking into the output.
    """
    if value is None:
        return Markup("")
    if hasattr(value, "__html__"):
        return Markup(value.__html__())
    return Markup(str(value).translate(_HTML_ESCAPE_TABLE))


def is_safe_html(value: Any) -> bool:
    """Return ``True`` if *value* is marked as already-escaped HTML."""
    return hasattr(value, "__html__")


def to_bytes(value: str | bytes | bytearray | memoryview, charset: str = "utf-8") -> bytes:
    """Coerce *value* to :class:`bytes` using *charset* for text input."""
    if isinstance(value, bytes):
        return value
    if isinstance(value, (bytearray, memoryview)):
        return bytes(value)
    return str(value).encode(charset)


def to_unicode(value: Any, charset: str = "utf-8", errors: str = "replace") -> str:
    """Coerce *value* to :class:`str` using *charset* for bytes input."""
    if isinstance(value, str):
        return value
    if isinstance(value, (bytes, bytearray, memoryview)):
        return bytes(value).decode(charset, errors)
    return str(value)


_OPTION_HEADER_RE = re.compile(r";\s*")


def parse_options_header(value: str | None) -> tuple[str, dict[str, str]]:
    """Parse a header like ``text/html; charset=utf-8`` into a tuple.

    Returns ``(main_value, {option: value})`` where ``main_value`` is
    lower-cased and options keys are lower-cased too, matching what browsers
    and HTTP libraries expect.  Quoted values are unquoted.
    """
    if not value:
        return "", {}
    main, _, rest = value.partition(";")
    options: dict[str, str] = {}
    for part in _split_quoted(rest, ";"):
        part = part.strip()
        if not part:
            continue
        key, _, val = part.partition("=")
        key = key.strip().lower()
        val = val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in "\"'":
            val = val[1:-1]
        if key:
            options[key] = val
    return main.strip().lower(), options


def _split_quoted(value: str, separator: str) -> list[str]:
    """Split *value* on *separator* while respecting double-quoted sections."""
    parts: list[str] = []
    current: list[str] = []
    in_quotes = False
    escaped = False
    for char in value:
        if escaped:
            current.append(char)
            escaped = False
            continue
        if char == "\\" and in_quotes:
            current.append(char)
            escaped = True
            continue
        if char == '"':
            in_quotes = not in_quotes
            current.append(char)
            continue
        if char == separator and not in_quotes:
            parts.append("".join(current))
            current = []
            continue
        current.append(char)
    parts.append("".join(current))
    return parts


_COOKIE_NAME_BAD_CHARS = set("=,; \t\r\n\013\014")


def dump_cookie(
    key: str,
    value: str = "",
    max_age: int | None = None,
    expires: _dt.datetime | int | float | str | None = None,
    path: str = "/",
    domain: str | None = None,
    secure: bool = False,
    httponly: bool = False,
    samesite: str | None = "Lax",
) -> str:
    """Build a ``Set-Cookie`` header value.

    All flags are explicit so that callers never get a "helpful" default they
    did not ask for.  The default ``samesite="Lax"`` and ``path="/"`` follow
    current browser guidance; ``secure`` and ``httponly`` are opt-in because
    they depend on the deployment (HTTPS only, JS access needed or not).
    """
    if not isinstance(key, str) or not key:
        raise ValueError("Cookie name must be a non-empty string.")
    if _COOKIE_NAME_BAD_CHARS & set(key):
        raise ValueError(f"Cookie name {key!r} contains invalid characters.")
    if samesite is not None and samesite.lower() not in {"strict", "lax", "none"}:
        raise ValueError("samesite must be 'strict', 'lax', 'none' or None.")
    if samesite is not None and samesite.lower() == "none" and not secure:
        # Browsers reject SameSite=None without Secure; fail loudly instead of
        # silently shipping a cookie the client will drop.
        raise ValueError("samesite='None' requires secure=True.")

    cookie: SimpleCookie = SimpleCookie()
    cookie[key] = value
    morsel = cookie[key]
    if max_age is not None:
        morsel["max-age"] = str(int(max_age))
    if expires is not None:
        if isinstance(expires, str):
            morsel["expires"] = expires
        elif isinstance(expires, _dt.datetime):
            if expires.tzinfo is None:
                expires = expires.replace(tzinfo=_dt.timezone.utc)
            morsel["expires"] = formatdate(expires.timestamp(), usegmt=True)
        else:
            morsel["expires"] = formatdate(float(expires), usegmt=True)
    if path:
        morsel["path"] = path
    if domain:
        morsel["domain"] = domain
    if secure:
        morsel["secure"] = True
    if httponly:
        morsel["httponly"] = True
    if samesite is not None:
        morsel["samesite"] = samesite.capitalize()
    return morsel.OutputString()


def parse_cookie(header: str | None) -> dict[str, str]:
    """Parse a ``Cookie`` request header into a plain dictionary.

    The parser is deliberately tolerant: malformed fragments are skipped
    instead of raising, because a hostile or buggy client must not be able to
    break the request by sending a broken ``Cookie`` header.  (The stdlib
    ``SimpleCookie`` silently discards the *whole* header in that case.)
    Quoted values are unquoted.
    """
    if not header:
        return {}
    result: dict[str, str] = {}
    for chunk in _split_quoted(header, ";"):
        name, separator, value = chunk.strip().partition("=")
        name = name.strip()
        if not separator or not name:
            continue
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] == '"':
            value = value[1:-1].replace('\\"', '"')
        result[name] = value
    return result


def encode_header(value: str) -> bytes:
    """Encode a header for WSGI.

    PEP 3333 requires header values on ``bytes``-level interfaces to be
    latin-1.  Real-world applications sometimes put UTF-8 (e.g. in a
    ``Location`` header) into headers, so we degrade gracefully instead of
    raising ``UnicodeEncodeError`` deep inside the server.
    """
    try:
        return value.encode("latin-1")
    except UnicodeEncodeError:
        return value.encode("utf-8").decode("latin-1").encode("latin-1")


def http_date(timestamp: float | _dt.datetime | None = None) -> str:
    """Format a timestamp (or datetime) as an RFC 7231 HTTP-date."""
    if timestamp is None:
        timestamp = _dt.datetime.now(_dt.timezone.utc).timestamp()
    if isinstance(timestamp, _dt.datetime):
        if timestamp.tzinfo is None:
            timestamp = timestamp.replace(tzinfo=_dt.timezone.utc)
        timestamp = timestamp.timestamp()
    return formatdate(float(timestamp), usegmt=True)


def parse_http_date(value: str | None) -> int | None:
    """Parse an HTTP-date into a Unix timestamp, or ``None`` when invalid."""
    if not value:
        return None
    try:
        parsed = parsedate_to_datetime(value)
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=_dt.timezone.utc)
    return int(parsed.timestamp())


def guess_mimetype(filename: str) -> str:
    """Guess the content type for *filename*, defaulting to ``text/plain``."""
    guess, _encoding = mimetypes.guess_type(filename)
    return guess or "text/plain"


def url_quote(value: Any, safe: str = "/", charset: str = "utf-8") -> str:
    """Percent-encode *value* for use in a URL path."""
    return _url_quote(to_unicode(value), safe=safe, encoding=charset)


def iter_pairs(value: Iterable[Any]) -> list[tuple[str, str]]:
    """Normalise a mapping or sequence of pairs into ``list[tuple[str, str]]``."""
    if hasattr(value, "items"):
        return [(str(k), str(v)) for k, v in value.items()]
    return [(str(k), str(v)) for k, v in value]
