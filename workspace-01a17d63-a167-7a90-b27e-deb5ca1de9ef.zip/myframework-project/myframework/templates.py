"""A small, original template engine.

Why write one instead of depending on Jinja2?
---------------------------------------------
The project goal is a framework that installs with **zero runtime
dependencies**.  The feature set required (interpolation, inheritance,
partials, autoescaping, loops, conditionals) is small and stable, so a focused
engine is cheaper than a dependency — and it lets MyFramework guarantee its own
escaping and sandboxing behaviour instead of inheriting another project's.

Design
------
* **Syntax** — ``{{ expression }}``, ``{% statement %}``, ``{# comment #}`` with
  Jinja-like statements: ``if/elif/else``, ``for/else``, ``block``, ``extends``,
  ``include``, ``set``, ``raw``.  Whitespace control with ``{{- -}}``.
* **Expressions** — parsed with the standard library :mod:`ast` module and then
  evaluated by a *restricted interpreter* in this file.  ``eval``/``exec`` are
  never used on template source, so a template cannot escalate beyond the
  expression nodes explicitly supported here (no lambdas, comprehensions,
  imports, assignments, walrus, ``__dunder__`` access, ...).
* **Filters** — ``{{ value|upper }}`` uses Python's ``|`` operator, so filters
  bind *looser* than arithmetic: ``{{ items|length > 1 }}`` works (comparison
  is looser still) and ``{{ x|default('a')|upper }}`` chains left to right.
  When a filter sits inside arithmetic, parenthesise it:
  ``{{ ('3'|int) + 1 }}``.  (Jinja binds filters tighter; the difference is
  visible only when arithmetic and filters are mixed in one expression.)
* **Safety** — output is HTML-escaped by default; attribute access to names
  starting with ``_`` is blocked; the file loader refuses paths that escape the
  template directory.
* **Errors** — missing variables raise :class:`UndefinedError` by default
  ("strict" mode) so typos surface immediately.  Set
  ``TEMPLATE_UNDEFINED = "lenient"`` for Jinja-style empty output, or use the
  ``default`` filter.

Not implemented (documented, not silently missing): macros, custom tags,
`{% filter %}` blocks, template-level block scoping subtleties, and automatic
calling of callables in expressions (use explicit parentheses).
"""

from __future__ import annotations

import ast
import json
import os
import re
from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from .exceptions import (
    SecurityError,
    TemplateNotFound,
    TemplateRuntimeError,
    TemplateSyntaxError,
    UndefinedError,
)
from .utils import Markup, escape, url_quote

__all__ = [
    "DEFAULT_FILTERS",
    "BaseLoader",
    "ChoiceLoader",
    "DictLoader",
    "Environment",
    "FileSystemLoader",
    "Template",
    "TemplateBody",
    "render_template_string",
]

_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


# ---------------------------------------------------------------------------
# Lexing
# ---------------------------------------------------------------------------
_OPENERS = {"{{": "}}", "{%": "%}", "{#": "#}"}
_RAW_END_RE = re.compile(r"\{%-?\s*endraw\s*-?%\}")


@dataclass
class Token:
    """A lexical token of the template source."""

    kind: str  # "text" | "var" | "block"
    value: str
    lineno: int
    trim_left: bool = False
    trim_right: bool = False


def tokenize(source: str) -> list[Token]:
    """Split template *source* into text/expression/statement tokens."""
    tokens: list[Token] = []
    position = 0
    lineno = 1
    length = len(source)

    while position < length:
        candidates = [
            (index, opener) for opener in _OPENERS if (index := source.find(opener, position)) != -1
        ]
        if not candidates:
            tokens.append(Token("text", source[position:], lineno))
            break
        index, opener = min(candidates)
        if index > position:
            text = source[position:index]
            tokens.append(Token("text", text, lineno))
            lineno += text.count("\n")
            position = index

        closer = _OPENERS[opener]
        content_start = index + 2
        trim_left = source.startswith("-", content_start)
        if trim_left:
            content_start += 1
        end = source.find(closer, content_start)
        if end == -1:
            raise TemplateSyntaxError(
                f"Unclosed '{opener}'; expected '{closer}' on the same block.", lineno=lineno
            )
        trim_right = end > content_start and source[end - 1] == "-"
        inner_end = end - 1 if trim_right else end
        inner = source[content_start:inner_end]
        kind = "var" if opener == "{{" else ("block" if opener == "{%" else "comment")

        if kind == "block" and inner.strip() == "raw":
            raw_start = end + 2
            match = _RAW_END_RE.search(source, raw_start)
            if match is None:
                raise TemplateSyntaxError(
                    "'raw' block is never closed with 'endraw'.", lineno=lineno
                )
            raw_text = source[raw_start : match.start()]
            if raw_text:
                tokens.append(Token("text", raw_text, lineno + 1))
            consumed = source[index : match.end()]
            lineno += consumed.count("\n")
            position = match.end()
            continue

        if kind != "comment":
            tokens.append(Token(kind, inner.strip(), lineno, trim_left, trim_right))

        consumed = source[index : end + 2]
        lineno += consumed.count("\n")
        position = end + 2

    # Apply whitespace control markers.
    for index, token in enumerate(tokens):
        if token.kind != "text":
            if token.trim_left and index > 0 and tokens[index - 1].kind == "text":
                tokens[index - 1].value = tokens[index - 1].value.rstrip()
            if token.trim_right and index + 1 < len(tokens) and tokens[index + 1].kind == "text":
                tokens[index + 1].value = tokens[index + 1].value.lstrip()
    return tokens


# ---------------------------------------------------------------------------
# Expression helpers
# ---------------------------------------------------------------------------
def split_filters(expression: str) -> tuple[str, list[str]]:
    """Split ``value|filter(1)|other`` into the base expression and filters.

    Pipes inside string literals, brackets or parentheses are ignored.
    """
    parts: list[str] = []
    current: list[str] = []
    depth = 0
    quote: str | None = None
    index = 0
    while index < len(expression):
        char = expression[index]
        if quote:
            current.append(char)
            if char == "\\" and index + 1 < len(expression):
                current.append(expression[index + 1])
                index += 2
                continue
            if char == quote:
                quote = None
            index += 1
            continue
        if char in "'\"":
            quote = char
            current.append(char)
        elif char in "([{":
            depth += 1
            current.append(char)
        elif char in ")]}":
            depth -= 1
            current.append(char)
        elif char == "|" and depth == 0:
            nxt = expression[index + 1 : index + 2]
            if nxt == "|":  # not a filter separator (there is no '||' operator)
                current.append("||")
                index += 2
                continue
            parts.append("".join(current))
            current = []
        else:
            current.append(char)
        index += 1
    parts.append("".join(current))
    base = parts[0].strip()
    return base, [part.strip() for part in parts[1:] if part.strip()]


_FILTER_CALL_RE = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)\s*(?:\((.*)\))?$", re.S)
_DEFAULT_FILTER_RE = re.compile(r"\|\s*(?:default|d)\s*\(")


def parse_filter(text: str, name: str) -> tuple[str, ast.Call]:
    """Parse ``name(args)`` into the filter name and an AST call node."""
    match = _FILTER_CALL_RE.match(text)
    if match is None:
        raise TemplateSyntaxError(f"Invalid filter syntax {text!r}.", name=name)
    filter_name = match.group(1)
    args_source = match.group(2) or ""
    try:
        parsed = ast.parse(f"_f({args_source})", mode="eval")
    except SyntaxError as exc:
        raise TemplateSyntaxError(
            f"Invalid arguments for filter {filter_name!r}: {exc.msg}", name=name
        ) from None
    assert isinstance(parsed.body, ast.Call)
    return filter_name, parsed.body


class Undefined:
    """Placeholder for a missing variable in ``lenient`` mode."""

    __slots__ = ("name",)

    def __init__(self, name: str = "") -> None:
        self.name = name

    def __bool__(self) -> bool:
        return False

    def __iter__(self) -> Iterable[Any]:
        return iter(())

    def __len__(self) -> int:
        return 0

    def __str__(self) -> str:
        return ""

    def __repr__(self) -> str:  # pragma: no cover - debugging convenience
        return f"Undefined({self.name!r})"

    def __getattr__(self, item: str) -> Undefined:
        if item.startswith("_"):
            raise AttributeError(item)
        return Undefined(f"{self.name}.{item}")

    def __getitem__(self, item: Any) -> Undefined:
        return Undefined(f"{self.name}[{item!r}]")


_BIN_OPS: dict[type[ast.operator], Callable[[Any, Any], Any]] = {
    ast.Add: lambda a, b: a + b,
    ast.Sub: lambda a, b: a - b,
    ast.Mult: lambda a, b: a * b,
    ast.Div: lambda a, b: a / b,
    ast.FloorDiv: lambda a, b: a // b,
    ast.Mod: lambda a, b: a % b,
    ast.Pow: lambda a, b: a**b,
}

_CMP_OPS: dict[type[ast.cmpop], Callable[[Any, Any], bool]] = {
    ast.Eq: lambda a, b: a == b,
    ast.NotEq: lambda a, b: a != b,
    ast.Lt: lambda a, b: a < b,
    ast.LtE: lambda a, b: a <= b,
    ast.Gt: lambda a, b: a > b,
    ast.GtE: lambda a, b: a >= b,
    ast.In: lambda a, b: a in b,
    ast.NotIn: lambda a, b: a not in b,
    ast.Is: lambda a, b: a is b,
    ast.IsNot: lambda a, b: a is not b,
}

_UNSUPPORTED_HINT = (
    "Supported expression features: names, literals, attribute/index access, calls, "
    "arithmetic, comparisons, boolean logic, conditional expressions and f-strings."
)


class RenderContext:
    """Variable scope used while rendering (supports nesting for loops)."""

    __slots__ = ("env", "parent", "template_name", "vars")

    def __init__(
        self,
        env: Environment,
        variables: Mapping[str, Any] | None = None,
        parent: RenderContext | None = None,
        template_name: str = "<string>",
    ) -> None:
        self.env = env
        self.vars: dict[str, Any] = dict(variables or {})
        self.parent = parent
        self.template_name = template_name

    def resolve(self, name: str) -> Any:
        """Look *name* up in this scope, then parent scopes, then globals.

        Raises
        ------
        KeyError
            When the name cannot be found (the evaluator decides whether that
            is an error or an ``Undefined`` placeholder).
        """
        context: RenderContext | None = self
        while context is not None:
            if name in context.vars:
                return context.vars[name]
            context = context.parent
        if name in self.env.globals:
            return self.env.globals[name]
        raise KeyError(name)

    def lookup(self, name: str) -> Any:
        """Resolve *name*, honouring the environment's undefined policy."""
        try:
            return self.resolve(name)
        except KeyError:
            if self.env.undefined == "lenient":
                return Undefined(name)
            known = sorted(self._all_names())
            raise UndefinedError(
                f"Template variable {name!r} is undefined in {self.template_name!r}. "
                f"Known names: {', '.join(known) or '<none>'}. "
                "Use the 'default' filter if the variable is optional."
            ) from None

    def _all_names(self) -> set[str]:
        names: set[str] = set(self.env.globals)
        context: RenderContext | None = self
        while context is not None:
            names.update(context.vars)
            context = context.parent
        return names

    def set(self, name: str, value: Any) -> None:
        """Assign a template-local variable."""
        self.vars[name] = value

    def child(self, variables: Mapping[str, Any] | None = None) -> RenderContext:
        """Create a nested scope (used by ``for`` loops and blocks)."""
        return RenderContext(self.env, variables, parent=self, template_name=self.template_name)


class Evaluator:
    """Evaluate a parsed expression against a :class:`RenderContext`.

    This is a whitelist interpreter: only the AST nodes handled below can be
    evaluated, which is what keeps template expressions from executing
    arbitrary Python.
    """

    def __init__(self, context: RenderContext, lenient: bool | None = None) -> None:
        self.context = context
        self.env = context.env
        # ``lenient`` overrides the environment policy for one evaluation; it is
        # used when re-evaluating an expression that contains ``|default(...)``.
        self.lenient = context.env.undefined == "lenient" if lenient is None else lenient

    def evaluate_source(self, source: str) -> Any:
        """Parse *source* as a Python expression and evaluate it."""
        try:
            tree = ast.parse(source.strip(), mode="eval")
        except SyntaxError as exc:
            raise TemplateSyntaxError(
                f"Invalid expression {source.strip()!r}: {exc.msg}",
                name=self.context.template_name,
                lineno=getattr(exc, "lineno", 0) or 0,
            ) from None
        return self.evaluate(tree.body)

    def evaluate(self, node: ast.AST) -> Any:
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            try:
                return self.context.resolve(node.id)
            except KeyError:
                if self.lenient:
                    return Undefined(node.id)
                known = sorted(self.context._all_names())
                raise UndefinedError(
                    f"Template variable {node.id!r} is undefined in "
                    f"{self.context.template_name!r}. "
                    f"Known names: {', '.join(known) or '<none>'}. "
                    "Use the 'default' filter if the variable is optional."
                ) from None
        if isinstance(node, ast.Attribute):
            return self._getattr(self.evaluate(node.value), node.attr)
        if isinstance(node, ast.Subscript):
            container = self.evaluate(node.value)
            slice_node = node.slice
            key = self.evaluate(slice_node)
            try:
                return container[key]
            except (KeyError, IndexError, TypeError):
                if self.lenient:
                    return Undefined(f"[{key!r}]")
                raise TemplateRuntimeError(
                    f"Cannot look up {key!r} in {type(container).__name__} in "
                    f"{self.context.template_name!r}."
                ) from None
        if isinstance(node, ast.Slice):
            lower = self.evaluate(node.lower) if node.lower else None
            upper = self.evaluate(node.upper) if node.upper else None
            step = self.evaluate(node.step) if node.step else None
            return slice(lower, upper, step)
        if isinstance(node, ast.Tuple):
            return tuple(self.evaluate(item) for item in node.elts)
        if isinstance(node, ast.List):
            return [self.evaluate(item) for item in node.elts]
        if isinstance(node, ast.Set):
            return {self.evaluate(item) for item in node.elts}
        if isinstance(node, ast.Dict):
            result: dict[Any, Any] = {}
            for key_node, value_node in zip(node.keys, node.values, strict=True):
                if key_node is None:  # ``{**other}`` unpacking
                    raise TemplateRuntimeError(
                        "Dictionary unpacking (**) is not supported in templates."
                    )
                result[self.evaluate(key_node)] = self.evaluate(value_node)
            return result
        if isinstance(node, ast.Call):
            return self._call(node)
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.BitOr):
            # ``value|filter`` — Python's own precedence gives exactly the
            # filter semantics we want (filters bind tighter than operators).
            return self._apply_filter(self.evaluate(node.left), node.right)
        if isinstance(node, ast.BinOp):
            operation = _BIN_OPS.get(type(node.op))
            if operation is None:
                raise TemplateRuntimeError(
                    f"Operator {type(node.op).__name__} is not supported in templates."
                )
            return operation(self.evaluate(node.left), self.evaluate(node.right))
        if isinstance(node, ast.UnaryOp):
            operand = self.evaluate(node.operand)
            if isinstance(node.op, ast.USub):
                return -operand
            if isinstance(node.op, ast.UAdd):
                return +operand
            if isinstance(node.op, ast.Not):
                return not operand
            raise TemplateRuntimeError(f"Operator {type(node.op).__name__} is not supported.")
        if isinstance(node, ast.BoolOp):
            values = [self.evaluate(value) for value in node.values]
            if isinstance(node.op, ast.And):
                last: Any = True
                for value in values:
                    last = value
                    if not value:
                        return last
                return last
            for value in values:
                if value:
                    return value
            return values[-1] if values else False
        if isinstance(node, ast.Compare):
            left = self.evaluate(node.left)
            for operation_node, comparator in zip(node.ops, node.comparators, strict=True):
                operation = _CMP_OPS.get(type(operation_node))
                if operation is None:
                    raise TemplateRuntimeError(
                        f"Comparison {type(operation_node).__name__} is not supported."
                    )
                right = self.evaluate(comparator)
                if not operation(left, right):
                    return False
                left = right
            return True
        if isinstance(node, ast.IfExp):
            return (
                self.evaluate(node.body) if self.evaluate(node.test) else self.evaluate(node.orelse)
            )
        if isinstance(node, ast.JoinedStr):
            return "".join(self._fstring_part(part) for part in node.values)
        if isinstance(node, ast.FormattedValue):
            return self._fstring_part(node)
        raise TemplateRuntimeError(
            f"Template expressions cannot use {type(node).__name__}. {_UNSUPPORTED_HINT}"
        )

    def _fstring_part(self, node: ast.AST) -> str:
        if isinstance(node, ast.Constant):
            return str(node.value)
        if isinstance(node, ast.FormattedValue):
            value = self.evaluate(node.value)
            if node.format_spec is not None:
                return format(value, self._fstring_part(node.format_spec))
            return str(value)
        return str(self.evaluate(node))

    def _apply_filter(self, value: Any, node: ast.AST) -> Any:
        """Apply a filter described by the right-hand side of a ``|``."""
        if isinstance(node, ast.Name):
            name, call_node = node.id, None
        elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            name, call_node = node.func.id, node
        elif isinstance(node, ast.BinOp):
            raise TemplateRuntimeError(
                "In MyFramework a filter applies to everything on its left, so "
                "'x|filter + 1' is ambiguous. Add parentheses, e.g. {{ (x|filter) + 1 }}."
            )
        else:
            raise TemplateRuntimeError(
                "Filters must be named, e.g. {{ value|upper }} or {{ value|truncate(20) }}."
            )
        function = self.env.filters.get(name)
        if function is None:
            raise TemplateRuntimeError(
                f"Unknown template filter {name!r} in {self.context.template_name!r}. "
                f"Available filters: {', '.join(sorted(self.env.filters))}."
            )
        args: list[Any] = []
        kwargs: dict[str, Any] = {}
        if call_node is not None:
            args = [self.evaluate(item) for item in call_node.args]
            kwargs = {kw.arg: self.evaluate(kw.value) for kw in call_node.keywords if kw.arg}
        try:
            return function(value, *args, **kwargs)
        except (TypeError, ValueError) as exc:
            raise TemplateRuntimeError(
                f"Filter {name!r} failed on value {value!r}: {exc}"
            ) from None

    def _getattr(self, target: Any, attribute: str) -> Any:
        if attribute.startswith("_"):
            raise TemplateRuntimeError(
                f"Access to private attribute {attribute!r} is not allowed in templates."
            )
        if isinstance(target, Mapping) and attribute in target:
            return target[attribute]
        try:
            return getattr(target, attribute)
        except AttributeError:
            if self.lenient:
                return Undefined(attribute)
            raise TemplateRuntimeError(
                f"{type(target).__name__!r} object has no attribute {attribute!r} "
                f"(in {self.context.template_name!r})."
            ) from None

    def _call(self, node: ast.Call) -> Any:
        if isinstance(node.func, ast.Attribute) and node.func.attr.startswith("_"):
            raise TemplateRuntimeError(
                f"Calling private method {node.func.attr!r} is not allowed in templates."
            )
        function = self.evaluate(node.func)
        if not callable(function):
            raise TemplateRuntimeError(
                f"{type(function).__name__!r} object is not callable "
                f"(in {self.context.template_name!r})."
            )
        args = [self.evaluate(item) for item in node.args]
        if any(isinstance(item, ast.Starred) for item in node.args):
            raise TemplateRuntimeError("Star-arguments are not supported in template calls.")
        kwargs = {}
        for keyword in node.keywords:
            if keyword.arg is None:
                raise TemplateRuntimeError("**kwargs are not supported in template calls.")
            kwargs[keyword.arg] = self.evaluate(keyword.value)
        try:
            return function(*args, **kwargs)
        except TypeError as exc:
            raise TemplateRuntimeError(
                f"Error calling {getattr(function, '__name__', function)!r}: {exc}"
            ) from None


def evaluate_expression(source: str, context: RenderContext) -> Any:
    """Evaluate *source* (filters included) in *context*.

    Used by ``{{ }}``, ``{% if %}``, ``{% for %}`` and ``{% set %}`` so filters
    work everywhere an expression is allowed.

    ``|`` is interpreted as a filter application, exactly like Jinja: it binds
    tighter than arithmetic and comparisons.  This is why ``'|'`` inside a
    string literal never starts a filter and why filters compose left to right.
    """
    evaluator = Evaluator(context)
    try:
        return evaluator.evaluate_source(source)
    except UndefinedError:
        # ``{{ missing|default('x') }}`` must work even in strict mode: retry
        # with undefined-tolerant lookups so the filter can supply a value.
        if not _DEFAULT_FILTER_RE.search(source):
            raise
        return Evaluator(context, lenient=True).evaluate_source(source)


# ---------------------------------------------------------------------------
# Filters
# ---------------------------------------------------------------------------
def _filter_default(value: Any, default_value: Any = "", boolean: bool = False) -> Any:
    if isinstance(value, Undefined) or (boolean and not value):
        return default_value
    return value


def _filter_truncate(
    value: Any, length: int = 255, end: str = "...", killwords: bool = False
) -> str:
    text = str(value)
    if len(text) <= length:
        return text
    if killwords:
        return text[: max(0, length - len(end))] + end
    truncated = text[: max(0, length - len(end))].rsplit(" ", 1)[0]
    return (truncated or text[: max(0, length - len(end))]) + end


def _filter_tojson(value: Any, indent: int | None = None) -> Markup:
    # Escape <, >, & so the JSON can be embedded in a <script> block safely.
    text = json.dumps(value, ensure_ascii=False, indent=indent, default=str)
    text = text.replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
    return Markup(text)


def _filter_join(value: Iterable[Any], separator: str = "") -> str:
    return separator.join(str(item) for item in value)


DEFAULT_FILTERS: dict[str, Callable[..., Any]] = {
    "e": escape,
    "escape": escape,
    "safe": lambda value: Markup(str(value)),
    "upper": lambda value: str(value).upper(),
    "lower": lambda value: str(value).lower(),
    "title": lambda value: str(value).title(),
    "capitalize": lambda value: str(value).capitalize(),
    "trim": lambda value: str(value).strip(),
    "striptags": lambda value: re.sub(r"<[^>]*>", "", str(value)),
    "length": len,
    "count": len,
    "default": _filter_default,
    "d": _filter_default,
    "join": _filter_join,
    "replace": lambda value, old, new, count=-1: str(value).replace(old, new, count),
    "truncate": _filter_truncate,
    "int": lambda value, default=0: _safe_cast(int, value, default),
    "float": lambda value, default=0.0: _safe_cast(float, value, default),
    "round": lambda value, precision=0: round(float(value), precision),
    "abs": abs,
    "first": lambda value: next(iter(value), Undefined("first")),
    "last": lambda value: list(value)[-1] if list(value) else Undefined("last"),
    "reverse": lambda value: list(reversed(list(value))),
    "sort": lambda value, reverse=False, attribute=None: sorted(
        value, reverse=reverse, key=(lambda item: item.get(attribute)) if attribute else None
    ),
    "list": lambda value: list(value),
    "string": str,
    "urlencode": lambda value: url_quote(value, safe=""),
    "tojson": _filter_tojson,
    "attr": lambda value, name: getattr(value, name),
    "nl2br": lambda value: Markup("<br>".join(escape(str(value)).splitlines())),
}


def _safe_cast(factory: Callable[[Any], Any], value: Any, default: Any) -> Any:
    try:
        return factory(value)
    except (TypeError, ValueError):
        return default


# ---------------------------------------------------------------------------
# AST nodes
# ---------------------------------------------------------------------------
class Node:
    """Base class for template nodes."""

    lineno: int = 0

    def render(
        self, context: RenderContext, out: list[str], blocks: list[dict[str, BlockNode]]
    ) -> None:
        raise NotImplementedError


class TextNode(Node):
    """Literal template text."""

    __slots__ = ("lineno", "value")

    def __init__(self, value: str, lineno: int = 0) -> None:
        self.value = value
        self.lineno = lineno

    def render(
        self, context: RenderContext, out: list[str], blocks: list[dict[str, BlockNode]]
    ) -> None:
        out.append(self.value)


class OutputNode(Node):
    """``{{ expression }}`` — evaluates and escapes one expression."""

    __slots__ = ("expression", "lineno")

    def __init__(self, expression: str, lineno: int = 0, template_name: str = "<string>") -> None:
        self.expression = expression
        self.lineno = lineno
        if not expression.strip():
            raise TemplateSyntaxError(
                "Empty expression in '{{ }}'.", name=template_name, lineno=lineno
            )

    def render(
        self, context: RenderContext, out: list[str], blocks: list[dict[str, BlockNode]]
    ) -> None:
        value = evaluate_expression(self.expression, context)
        if context.env.autoescape and not isinstance(value, Markup):
            out.append(str(escape(value)))
        else:
            out.append(str(value))


class IfNode(Node):
    """``{% if %}`` / ``{% elif %}`` / ``{% else %}``."""

    __slots__ = ("branches", "else_body", "lineno")

    def __init__(
        self,
        branches: Sequence[tuple[str, list[Node]]],
        else_body: list[Node] | None,
        lineno: int = 0,
    ) -> None:
        self.branches = list(branches)
        self.else_body = else_body or []
        self.lineno = lineno

    def render(
        self, context: RenderContext, out: list[str], blocks: list[dict[str, BlockNode]]
    ) -> None:
        for condition, body in self.branches:
            if evaluate_expression(condition, context):
                _render_nodes(body, context, out, blocks)
                return
        _render_nodes(self.else_body, context, out, blocks)


class LoopContext:
    """The ``loop`` variable available inside ``{% for %}``."""

    __slots__ = ("_items", "index0")

    def __init__(self, items: list[Any]) -> None:
        self._items = items
        self.index0 = 0

    @property
    def index(self) -> int:
        return self.index0 + 1

    @property
    def first(self) -> bool:
        return self.index0 == 0

    @property
    def last(self) -> bool:
        return self.index0 == len(self._items) - 1

    @property
    def length(self) -> int:
        return len(self._items)

    @property
    def revindex(self) -> int:
        return len(self._items) - self.index0

    @property
    def revindex0(self) -> int:
        return len(self._items) - self.index0 - 1

    @property
    def previtem(self) -> Any:
        return self._items[self.index0 - 1] if self.index0 > 0 else Undefined("previtem")

    @property
    def nextitem(self) -> Any:
        if self.index0 + 1 < len(self._items):
            return self._items[self.index0 + 1]
        return Undefined("nextitem")

    def cycle(self, *values: Any) -> Any:
        """Return ``values[index % len(values)]`` for the current iteration."""
        if not values:
            return Undefined("cycle")
        return values[self.index0 % len(values)]


class ForNode(Node):
    """``{% for target in iterable %}`` with optional ``{% else %}``."""

    __slots__ = ("body", "else_body", "iterable_source", "lineno", "targets")

    def __init__(
        self,
        targets: list[str],
        iterable_source: str,
        body: list[Node],
        else_body: list[Node],
        lineno: int = 0,
    ) -> None:
        self.targets = targets
        self.iterable_source = iterable_source
        self.body = body
        self.else_body = else_body
        self.lineno = lineno

    def render(
        self, context: RenderContext, out: list[str], blocks: list[dict[str, BlockNode]]
    ) -> None:
        iterable = evaluate_expression(self.iterable_source, context)
        if isinstance(iterable, Undefined):
            items: list[Any] = []
        elif isinstance(iterable, Mapping):
            items = list(iterable.items())
        else:
            try:
                items = list(iterable)
            except TypeError:
                raise TemplateRuntimeError(
                    f"Cannot iterate over {type(iterable).__name__!r} in "
                    f"{context.template_name!r} (line {self.lineno})."
                ) from None
        if not items:
            _render_nodes(self.else_body, context, out, blocks)
            return
        loop = LoopContext(items)
        for index, item in enumerate(items):
            loop.index0 = index
            scope = {"loop": loop}
            if len(self.targets) == 1:
                scope[self.targets[0]] = item
            else:
                try:
                    values = list(item)
                except TypeError:
                    raise TemplateRuntimeError(
                        f"Cannot unpack {item!r} into {len(self.targets)} names "
                        f"(line {self.lineno})."
                    ) from None
                if len(values) != len(self.targets):
                    raise TemplateRuntimeError(
                        f"Cannot unpack {len(values)} values into {len(self.targets)} names "
                        f"(line {self.lineno})."
                    )
                scope.update(zip(self.targets, values, strict=True))
            _render_nodes(self.body, context.child(scope), out, blocks)


class SetNode(Node):
    """``{% set name = expression %}``."""

    __slots__ = ("expression", "lineno", "name")

    def __init__(self, name: str, expression: str, lineno: int = 0) -> None:
        self.name = name
        self.expression = expression
        self.lineno = lineno

    def render(
        self, context: RenderContext, out: list[str], blocks: list[dict[str, BlockNode]]
    ) -> None:
        context.set(self.name, evaluate_expression(self.expression, context))


class IncludeNode(Node):
    """``{% include "partial.html" %}`` (optionally ``ignore missing``)."""

    __slots__ = ("expression", "ignore_missing", "lineno")

    def __init__(self, expression: str, ignore_missing: bool = False, lineno: int = 0) -> None:
        self.expression = expression
        self.ignore_missing = ignore_missing
        self.lineno = lineno

    def render(
        self, context: RenderContext, out: list[str], blocks: list[dict[str, BlockNode]]
    ) -> None:
        name = evaluate_expression(self.expression, context)
        if not isinstance(name, str):
            raise TemplateRuntimeError(
                f"include expects a template name string, got {type(name).__name__!r}."
            )
        try:
            template = context.env.get_template(name)
        except TemplateNotFound:
            if self.ignore_missing:
                return
            raise
        include_context = RenderContext(
            context.env,
            {"template_name": name},
            parent=context,
            template_name=name,
        )
        out.append(render_body(template.body, include_context, []))


class BlockNode(Node):
    """``{% block name %}`` — overridable by child templates.

    The block chain is ordered from the most-ancestor template to the most
    derived one, so the *last* definition of a name wins and ``{{ super() }}``
    walks one step towards the ancestors.
    """

    __slots__ = ("body", "lineno", "name")

    def __init__(self, name: str, body: list[Node], lineno: int = 0) -> None:
        self.name = name
        self.body = body
        self.lineno = lineno

    def render(
        self, context: RenderContext, out: list[str], blocks: list[dict[str, BlockNode]]
    ) -> None:
        found = _find_block(blocks, self.name, len(blocks) - 1)
        if found is None:
            out.append(self._render_definition(self, context, blocks, -1))
            return
        node, level = found
        out.append(self._render_definition(node, context, blocks, level))

    def _render_definition(
        self,
        node: BlockNode,
        context: RenderContext,
        blocks: list[dict[str, BlockNode]],
        level: int,
    ) -> str:
        def _super() -> Markup:
            found = _find_block(blocks, node.name, level - 1)
            if found is None:
                return Markup("")
            parent_node, parent_level = found
            return Markup(
                parent_node._render_definition(parent_node, context, blocks, parent_level)
            )

        scope = context.child({"super": _super})
        parts: list[str] = []
        _render_nodes(node.body, scope, parts, blocks)
        return "".join(parts)


def _find_block(
    blocks: list[dict[str, BlockNode]], name: str, highest: int
) -> tuple[BlockNode, int] | None:
    """Find the most derived definition of *name* at or below *highest*."""
    for index in range(min(highest, len(blocks) - 1), -1, -1):
        if name in blocks[index]:
            return blocks[index][name], index
    return None


def _render_nodes(
    nodes: Iterable[Node],
    context: RenderContext,
    out: list[str],
    blocks: list[dict[str, BlockNode]],
) -> None:
    for node in nodes:
        node.render(context, out, blocks)


@dataclass
class TemplateBody:
    """The parsed representation of one template file."""

    nodes: list[Node] = field(default_factory=list)
    blocks: dict[str, BlockNode] = field(default_factory=dict)
    extends: str | None = None
    extends_lineno: int = 0


def render_body(
    body: TemplateBody, context: RenderContext, blocks: list[dict[str, BlockNode]]
) -> str:
    """Render a parsed template body, resolving inheritance first."""
    chain = [body.blocks, *blocks]
    if body.extends is not None:
        parent_name = Evaluator(context).evaluate_source(body.extends)
        if not isinstance(parent_name, str):
            raise TemplateRuntimeError(
                f"extends expects a template name string, got {type(parent_name).__name__!r}."
            )
        parent = context.env.get_template(parent_name)
        return render_body(parent.body, context, chain)
    out: list[str] = []
    _render_nodes(body.nodes, context, out, chain)
    return "".join(out)


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------
class TemplateParser:
    """Turn template source into a :class:`TemplateBody`."""

    def __init__(self, source: str, name: str = "<string>") -> None:
        self.source = source
        self.name = name
        self.tokens = tokenize(source)
        self.index = 0
        self.blocks: dict[str, BlockNode] = {}
        self._extends: str | None = None
        self._extends_lineno = 0

    # -- public -----------------------------------------------------------
    def parse(self) -> TemplateBody:
        nodes, terminator = self._parse_body(set())
        if terminator is not None:
            raise self._error(f"Unexpected '{{% {terminator.value} %}}'.", terminator)
        return TemplateBody(
            nodes=nodes,
            blocks=self.blocks,
            extends=self._extends,
            extends_lineno=self._extends_lineno,
        )

    # -- helpers ---------------------------------------------------------
    def _error(self, message: str, token: Token | None = None) -> TemplateSyntaxError:
        return TemplateSyntaxError(message, name=self.name, lineno=token.lineno if token else 0)

    def _consume(self) -> Token:
        token = self.tokens[self.index]
        self.index += 1
        return token

    def _parse_body(self, stop: set[str]) -> tuple[list[Node], Token | None]:
        nodes: list[Node] = []
        while self.index < len(self.tokens):
            token = self.tokens[self.index]
            if token.kind == "text":
                nodes.append(TextNode(token.value, token.lineno))
                self.index += 1
                continue
            if token.kind == "var":
                nodes.append(OutputNode(token.value, token.lineno, self.name))
                self.index += 1
                continue
            keyword, _, rest = token.value.partition(" ")
            keyword = keyword.strip()
            rest = rest.strip()
            if keyword in stop:
                return nodes, token
            handler = getattr(self, f"_parse_{keyword}", None)
            if handler is None:
                raise self._error(
                    f"Unknown template tag '{{% {keyword} %}}'. Supported tags: if, for, block, "
                    "extends, include, set, raw.",
                    token,
                )
            node = handler(token, rest)
            if node is not None:
                nodes.append(node)
        return nodes, None

    # -- statements ------------------------------------------------------
    def _parse_if(self, token: Token, rest: str) -> Node:
        if not rest:
            raise self._error("'if' requires a condition.", token)
        self._consume()
        branches: list[tuple[str, list[Node]]] = []
        condition = rest
        while True:
            body, terminator = self._parse_body({"elif", "else", "endif"})
            branches.append((condition, body))
            if terminator is None:
                raise self._error("'if' is never closed with 'endif'.", token)
            keyword, _, new_condition = terminator.value.partition(" ")
            keyword = keyword.strip()
            self._consume()
            if keyword == "elif":
                condition = new_condition.strip()
                if not condition:
                    raise self._error("'elif' requires a condition.", terminator)
                continue
            if keyword == "else":
                else_body, end = self._parse_body({"endif"})
                if end is None:
                    raise self._error("'if' is never closed with 'endif'.", token)
                self._consume()
                return IfNode(branches, else_body, token.lineno)
            return IfNode(branches, None, token.lineno)

    def _parse_for(self, token: Token, rest: str) -> Node:
        match = re.match(r"^(.*?)\s+in\s+(.*)$", rest, re.S)
        if match is None:
            raise self._error("'for' must look like: for item in items", token)
        target_text = match.group(1).strip()
        iterable_source = match.group(2).strip()
        if not iterable_source:
            raise self._error("'for' is missing the iterable expression.", token)
        targets = [part.strip() for part in target_text.strip("()[] ").split(",")]
        for target in targets:
            if not _NAME_RE.match(target):
                raise self._error(
                    f"Invalid loop variable {target!r}; use plain names or a tuple of names.", token
                )
        self._consume()
        body, terminator = self._parse_body({"else", "endfor"})
        else_body: list[Node] = []
        if terminator is not None and terminator.value.split(" ")[0].strip() == "else":
            self._consume()
            else_body, terminator = self._parse_body({"endfor"})
        if terminator is None:
            raise self._error("'for' is never closed with 'endfor'.", token)
        self._consume()
        return ForNode(targets, iterable_source, body, else_body, token.lineno)

    def _parse_block(self, token: Token, rest: str) -> Node:
        name = rest.split(" ")[0].strip()
        if not _NAME_RE.match(name):
            raise self._error(f"Invalid block name {rest!r}.", token)
        self._consume()
        body, terminator = self._parse_body({"endblock"})
        if terminator is None:
            raise self._error(f"Block {name!r} is never closed with 'endblock'.", token)
        trailing = terminator.value.partition(" ")[2].strip()
        if trailing and trailing != name:
            raise self._error(f"'endblock {trailing}' does not match 'block {name}'.", terminator)
        self._consume()
        node = BlockNode(name, body, token.lineno)
        self.blocks.setdefault(name, node)
        return node

    def _parse_extends(self, token: Token, rest: str) -> Node | None:
        if not rest:
            raise self._error("'extends' requires a template name.", token)
        if self._extends is not None:
            raise self._error("A template may only extend one parent template.", token)
        self._extends = rest
        self._extends_lineno = token.lineno
        self._consume()
        return None

    def _parse_include(self, token: Token, rest: str) -> Node:
        ignore_missing = False
        expression = rest
        if rest.endswith("ignore missing"):
            ignore_missing = True
            expression = rest[: -len("ignore missing")].strip()
        if not expression:
            raise self._error("'include' requires a template name.", token)
        self._consume()
        return IncludeNode(expression, ignore_missing, token.lineno)

    def _parse_set(self, token: Token, rest: str) -> Node:
        name, separator, expression = rest.partition("=")
        name = name.strip()
        if not separator or not _NAME_RE.match(name) or not expression.strip():
            raise self._error("'set' must look like: set name = expression", token)
        self._consume()
        return SetNode(name, expression.strip(), token.lineno)

    def _parse_raw(self, token: Token, rest: str) -> Node:
        # ``raw`` blocks are handled by the tokenizer; reaching this means the
        # scanner saw an ``{% raw %}`` that has no matching ``{% endraw %}``.
        raise self._error("'raw' must be closed with 'endraw'.", token)


# ---------------------------------------------------------------------------
# Loaders
# ---------------------------------------------------------------------------
class BaseLoader:
    """Base class for template loaders."""

    def get_source(
        self, environment: Environment, template: str
    ) -> tuple[str, str | None, Callable[[], bool]]:
        """Return ``(source, filename, up_to_date)`` for *template*.

        ``up_to_date`` is a zero-argument callable used by ``auto_reload``.
        """
        raise NotImplementedError

    def list_templates(self) -> list[str]:
        """Return all template names known to this loader (for tooling)."""
        return []


class FileSystemLoader(BaseLoader):
    """Load templates from one or more directories.

    Path traversal is blocked: names containing ``..`` segments, absolute
    paths, drive letters or backslashes are rejected, and the resolved file
    must live inside the configured directory.
    """

    def __init__(
        self,
        searchpath: str | os.PathLike[str] | Sequence[str | os.PathLike[str]],
        encoding: str = "utf-8",
        default_extension: str = ".html",
    ) -> None:
        if isinstance(searchpath, (str, os.PathLike)):
            searchpath = [searchpath]
        self.searchpath = [os.path.realpath(os.fspath(path)) for path in searchpath]
        self.encoding = encoding
        self.default_extension = default_extension

    @staticmethod
    def _normalise(template: str) -> str:
        name = template.replace("\\", "/").strip()
        if not name:
            raise TemplateNotFound(template)
        if name.startswith("/") or re.match(r"^[A-Za-z]:", name):
            raise SecurityError(f"Template name {template!r} must be relative.")
        if any(part in ("..", "") for part in name.split("/")):
            raise SecurityError(f"Template name {template!r} contains an unsafe path segment.")
        return name

    def _candidates(self, template: str) -> list[str]:
        name = self._normalise(template)
        if self.default_extension and not os.path.splitext(name)[1]:
            return [name + self.default_extension, name]
        return [name]

    def get_source(
        self, environment: Environment, template: str
    ) -> tuple[str, str | None, Callable[[], bool]]:
        searched: list[str] = []
        for candidate in self._candidates(template):
            for root in self.searchpath:
                path = os.path.realpath(os.path.join(root, candidate))
                searched.append(path)
                if not (path == root or path.startswith(root + os.sep)):
                    raise SecurityError(
                        f"Template {template!r} resolves outside the template directory."
                    )
                if os.path.isfile(path):
                    try:
                        with open(path, encoding=self.encoding) as handle:
                            source = handle.read()
                    except OSError as exc:
                        raise TemplateNotFound(template, searched) from exc
                    mtime = os.path.getmtime(path)

                    def up_to_date(mtime: float = mtime, path: str = path) -> bool:
                        try:
                            return os.path.getmtime(path) == mtime
                        except OSError:
                            return False

                    return source, path, up_to_date
        raise TemplateNotFound(template, searched)

    def list_templates(self) -> list[str]:
        names: list[str] = []
        for root in self.searchpath:
            for dirpath, _dirnames, filenames in os.walk(root):
                for filename in filenames:
                    if filename.endswith(self.default_extension):
                        full = os.path.join(dirpath, filename)
                        names.append(os.path.relpath(full, root).replace(os.sep, "/"))
        return sorted(names)


class DictLoader(BaseLoader):
    """Load templates from a dictionary — handy for tests and small apps."""

    def __init__(self, mapping: Mapping[str, str]) -> None:
        self.mapping = {key.replace("\\", "/"): value for key, value in mapping.items()}

    def get_source(
        self, environment: Environment, template: str
    ) -> tuple[str, str | None, Callable[[], bool]]:
        name = template.replace("\\", "/").lstrip("/")
        for candidate in (name, name + ".html"):
            if candidate in self.mapping:
                return self.mapping[candidate], None, lambda: True
        raise TemplateNotFound(template, sorted(self.mapping))

    def list_templates(self) -> list[str]:
        return sorted(self.mapping)


class ChoiceLoader(BaseLoader):
    """Try several loaders in order."""

    def __init__(self, loaders: Sequence[BaseLoader]) -> None:
        self.loaders = list(loaders)

    def get_source(
        self, environment: Environment, template: str
    ) -> tuple[str, str | None, Callable[[], bool]]:
        for loader in self.loaders:
            try:
                return loader.get_source(environment, template)
            except TemplateNotFound:
                continue
        raise TemplateNotFound(template)

    def list_templates(self) -> list[str]:
        names: set[str] = set()
        for loader in self.loaders:
            names.update(loader.list_templates())
        return sorted(names)


# ---------------------------------------------------------------------------
# Environment and Template
# ---------------------------------------------------------------------------
class Template:
    """A compiled template.

    >>> from myframework.templates import Environment, DictLoader
    >>> env = Environment(loader=DictLoader({"hello.html": "Hi {{ name }}!"}))
    >>> env.get_template("hello.html").render(name="<b>Ada</b>")
    'Hi &lt;b&gt;Ada&lt;/b&gt;!'
    """

    def __init__(
        self, environment: Environment, name: str, source: str, filename: str | None = None
    ) -> None:
        self.env = environment
        self.name = name
        self.filename = filename
        self.source = source
        self.body: TemplateBody = TemplateParser(source, name).parse()

    def render(self, context: Mapping[str, Any] | None = None, **kwargs: Any) -> str:
        """Render the template with *context* plus keyword arguments."""
        variables = dict(context or {})
        variables.update(kwargs)
        scope = RenderContext(self.env, variables, template_name=self.name)
        return render_body(self.body, scope, [])

    def __repr__(self) -> str:  # pragma: no cover - debugging convenience
        return f"<Template {self.name!r}>"


class Environment:
    """Holds template configuration: loader, filters, globals, autoescaping.

    Parameters
    ----------
    loader:
        A :class:`BaseLoader` (``FileSystemLoader``, ``DictLoader``, ...).
    autoescape:
        Escape ``{{ }}`` output by default.  Turning this off is a security
        decision — do not do it for HTML templates that include user input.
    undefined:
        ``"strict"`` (default) raises :class:`UndefinedError` for missing
        variables, ``"lenient"`` renders them as empty strings.
    auto_reload:
        Re-read templates when their modification time changes (enabled
        automatically in debug mode by the application).
    """

    def __init__(
        self,
        loader: BaseLoader | None = None,
        autoescape: bool = True,
        undefined: str = "strict",
        auto_reload: bool = False,
        cache_size: int = 400,
        filters: Mapping[str, Callable[..., Any]] | None = None,
        globals: Mapping[str, Any] | None = None,
    ) -> None:
        if undefined not in ("strict", "lenient"):
            raise ValueError("undefined must be 'strict' or 'lenient'")
        self.loader = loader
        self.autoescape = autoescape
        self.undefined = undefined
        self.auto_reload = auto_reload
        self.cache_size = cache_size
        self.filters: dict[str, Callable[..., Any]] = dict(DEFAULT_FILTERS)
        if filters:
            self.filters.update(filters)
        self.globals: dict[str, Any] = {
            "range": range,
            "dict": dict,
            "list": list,
            "len": len,
            "str": str,
            "int": int,
            "float": float,
            "enumerate": enumerate,
            "zip": zip,
            "sorted": sorted,
            "min": min,
            "max": max,
            "sum": sum,
            "escape": escape,
            "Markup": Markup,
        }
        if globals:
            self.globals.update(globals)
        self._cache: dict[str, tuple[Template, Callable[[], bool]]] = {}

    # -- template access --------------------------------------------------
    def get_template(self, name: str) -> Template:
        """Return a (cached) template by name."""
        cached = self._cache.get(name)
        if cached is not None:
            template, up_to_date = cached
            if not self.auto_reload or up_to_date():
                return template
        if self.loader is None:
            raise TemplateNotFound(name, ["<no loader configured>"])
        source, filename, up_to_date = self.loader.get_source(self, name)
        template = Template(self, name, source, filename)
        if len(self._cache) >= max(self.cache_size, 1):
            self._cache.pop(next(iter(self._cache)))
        self._cache[name] = (template, up_to_date)
        return template

    def select_template(self, names: Iterable[str]) -> Template:
        """Return the first template that exists in *names*."""
        last_error: TemplateNotFound | None = None
        for name in names:
            try:
                return self.get_template(name)
            except TemplateNotFound as exc:
                last_error = exc
        raise last_error or TemplateNotFound(", ".join(names))

    def from_string(self, source: str, name: str = "<string>") -> Template:
        """Compile template *source* directly (not cached)."""
        return Template(self, name, source)

    def render_string(
        self, source: str, context: Mapping[str, Any] | None = None, **kwargs: Any
    ) -> str:
        """Compile and render *source* in one call."""
        return self.from_string(source).render(context, **kwargs)

    def render(self, name: str, context: Mapping[str, Any] | None = None, **kwargs: Any) -> str:
        """Render the named template."""
        return self.get_template(name).render(context, **kwargs)

    def list_templates(self) -> list[str]:
        """Return every template name the loader can see."""
        return self.loader.list_templates() if self.loader else []

    def clear_cache(self) -> None:
        """Drop cached templates (useful after editing templates in tests)."""
        self._cache.clear()


def render_template_string(source: str, **context: Any) -> str:
    """Render a template from a string with autoescaping enabled (no loader)."""
    return Environment().from_string(source).render(context)
