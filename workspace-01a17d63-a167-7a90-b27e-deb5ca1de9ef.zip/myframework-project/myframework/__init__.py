"""MyFramework — a small, dependency-free Python web framework with native WSGI support.

Quick start::

    from myframework import App, request, Response

    app = App()

    @app.route("/")
    def home():
        return "<h1>My Website</h1>"

    if __name__ == "__main__":
        app.run(debug=True)

The package is organised in layers:

===================  ==================================================
:mod:`app`           Application object, dispatch, hooks, errors
:mod:`request`       WSGI environ -> ``Request``
:mod:`response`      ``Response``, ``jsonify``, ``redirect``, ``abort``
:mod:`routing`       Rules, converters, URL building
:mod:`wsgi`          PEP 3333 helpers and validation
:mod:`devserver`     Threaded development server with auto-reload
:mod:`middleware`    WSGI middleware (CORS, security headers, proxy fix, ...)
:mod:`templates`     Template engine with inheritance and autoescaping
:mod:`static`        Safe static file serving
:mod:`config`        Configuration defaults and loading
:mod:`globals`       ``request`` / ``g`` / ``current_app`` proxies
:mod:`exceptions`    HTTP and framework exceptions
:mod:`testing`       Test client
:mod:`cli`           ``myframework`` command line interface
===================  ==================================================
"""

from __future__ import annotations

from .app import App
from .config import Config
from .datastructures import FileStorage, Headers, MultiDict
from .exceptions import (
    BadRequest,
    ConfigurationError,
    Conflict,
    Forbidden,
    FrameworkException,
    HTTPException,
    InternalServerError,
    MethodNotAllowed,
    NotFound,
    PayloadTooLarge,
    RequestRedirect,
    RoutingError,
    SecurityError,
    ServiceUnavailable,
    TemplateError,
    TemplateNotFound,
    TemplateRuntimeError,
    TemplateSyntaxError,
    Unauthorized,
    UndefinedError,
    UnsupportedMediaType,
)
from .globals import current_app, g, has_request_context, render_template, request, url_for
from .middleware import (
    AccessLogMiddleware,
    CORSMiddleware,
    HeaderMiddleware,
    HTTPSRedirectMiddleware,
    Middleware,
    ProxyFix,
    RequestIDMiddleware,
    SecurityHeadersMiddleware,
    TrustedHostMiddleware,
    WSGIMiddleware,
)
from .request import Request
from .response import Response, abort, jsonify, make_response, redirect, stream_response
from .routing import BaseConverter, Map, Rule
from .static import StaticFiles, safe_join, send_file, send_from_directory
from .templates import DictLoader, FileSystemLoader, render_template_string
from .templates import Environment as TemplateEnvironment
from .wsgi import WSGIApp, middleware_chain, serve_wsgiref, wsgi_application

__version__ = "0.1.0"

__all__ = [
    "AccessLogMiddleware",
    "App",
    "BadRequest",
    "BaseConverter",
    "CORSMiddleware",
    "Config",
    "ConfigurationError",
    "Conflict",
    "DictLoader",
    "FileStorage",
    "FileSystemLoader",
    "Forbidden",
    "FrameworkException",
    "HTTPException",
    "HTTPSRedirectMiddleware",
    "HeaderMiddleware",
    "Headers",
    "InternalServerError",
    "Map",
    "MethodNotAllowed",
    "Middleware",
    "MultiDict",
    "NotFound",
    "PayloadTooLarge",
    "ProxyFix",
    "Request",
    "RequestIDMiddleware",
    "RequestRedirect",
    "Response",
    "RoutingError",
    "Rule",
    "SecurityError",
    "SecurityHeadersMiddleware",
    "ServiceUnavailable",
    "StaticFiles",
    "TemplateEnvironment",
    "TemplateError",
    "TemplateNotFound",
    "TemplateRuntimeError",
    "TemplateSyntaxError",
    "TrustedHostMiddleware",
    "Unauthorized",
    "UndefinedError",
    "UnsupportedMediaType",
    "WSGIApp",
    "WSGIMiddleware",
    "__version__",
    "abort",
    "current_app",
    "g",
    "has_request_context",
    "jsonify",
    "make_response",
    "middleware_chain",
    "redirect",
    "render_template",
    "render_template_string",
    "request",
    "safe_join",
    "send_file",
    "send_from_directory",
    "serve_wsgiref",
    "stream_response",
    "url_for",
    "wsgi_application",
]
