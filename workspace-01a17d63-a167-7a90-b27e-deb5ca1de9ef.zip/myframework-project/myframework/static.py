"""Safe static file serving.

Security model
--------------
* The request path is percent-decoded, normalised and *rejected* if it contains
  a ``..`` segment, a NUL byte, a backslash or a Windows drive letter.
* The final path is resolved with :func:`os.path.realpath` and must still be
  inside the configured directory, which also blocks symlinks that point
  outside it.
* Only regular files are served; directories return ``404`` (no listings).
* Unknown extensions are served as ``application/octet-stream`` with
  ``Content-Disposition: attachment`` so the browser cannot be tricked into
  rendering an attacker-authored file inline.
* ``ETag``/``Last-Modified`` are sent and ``If-None-Match`` /
  ``If-Modified-Since`` produce ``304 Not Modified``.
"""

from __future__ import annotations

import hashlib
import os
import stat
from collections.abc import Iterable, Mapping
from typing import Any
from urllib.parse import unquote

from .exceptions import NotFound, SecurityError
from .response import Response
from .utils import guess_mimetype, http_date, parse_http_date

__all__ = ["StaticFiles", "safe_join", "send_file", "send_from_directory"]

#: Extensions that are always served as downloads rather than rendered inline.
_FORCE_DOWNLOAD_EXTENSIONS = {
    ".exe",
    ".dll",
    ".bat",
    ".cmd",
    ".sh",
    ".ps1",
    ".msi",
    ".jar",
    ".com",
    ".scr",
}


def safe_join(directory: str, path: str) -> str:
    """Resolve *path* inside *directory* or raise :class:`SecurityError`.

    ``directory`` should be an absolute path.  The returned path is absolute
    and guaranteed to exist inside *directory*.
    """
    if "\x00" in path:
        raise SecurityError("NUL byte in path.")
    if "\\" in path:
        raise SecurityError("Backslashes are not allowed in static paths.")

    decoded = unquote(path)
    if "\x00" in decoded:
        raise SecurityError("NUL byte in path.")

    root = os.path.realpath(directory)
    # Strip a leading slash so "/style.css" is treated as relative.
    relative = decoded.lstrip("/")
    if not relative.strip("/"):
        raise NotFound("Directory listing is disabled.")
    # Duplicate separators collapse, but "." / ".." are rejected outright.
    segments = [segment for segment in relative.split("/") if segment]
    for segment in segments:
        if segment in (".", ".."):
            raise SecurityError(f"Unsafe path segment {segment!r} in {path!r}.")

    candidate = os.path.realpath(os.path.join(root, *segments))
    if candidate != root and not candidate.startswith(root + os.sep):
        raise SecurityError(f"Path {path!r} escapes the static directory.")
    return candidate


def send_file(
    filepath: str,
    environ: Mapping[str, Any] | None = None,
    max_age: int | None = None,
    mimetype: str | None = None,
    conditional: bool = True,
    download_name: str | None = None,
) -> Response:
    """Return a streaming response for the file at *filepath*.

    ``filepath`` must already be a trusted, resolved path (use
    :func:`safe_join` first).  The file handle is opened lazily and closed by
    the WSGI server via the response's ``close()``.
    """
    try:
        file_stat = os.stat(filepath)
    except OSError:
        raise NotFound("The requested file does not exist.") from None
    if not stat.S_ISREG(file_stat.st_mode):
        raise NotFound("The requested path is not a regular file.")

    content_type = mimetype or guess_mimetype(filepath)
    extension = os.path.splitext(filepath)[1].lower()
    if extension in _FORCE_DOWNLOAD_EXTENSIONS:
        content_type = "application/octet-stream"

    etag = f'"{file_stat.st_mtime_ns:x}-{file_stat.st_size:x}"'
    last_modified = int(file_stat.st_mtime)

    if conditional and environ is not None and _is_not_modified(environ, etag, last_modified):
        response = Response(b"", status=304, mimetype=content_type)
        response.headers["ETag"] = etag
        response.headers["Last-Modified"] = http_date(last_modified)
        return response

    length = file_stat.st_size

    def _iter_file(path: str = filepath, chunk_size: int = 64 * 1024) -> Iterable[bytes]:
        handle = open(path, "rb")  # noqa: SIM115 - intentionally streamed
        try:
            while True:
                chunk = handle.read(chunk_size)
                if not chunk:
                    break
                yield chunk
        finally:
            handle.close()

    response = Response(_iter_file(), mimetype=content_type, direct_passthrough=True)
    response.headers["Content-Length"] = str(length)
    response.headers["Accept-Ranges"] = "none"
    response.headers["ETag"] = etag
    response.headers["Last-Modified"] = http_date(last_modified)
    if max_age is not None and max_age > 0:
        response.cache_control(max_age=max_age, public=True)
    else:
        response.headers["Cache-Control"] = "no-cache"
    if download_name:
        safe_name = download_name.replace('"', "").replace("\\", "").replace("\n", "")
        response.headers["Content-Disposition"] = f'attachment; filename="{safe_name}"'
    return response


def _is_not_modified(environ: Mapping[str, Any], etag: str, last_modified: int) -> bool:
    if_none_match = environ.get("HTTP_IF_NONE_MATCH")
    if if_none_match:
        candidates = [value.strip() for value in str(if_none_match).split(",")]
        if "*" in candidates or etag in candidates:
            return True
        return any(value.removeprefix("W/") == etag for value in candidates)
    if_modified_since = parse_http_date(
        str(environ.get("HTTP_IF_MODIFIED_SINCE"))
        if environ.get("HTTP_IF_MODIFIED_SINCE")
        else None
    )
    return if_modified_since is not None and last_modified <= if_modified_since


def send_from_directory(
    directory: str,
    path: str,
    environ: Mapping[str, Any] | None = None,
    max_age: int | None = None,
    mimetype: str | None = None,
) -> Response:
    """Safely serve *path* from *directory*."""
    return send_file(
        safe_join(directory, path), environ=environ, max_age=max_age, mimetype=mimetype
    )


class StaticFiles:
    """Serve a directory of static assets from a URL prefix.

    Used by :class:`myframework.App` for its ``/static`` route; can also be
    mounted on its own because instances are WSGI applications.

    >>> static = StaticFiles("public", url_path="/assets")  # doctest: +SKIP
    """

    def __init__(
        self,
        directory: str | os.PathLike[str] | None,
        url_path: str = "/static",
        max_age: int = 3600,
        use_etag: bool = True,
    ) -> None:
        self.directory = os.path.realpath(os.fspath(directory)) if directory else None
        self.url_path = "/" + url_path.strip("/")
        self.max_age = max_age
        self.use_etag = use_etag

    def __repr__(self) -> str:
        return f"<StaticFiles {self.url_path} -> {self.directory}>"

    @property
    def exists(self) -> bool:
        """``True`` when the directory was configured and exists."""
        return bool(self.directory and os.path.isdir(self.directory))

    def handle(self, filename: str, environ: Mapping[str, Any]) -> Response:
        """Serve *filename* (a URL-relative path) or raise ``404``/``SecurityError``."""
        if not self.exists or self.directory is None:
            raise NotFound("No static directory is configured.")
        path = safe_join(self.directory, filename)
        return send_file(
            path,
            environ=environ,
            max_age=self.max_age if self.max_age >= 0 else None,
            conditional=self.use_etag,
        )

    def __call__(self, environ: dict[str, Any], start_response: Any) -> Iterable[bytes]:
        """Minimal standalone WSGI app for the static directory."""
        path_info = str(environ.get("PATH_INFO") or "/")
        prefix = self.url_path
        if path_info.startswith(prefix):
            path_info = path_info[len(prefix) :]
        try:
            response = self.handle(path_info, environ)
        except SecurityError:
            body = b"<h1>403 Forbidden</h1>"
            start_response(
                "403 Forbidden",
                [("Content-Type", "text/html; charset=utf-8"), ("Content-Length", str(len(body)))],
            )
            return [body]
        except NotFound:
            body = b"<h1>404 Not Found</h1>"
            start_response(
                "404 Not Found",
                [("Content-Type", "text/html; charset=utf-8"), ("Content-Length", str(len(body)))],
            )
            return [body]
        return response.wsgi(environ, start_response)


def file_digest(path: str) -> str:
    """Return the SHA-1 digest of a file (used for cache-busting URLs)."""
    digest = hashlib.sha1(usedforsecurity=False)
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(64 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()
