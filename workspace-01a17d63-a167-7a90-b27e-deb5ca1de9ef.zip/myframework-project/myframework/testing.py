"""A test client that drives the application through its WSGI interface.

The client never special-cases the internals: it builds a real WSGI environ,
calls the application, and reads the real response.  That means the tests
exercise the same code path as production traffic, including middleware.

>>> from myframework import App
>>> app = App(__name__)
>>> @app.route("/ping")
... def ping():
...     return {"pong": True}
>>> client = app.test_client()
>>> response = client.get("/ping")
>>> response.status_code, response.json
(200, {'pong': True})
"""

from __future__ import annotations

import json as _json
from collections.abc import Iterable, Mapping, Sequence
from http.cookies import SimpleCookie
from typing import TYPE_CHECKING, Any
from urllib.parse import unquote, urlencode, urlsplit

from .datastructures import Headers
from .request import Request
from .response import Response
from .wsgi import make_environ

if TYPE_CHECKING:  # pragma: no cover - typing only
    from .app import App

__all__ = ["Client", "TestResponse", "make_request"]


def make_request(
    app: App,
    path: str = "/",
    method: str = "GET",
    query_string: str = "",
    headers: Sequence[tuple[str, str]] | Mapping[str, str] | None = None,
    data: bytes | str = b"",
    **environ_options: Any,
) -> Request:
    """Build a :class:`~myframework.request.Request` without running a request."""
    if isinstance(data, str):
        data = data.encode("utf-8")
    split = urlsplit(path)
    if split.query and not query_string:
        query_string = split.query
    path = split.path or "/"
    environ = make_environ(
        path=path,
        method=method,
        query_string=query_string,
        headers=headers,
        body=data,
        **environ_options,
    )
    return app.request_class(environ, max_content_length=app.config.get("MAX_CONTENT_LENGTH"))


class TestResponse(Response):
    """A :class:`Response` with a few assertion helpers for tests."""

    #: The :class:`Request` that produced this response.
    request: Request | None = None
    #: Responses that were followed before this one (with ``follow_redirects``).
    history: list[TestResponse]

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.history = []

    @classmethod
    def from_wsgi(cls, body: bytes, status: str, headers: list[tuple[str, str]]) -> TestResponse:
        """Build a response from what the WSGI app actually sent.

        The headers recorded by ``start_response`` are authoritative, so they
        replace anything :class:`~myframework.response.Response` inferred: a
        ``HEAD`` response, for example, has a ``Content-Length`` but no body.
        """
        response = cls(body, status=status)
        response.headers = Headers(list(headers))
        response._body = body
        response._iterable = None
        return response

    # -- convenience ------------------------------------------------------
    @property
    def location(self) -> str | None:
        """The ``Location`` header, if any."""
        return self.headers.get("Location")

    def assert_status(self, *expected: int) -> TestResponse:
        """Assert the status code is one of *expected*."""
        assert self.status_code in expected, (
            f"Expected status in {expected}, got {self.status_code} "
            f"({self.status}). Body: {self.text[:400]!r}"
        )
        return self

    def assert_ok(self) -> TestResponse:
        """Assert a 2xx status."""
        assert 200 <= self.status_code < 300, (
            f"Expected 2xx, got {self.status_code}: {self.text[:200]!r}"
        )
        return self

    def assert_redirects(self, to: str | None = None, status: int | None = 302) -> TestResponse:
        """Assert this response is a redirect (optionally to *to*)."""
        assert 300 <= self.status_code < 400, f"Expected a redirect, got {self.status_code}"
        if status is not None:
            assert self.status_code == status, f"Expected {status}, got {self.status_code}"
        if to is not None:
            assert self.location == to, f"Expected redirect to {to!r}, got {self.location!r}"
        return self

    def assert_contains(self, needle: str) -> TestResponse:
        """Assert the body contains *needle*."""
        assert needle in self.text, f"{needle!r} not found in body: {self.text[:400]!r}"
        return self

    def assert_content_type(self, mimetype: str) -> TestResponse:
        """Assert the response media type."""
        assert self.mimetype == mimetype, f"Expected {mimetype!r}, got {self.mimetype!r}"
        return self

    def __repr__(self) -> str:
        return f"<TestResponse {self.status} {self.mimetype}>"


class _CookieJar:
    """A tiny cookie jar: enough for ``Set-Cookie`` round-tripping in tests."""

    def __init__(self) -> None:
        self._cookies: dict[str, str] = {}

    def update_from_headers(self, headers: Iterable[tuple[str, str]]) -> None:
        for name, value in headers:
            if name.lower() != "set-cookie":
                continue
            jar: SimpleCookie = SimpleCookie()
            try:
                jar.load(value)
            except Exception:
                continue
            for key, morsel in jar.items():
                if morsel["max-age"] == "0":
                    self._cookies.pop(key, None)
                    continue
                self._cookies[key] = morsel.value

    def header_value(self) -> str:
        return "; ".join(f"{key}={value}" for key, value in self._cookies.items())

    def clear(self) -> None:
        self._cookies.clear()

    def __len__(self) -> int:
        return len(self._cookies)


class Client:
    """A test client for a :class:`~myframework.App`.

    Parameters
    ----------
    app:
        The application under test.
    base_url:
        Scheme/host/port used in generated URLs.
    use_cookies:
        Keep cookies returned by the app and send them back on later requests.
    follow_redirects:
        Default for :meth:`open`'s ``follow_redirects`` argument.
    """

    def __init__(
        self,
        app: App,
        base_url: str = "http://localhost",
        use_cookies: bool = True,
        follow_redirects: bool = False,
    ) -> None:
        self.app = app
        self.base_url = base_url.rstrip("/")
        self.use_cookies = use_cookies
        self.follow_redirects = follow_redirects
        self.cookies = _CookieJar()
        self.default_environ_overrides: dict[str, Any] = {}

    def __enter__(self) -> Client:
        return self

    def __exit__(self, *exc_info: Any) -> None:
        self.cookies.clear()

    # -- verbs ------------------------------------------------------------
    def get(self, path: str, **kwargs: Any) -> TestResponse:
        """Send a ``GET`` request."""
        return self.open(path, method="GET", **kwargs)

    def post(self, path: str, **kwargs: Any) -> TestResponse:
        """Send a ``POST`` request (``data``/``json``/``form`` are supported)."""
        return self.open(path, method="POST", **kwargs)

    def put(self, path: str, **kwargs: Any) -> TestResponse:
        """Send a ``PUT`` request."""
        return self.open(path, method="PUT", **kwargs)

    def patch(self, path: str, **kwargs: Any) -> TestResponse:
        """Send a ``PATCH`` request."""
        return self.open(path, method="PATCH", **kwargs)

    def delete(self, path: str, **kwargs: Any) -> TestResponse:
        """Send a ``DELETE`` request."""
        return self.open(path, method="DELETE", **kwargs)

    def options(self, path: str, **kwargs: Any) -> TestResponse:
        """Send an ``OPTIONS`` request."""
        return self.open(path, method="OPTIONS", **kwargs)

    def head(self, path: str, **kwargs: Any) -> TestResponse:
        """Send a ``HEAD`` request."""
        return self.open(path, method="HEAD", **kwargs)

    # -- core -------------------------------------------------------------
    def open(
        self,
        path: str = "/",
        method: str = "GET",
        data: bytes | str | Mapping[str, Any] | None = None,
        json: Any = None,
        form: Mapping[str, Any] | None = None,
        query_string: str | Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | Sequence[tuple[str, str]] | None = None,
        content_type: str | None = None,
        follow_redirects: bool | None = None,
        files: Mapping[str, Any] | None = None,
    ) -> TestResponse:
        """Send a request to the application and return a :class:`TestResponse`.

        ``json=`` sets ``Content-Type: application/json``, ``form=`` encodes a
        urlencoded body, ``files=`` builds a multipart body (values may be
        ``(filename, bytes)`` tuples).
        """
        method = method.upper()
        body, content_type = self._prepare_body(data, json, form, files, content_type)
        header_items = self._prepare_headers(headers, content_type)

        split = urlsplit(path)
        if split.scheme and split.netloc:
            environ_base = {
                "wsgi.url_scheme": split.scheme,
                "HTTP_HOST": split.netloc,
                "SERVER_NAME": split.netloc.split(":")[0],
                "SERVER_PORT": split.port or (443 if split.scheme == "https" else 80),
            }
        else:
            base = urlsplit(self.base_url)
            environ_base = {
                "wsgi.url_scheme": base.scheme or "http",
                "HTTP_HOST": base.netloc,
                "SERVER_NAME": base.hostname or "localhost",
                "SERVER_PORT": base.port or 80,
            }
        # Real WSGI servers percent-decode PATH_INFO before handing it over, so
        # the test client does the same.
        request_path = unquote(split.path) or "/"
        query = split.query
        if query_string:
            extra = (
                query_string
                if isinstance(query_string, str)
                else urlencode(query_string, doseq=True)
            )
            query = f"{query}&{extra}" if query else extra

        environ = make_environ(
            path=request_path,
            method=method,
            query_string=query,
            headers=header_items,
            body=body,
            scheme=str(environ_base["wsgi.url_scheme"]),
            server_name=str(environ_base["SERVER_NAME"]),
            server_port=str(environ_base["SERVER_PORT"]),
        )
        has_explicit_host = any(name.lower() == "host" for name, _ in header_items)
        if not has_explicit_host:
            environ["HTTP_HOST"] = environ_base["HTTP_HOST"]
        environ.update(self.default_environ_overrides)

        response = self._run(environ)
        should_follow = self.follow_redirects if follow_redirects is None else follow_redirects
        if should_follow and response.status_code in (301, 302, 303, 307, 308):
            history = [response]
            budget = 8
            while response.status_code in (301, 302, 303, 307, 308) and budget > 0:
                location = response.location
                if not location:
                    break
                budget -= 1
                if response.status_code == 303 or (
                    response.status_code in (301, 302) and method not in ("GET", "HEAD")
                ):
                    next_method = "GET"
                    next_body: Any = None
                else:
                    next_method = method
                    next_body = data if isinstance(data, (bytes, str)) else None
                response = self.open(
                    location,
                    method=next_method,
                    data=next_body,
                    headers=headers,
                    follow_redirects=False,
                )
                history.append(response)
            response.history = history[:-1]
        return response

    def _run(self, environ: dict[str, Any]) -> TestResponse:
        captured: dict[str, Any] = {}

        def start_response(
            status: str, headers: Sequence[tuple[str, str]], exc_info: Any = None
        ) -> Any:
            captured["status"] = status
            captured["headers"] = list(headers)
            if exc_info and "headers" in captured:
                pass
            return lambda data: None

        result = self.app(environ, start_response)
        chunks: list[bytes] = []
        try:
            for chunk in result:
                if not isinstance(chunk, bytes):  # pragma: no cover - contract guard
                    raise AssertionError(
                        f"WSGI app yielded {type(chunk).__name__}; bodies must be bytes."
                    )
                chunks.append(chunk)
        finally:
            close = getattr(result, "close", None)
            if callable(close):
                close()

        status = captured["status"]
        headers = captured["headers"]
        code = int(status.split(" ", 1)[0])
        response = TestResponse.from_wsgi(b"".join(chunks), status, headers)
        response.status_code = code
        if self.use_cookies:
            self.cookies.update_from_headers(headers)
        response.request = Request(
            environ, max_content_length=self.app.config.get("MAX_CONTENT_LENGTH")
        )
        return response

    # -- body / header preparation ----------------------------------------
    def _prepare_headers(
        self,
        headers: Mapping[str, str] | Sequence[tuple[str, str]] | None,
        content_type: str | None,
    ) -> list[tuple[str, str]]:
        items: list[tuple[str, str]] = []
        if headers:
            items = list(headers.items()) if hasattr(headers, "items") else list(headers)
        lowered = {name.lower() for name, _ in items}
        if content_type and "content-type" not in lowered:
            items.append(("Content-Type", content_type))
        if self.use_cookies and len(self.cookies) and "cookie" not in lowered:
            items.append(("Cookie", self.cookies.header_value()))
        return items

    def _prepare_body(
        self,
        data: bytes | str | Mapping[str, Any] | None,
        json: Any,
        form: Mapping[str, Any] | None,
        files: Mapping[str, Any] | None,
        content_type: str | None,
    ) -> tuple[bytes, str | None]:
        if json is not None:
            return _json.dumps(json).encode("utf-8"), content_type or "application/json"
        if files is not None:
            boundary = "----myframeworkboundary"
            body = _encode_multipart({**(form or {}), **files}, boundary)
            return body, content_type or f"multipart/form-data; boundary={boundary}"
        if form is not None:
            return urlencode(form, doseq=True).encode("utf-8"), (
                content_type or "application/x-www-form-urlencoded"
            )
        if data is None:
            return b"", content_type
        if isinstance(data, Mapping):
            return urlencode(data, doseq=True).encode("utf-8"), (
                content_type or "application/x-www-form-urlencoded"
            )
        if isinstance(data, str):
            return data.encode("utf-8"), content_type or "text/plain; charset=utf-8"
        return data, content_type

    def __repr__(self) -> str:  # pragma: no cover - debugging convenience
        return f"<Client {self.app!r}>"


def _encode_multipart(
    fields: Mapping[str, Any], boundary: str = "----myframeworkboundary"
) -> bytes:
    """Build a minimal ``multipart/form-data`` body for upload tests."""
    lines: list[bytes] = []
    for name, value in fields.items():
        lines.append(f"--{boundary}".encode())
        if isinstance(value, tuple) and len(value) == 2:
            filename, payload = value
            if isinstance(payload, str):
                payload = payload.encode("utf-8")
            lines.append(
                f'Content-Disposition: form-data; name="{name}"; filename="{filename}"'.encode()
            )
            lines.append(b"Content-Type: application/octet-stream")
            lines.append(b"")
            lines.append(payload)
        else:
            lines.append(f'Content-Disposition: form-data; name="{name}"'.encode())
            lines.append(b"")
            lines.append(str(value).encode("utf-8"))
    lines.append(f"--{boundary}--".encode())
    lines.append(b"")
    return b"\r\n".join(lines)
