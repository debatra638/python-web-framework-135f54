"""WSGI middleware.

Every middleware in this module is WSGI-to-WSGI: it wraps an application and
returns a new callable with the signature ``app(environ, start_response)``.
That means they work with MyFramework, with any other WSGI framework, and can
be mounted in front of the application with ``app.use(...)`` or by hand.

Because WSGI middleware runs *outside* the application, the :data:`request`
proxy is **not** available inside them (the request context is pushed by the
app when the view is dispatched).  Use ``environ`` directly, or the
``before_request`` / ``after_request`` hooks if you need request-aware logic.

Ordering note: middleware added with ``app.use(mw)`` is applied so that the
first registered middleware is the outermost one, i.e. it sees the request
first and the response last.
"""

from __future__ import annotations

import contextlib
import logging
import re
import time
import uuid
from collections.abc import Callable, Iterable, Mapping, Sequence
from typing import Any

__all__ = [
    "AccessLogMiddleware",
    "CORSMiddleware",
    "HTTPSRedirectMiddleware",
    "HeaderMiddleware",
    "Middleware",
    "MiddlewareStack",
    "ProxyFix",
    "RequestIDMiddleware",
    "SecurityHeadersMiddleware",
    "TrustedHostMiddleware",
    "WSGIMiddleware",
]

Environ = Mapping[str, Any]
StartResponse = Callable[..., Any]
WSGIApp = Callable[[Environ, StartResponse], Iterable[bytes]]

_DEFAULT_LOG = logging.getLogger("myframework.access")


class WSGIMiddleware:
    """Base class for WSGI middleware.

    Subclasses either override :meth:`__call__` entirely or implement
    :meth:`process_environ` and/or :meth:`process_response` for the common
    "mutate the environment, then mutate the response" pattern.

    >>> class Hello(WSGIMiddleware):       # doctest: +SKIP
    ...     def process_response(self, status, headers):
    ...         return status, headers + [("X-Hello", "1")]
    """

    def __init__(self, app: WSGIApp | None = None) -> None:
        self.app = app

    # -- hooks ------------------------------------------------------------
    def process_environ(self, environ: dict[str, Any]) -> dict[str, Any]:
        """Return a (possibly new) environ.  Default: unchanged."""
        return environ

    def process_response(
        self, status: str, headers: list[tuple[str, str]]
    ) -> tuple[str, list[tuple[str, str]]]:
        """Return updated ``(status, headers)``.  Default: unchanged."""
        return status, headers

    # -- WSGI -------------------------------------------------------------
    def __call__(
        self, environ: Mapping[str, Any], start_response: StartResponse
    ) -> Iterable[bytes]:
        if self.app is None:
            raise RuntimeError(
                f"{type(self).__name__} has no wrapped application. "
                "Pass one to the constructor or use app.use(middleware_class())."
            )
        environ = self.process_environ(dict(environ))

        def _start_response(
            status: str, headers: list[tuple[str, str]], exc_info: Any = None
        ) -> Any:
            status, headers = self.process_response(status, list(headers))
            return (
                start_response(status, headers, exc_info)
                if exc_info
                else start_response(status, headers)
            )

        return self.app(environ, _start_response)


#: Friendly alias: ``Middleware`` reads better in application code.
Middleware = WSGIMiddleware


class MiddlewareStack:
    """Compose an application with several middleware layers.

    >>> stack = MiddlewareStack(app)        # doctest: +SKIP
    >>> stack.add(SecurityHeadersMiddleware())
    >>> wsgi_app = stack.build()
    """

    def __init__(self, app: WSGIApp | None = None) -> None:
        self.app = app
        self._layers: list[tuple[WSGIMiddleware, dict[str, Any]]] = []

    def add(self, middleware: WSGIMiddleware, **options: Any) -> MiddlewareStack:
        """Add a middleware instance (or unbounded subclass instance)."""
        self._layers.append((middleware, options))
        return self

    def __len__(self) -> int:
        return len(self._layers)

    def build(self) -> WSGIApp:
        """Return the fully wrapped application (first added = outermost)."""
        if self.app is None:
            raise RuntimeError("MiddlewareStack needs an application before build().")
        app: WSGIApp = self.app
        for middleware, options in reversed(self._layers):
            if options:
                middleware.app = app
                for key, value in options.items():
                    setattr(middleware, key, value)
            else:
                middleware.app = app
            app = middleware
        return app

    def __call__(
        self, environ: Mapping[str, Any], start_response: StartResponse
    ) -> Iterable[bytes]:
        return self.build()(environ, start_response)


class RequestIDMiddleware(WSGIMiddleware):
    """Ensure every request carries an id, exposed as ``X-Request-ID``.

    The id is also stored in the WSGI environ under
    ``myframework.request_id`` so the application can include it in logs or
    error pages.  An inbound ``X-Request-ID`` is reused (truncated to 200
    characters) which makes tracing across services work.
    """

    def __init__(
        self,
        app: WSGIApp | None = None,
        header: str = "X-Request-ID",
        generator: Callable[[], str] | None = None,
    ) -> None:
        super().__init__(app)
        self.header = header
        self.generator = generator or (lambda: uuid.uuid4().hex)

    def __call__(
        self, environ: Mapping[str, Any], start_response: StartResponse
    ) -> Iterable[bytes]:
        if self.app is None:  # pragma: no cover - defensive
            raise RuntimeError("RequestIDMiddleware is not bound to an application.")
        environ = dict(environ)
        incoming = environ.get("HTTP_X_REQUEST_ID")
        request_id = (
            incoming if isinstance(incoming, str) and incoming.strip() else self.generator()
        )
        request_id = request_id.strip()[:200]
        environ["myframework.request_id"] = request_id

        def _start_response(
            status: str, headers: list[tuple[str, str]], exc_info: Any = None
        ) -> Any:
            headers = [(k, v) for k, v in headers if k.lower() != self.header.lower()]
            headers.append((self.header, request_id))
            return (
                start_response(status, headers, exc_info)
                if exc_info
                else start_response(status, headers)
            )

        return self.app(environ, _start_response)


class AccessLogMiddleware(WSGIMiddleware):
    """Write one log line per request with status, duration and size."""

    def __init__(
        self,
        app: WSGIApp | None = None,
        logger: logging.Logger | None = None,
        level: int = logging.INFO,
    ) -> None:
        super().__init__(app)
        self.logger = logger or _DEFAULT_LOG
        self.level = level

    def __call__(
        self, environ: Mapping[str, Any], start_response: StartResponse
    ) -> Iterable[bytes]:
        if self.app is None:  # pragma: no cover - defensive
            raise RuntimeError("AccessLogMiddleware is not bound to an application.")
        started = time.perf_counter()
        status_holder: dict[str, str] = {}
        size_holder: dict[str, int] = {}

        def _start_response(
            status: str, headers: list[tuple[str, str]], exc_info: Any = None
        ) -> Any:
            status_holder["status"] = status
            for name, value in headers:
                if name.lower() == "content-length":
                    with contextlib.suppress(ValueError):
                        size_holder["size"] = int(value)
            return (
                start_response(status, headers, exc_info)
                if exc_info
                else start_response(status, headers)
            )

        chunks = self.app(environ, _start_response)
        try:
            for chunk in chunks:
                if "size" not in size_holder:
                    size_holder["size"] = size_holder.get("size", 0) + len(chunk)
                yield chunk
        finally:
            close = getattr(chunks, "close", None)
            if callable(close):
                close()
            elapsed_ms = (time.perf_counter() - started) * 1000
            remote = environ.get("REMOTE_ADDR", "-")
            method = environ.get("REQUEST_METHOD", "-")
            path = environ.get("PATH_INFO", "/")
            query = environ.get("QUERY_STRING") or ""
            target = f"{path}?{query}" if query else path
            self.logger.log(
                self.level,
                "%s - %s %s %s %d bytes %.1fms",
                remote,
                method,
                target,
                status_holder.get("status", "-"),
                size_holder.get("size", 0),
                elapsed_ms,
                extra={"request_id": environ.get("myframework.request_id", "-")},
            )


class HeaderMiddleware(WSGIMiddleware):
    """Add a static header to every response (unless already present)."""

    def __init__(
        self, app: WSGIApp | None = None, headers: Mapping[str, str] | None = None
    ) -> None:
        super().__init__(app)
        self.headers = dict(headers or {})

    def process_response(
        self, status: str, headers: list[tuple[str, str]]
    ) -> tuple[str, list[tuple[str, str]]]:
        existing = {name.lower() for name, _ in headers}
        for name, value in self.headers.items():
            if name.lower() not in existing:
                headers.append((name, value))
        return status, headers


class SecurityHeadersMiddleware(HeaderMiddleware):
    """Add conservative security headers to responses.

    Defaults: ``X-Content-Type-Options: nosniff``,
    ``X-Frame-Options: DENY``, ``Referrer-Policy: strict-origin-when-cross-origin``
    and a restrictive ``Content-Security-Policy`` that allows only same-origin
    resources plus inline styles.  Tune or disable individual headers for your
    application — these are starting points, not a security guarantee.
    """

    DEFAULT_CSP = (
        "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; "
        "base-uri 'self'; frame-ancestors 'none'"
    )

    def __init__(
        self,
        app: WSGIMiddleware | None = None,
        content_security_policy: str | None = DEFAULT_CSP,
        x_frame_options: str | None = "DENY",
        referrer_policy: str | None = "strict-origin-when-cross-origin",
        hsts_max_age: int | None = None,
        permissions_policy: str | None = None,
    ) -> None:
        headers: dict[str, str] = {"X-Content-Type-Options": "nosniff"}
        if x_frame_options:
            headers["X-Frame-Options"] = x_frame_options
        if referrer_policy:
            headers["Referrer-Policy"] = referrer_policy
        if content_security_policy:
            headers["Content-Security-Policy"] = content_security_policy
        if hsts_max_age:
            # Only send HSTS when the app is actually served over HTTPS;
            # this is opt-in because http-only deployments would be bricked.
            headers["Strict-Transport-Security"] = f"max-age={int(hsts_max_age)}"
        if permissions_policy:
            headers["Permissions-Policy"] = permissions_policy
        super().__init__(app, headers)


class CORSMiddleware(WSGIMiddleware):
    """Add CORS headers and answer pre-flight requests.

    ``allow_origins`` accepts exact origins, ``"*"`` or a callable receiving the
    ``Origin`` header.  ``allow_credentials=True`` combined with ``"*"`` is
    rejected by browsers, so the middleware echoes the request origin instead.
    """

    def __init__(
        self,
        app: WSGIApp | None = None,
        allow_origins: Sequence[str] | str | Callable[[str | None], str | None] = (),
        allow_methods: Sequence[str] = ("GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"),
        allow_headers: Sequence[str] = ("Content-Type", "Authorization", "Accept"),
        expose_headers: Sequence[str] = (),
        allow_credentials: bool = False,
        max_age: int = 600,
        intercept_preflight: bool = True,
    ) -> None:
        super().__init__(app)
        if isinstance(allow_origins, str):
            allow_origins = [allow_origins]
        self._origins = allow_origins
        self.allow_methods = list(allow_methods)
        self.allow_headers = list(allow_headers)
        self.expose_headers = list(expose_headers)
        self.allow_credentials = allow_credentials
        self.max_age = max_age
        self.intercept_preflight = intercept_preflight

    def _resolve_origin(self, origin: str | None) -> str | None:
        if origin is None:
            return None
        if callable(self._origins):
            return self._origins(origin)
        origins = list(self._origins)
        if "*" in origins:
            return origin if self.allow_credentials else "*"
        return origin if origin in origins else None

    def __call__(
        self, environ: Mapping[str, Any], start_response: StartResponse
    ) -> Iterable[bytes]:
        if self.app is None:  # pragma: no cover - defensive
            raise RuntimeError("CORSMiddleware is not bound to an application.")
        origin_header = environ.get("HTTP_ORIGIN")
        origin = origin_header if isinstance(origin_header, str) else None
        resolved = self._resolve_origin(origin)

        method = str(environ.get("REQUEST_METHOD", "GET")).upper()
        is_preflight = (
            self.intercept_preflight
            and method == "OPTIONS"
            and "HTTP_ACCESS_CONTROL_REQUEST_METHOD" in environ
        )
        if is_preflight:
            headers: list[tuple[str, str]] = [
                ("Access-Control-Allow-Methods", ", ".join(self.allow_methods)),
                ("Access-Control-Allow-Headers", ", ".join(self.allow_headers)),
                ("Access-Control-Max-Age", str(int(self.max_age))),
                ("Content-Length", "0"),
            ]
            if resolved:
                headers.append(("Access-Control-Allow-Origin", resolved))
                if resolved != "*":
                    headers.append(("Vary", "Origin"))
                if self.allow_credentials:
                    headers.append(("Access-Control-Allow-Credentials", "true"))
            elif origin:
                # Origin present but not allowed: answer without CORS headers.
                start_response("403 Forbidden", [("Content-Length", "0")])
                return [b""]
            start_response("204 No Content", headers)
            return [b""]

        def _start_response(
            status: str, headers: list[tuple[str, str]], exc_info: Any = None
        ) -> Any:
            headers = list(headers)
            if resolved is None:
                return (
                    start_response(status, headers, exc_info)
                    if exc_info
                    else start_response(status, headers)
                )
            existing = {name.lower() for name, _ in headers}
            if "access-control-allow-origin" not in existing:
                headers.append(("Access-Control-Allow-Origin", resolved))
            if resolved != "*" and "vary" not in existing:
                headers.append(("Vary", "Origin"))
            if self.allow_credentials and "access-control-allow-credentials" not in existing:
                headers.append(("Access-Control-Allow-Credentials", "true"))
            if self.expose_headers and "access-control-expose-headers" not in existing:
                headers.append(("Access-Control-Expose-Headers", ", ".join(self.expose_headers)))
            return (
                start_response(status, headers, exc_info)
                if exc_info
                else start_response(status, headers)
            )

        return self.app(environ, _start_response)


class TrustedHostMiddleware(WSGIMiddleware):
    """Reject requests whose ``Host`` header is not in an allowlist.

    Protects against Host-header poisoning (password reset links, cache
    poisoning, virtual-host confusion).  Supports ``*.example.com`` wildcards.
    """

    def __init__(
        self,
        app: WSGIApp | None = None,
        allowed_hosts: Sequence[str] = ("*",),
    ) -> None:
        super().__init__(app)
        self.allowed_hosts = [host.lower() for host in allowed_hosts]
        self._patterns = [
            re.compile(r"^" + re.escape(host).replace(r"\*", "[^.]+") + "$")
            for host in self.allowed_hosts
            if host != "*"
        ]

    def _host_allowed(self, host: str) -> bool:
        if "*" in self.allowed_hosts:
            return True
        host = host.lower()
        bare = host.rsplit(":", 1)[0] if ":" in host and not host.endswith("]") else host
        for candidate in (host, bare):
            if any(pattern.match(candidate) for pattern in self._patterns):
                return True
        return False

    def __call__(
        self, environ: Mapping[str, Any], start_response: StartResponse
    ) -> Iterable[bytes]:
        if self.app is None:  # pragma: no cover - defensive
            raise RuntimeError("TrustedHostMiddleware is not bound to an application.")
        host = environ.get("HTTP_HOST") or environ.get("SERVER_NAME") or ""
        if not self._host_allowed(str(host)):
            body = b"<h1>400 Bad Request</h1><p>Host header is not trusted.</p>"
            start_response(
                "400 Bad Request",
                [("Content-Type", "text/html; charset=utf-8"), ("Content-Length", str(len(body)))],
            )
            return [body]
        return self.app(environ, start_response)


class ProxyFix(WSGIMiddleware):
    """Trust ``X-Forwarded-*`` headers from a reverse proxy.

    Only enable this when the application is *only* reachable through a proxy
    you control; otherwise clients can spoof their address and scheme.
    ``x_for`` / ``x_proto`` / ``x_host`` / ``x_port`` / ``x_prefix`` set how
    many proxy hops to trust (0 disables that header).
    """

    def __init__(
        self,
        app: WSGIApp | None = None,
        x_for: int = 1,
        x_proto: int = 1,
        x_host: int = 1,
        x_port: int = 0,
        x_prefix: int = 0,
    ) -> None:
        super().__init__(app)
        self.x_for = x_for
        self.x_proto = x_proto
        self.x_host = x_host
        self.x_port = x_port
        self.x_prefix = x_prefix

    @staticmethod
    def _trusted_value(raw: str, hops: int) -> str | None:
        parts = [part.strip() for part in raw.split(",") if part.strip()]
        if not parts:
            return None
        return parts[-hops] if hops <= len(parts) else parts[0]

    def process_environ(self, environ: dict[str, Any]) -> dict[str, Any]:
        if self.x_for and "HTTP_X_FORWARDED_FOR" in environ:
            value = self._trusted_value(str(environ["HTTP_X_FORWARDED_FOR"]), self.x_for)
            if value:
                environ["REMOTE_ADDR"] = value
        if self.x_proto and "HTTP_X_FORWARDED_PROTO" in environ:
            value = self._trusted_value(str(environ["HTTP_X_FORWARDED_PROTO"]), self.x_proto)
            if value:
                environ["wsgi.url_scheme"] = value.lower()
        if self.x_host and "HTTP_X_FORWARDED_HOST" in environ:
            value = self._trusted_value(str(environ["HTTP_X_FORWARDED_HOST"]), self.x_host)
            if value:
                environ["HTTP_HOST"] = value
        if self.x_port and "HTTP_X_FORWARDED_PORT" in environ:
            value = self._trusted_value(str(environ["HTTP_X_FORWARDED_PORT"]), self.x_port)
            if value:
                environ["SERVER_PORT"] = value
        if self.x_prefix and "HTTP_X_FORWARDED_PREFIX" in environ:
            value = self._trusted_value(str(environ["HTTP_X_FORWARDED_PREFIX"]), self.x_prefix)
            if value:
                environ["SCRIPT_NAME"] = value
        return environ


class HTTPSRedirectMiddleware(WSGIMiddleware):
    """Redirect ``http`` requests to ``https`` (combine with :class:`ProxyFix`)."""

    def __init__(
        self, app: WSGIApp | None = None, code: int = 308, exclude: Sequence[str] = ()
    ) -> None:
        super().__init__(app)
        self.code = code
        self.exclude = list(exclude)

    def __call__(
        self, environ: Mapping[str, Any], start_response: StartResponse
    ) -> Iterable[bytes]:
        if self.app is None:  # pragma: no cover - defensive
            raise RuntimeError("HTTPSRedirectMiddleware is not bound to an application.")
        if str(environ.get("wsgi.url_scheme", "http")) == "https":
            return self.app(environ, start_response)
        path = str(environ.get("PATH_INFO") or "/")
        if any(path.startswith(prefix) for prefix in self.exclude):
            return self.app(environ, start_response)
        host = str(environ.get("HTTP_HOST") or environ.get("SERVER_NAME") or "localhost")
        query = environ.get("QUERY_STRING") or ""
        location = f"https://{host}{path}" + (f"?{query}" if query else "")
        start_response(
            f"{self.code} Permanent Redirect",
            [("Location", location), ("Content-Length", "0")],
        )
        return [b""]
