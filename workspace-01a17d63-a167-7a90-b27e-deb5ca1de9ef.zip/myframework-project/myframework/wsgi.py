"""WSGI interface (PEP 3333) helpers.

WSGI is *not* an HTTP server: it is the contract between a Python application
and a server such as Gunicorn, uWSGI, Waitress or ``wsgiref``.  This module
makes the contract easy to satisfy and easy to test:

* :func:`wsgi_application` returns the WSGI callable for an :class:`~myframework.App`.
* :func:`validate_status` / :func:`validate_headers` check the response halves
  of the contract (used by the test-suite and available to middleware authors).
* :func:`middleware_chain` applies WSGI middleware in a predictable order.
* :func:`serve_wsgiref` runs any WSGI app on the standard library's reference
  server — handy for verifying the interface, not for production.

The framework application object itself is a WSGI callable, so a production
server is configured with the dotted path of the module-level variable::

    gunicorn -w 4 "myapp:app"       # App instance -> WSGI callable
"""

from __future__ import annotations

import sys
from collections.abc import Callable, Iterable, Mapping, Sequence
from typing import Any, Protocol, runtime_checkable
from wsgiref.simple_server import WSGIRequestHandler, WSGIServer, make_server

__all__ = [
    "Environ",
    "StartResponse",
    "WSGIApp",
    "WSGIContractError",
    "middleware_chain",
    "serve_wsgiref",
    "validate_headers",
    "validate_response",
    "validate_status",
    "wsgi_application",
]

Environ = Mapping[str, Any]
StartResponse = Callable[..., Any]
WSGIApp = Callable[[Environ, StartResponse], Iterable[bytes]]


class WSGIContractError(AssertionError):
    """Raised when an object violates the WSGI specification."""


@runtime_checkable
class WSGIApplication(Protocol):
    """Static protocol for a PEP 3333 application callable."""

    def __call__(self, environ: Environ, start_response: StartResponse) -> Iterable[bytes]: ...


def wsgi_application(app: Any) -> WSGIApp:
    """Return the WSGI callable for *app*.

    Accepts a MyFramework :class:`~myframework.App` (which is already callable)
    or any object exposing a ``wsgi_app`` attribute.
    """
    candidate = getattr(app, "wsgi_app", app)
    if not callable(candidate):
        raise TypeError(f"{app!r} is not a WSGI application (not callable).")
    return candidate  # type: ignore[no-any-return]


def middleware_chain(app: WSGIApp, *middlewares: Any) -> WSGIApp:
    """Wrap *app* so that ``middlewares[0]`` is the outermost layer."""
    result = app
    for middleware in reversed(middlewares):
        if isinstance(middleware, type):
            middleware = middleware()
        if hasattr(middleware, "app") and middleware.app is None:
            middleware.app = result
            result = middleware
        else:
            result = middleware(result)
    return result


def validate_status(status: Any) -> None:
    """Check that *status* is ``"<code> <reason>"`` per PEP 3333."""
    if not isinstance(status, str):
        raise WSGIContractError(f"Status must be str, got {type(status).__name__}.")
    parts = status.split(" ", 1)
    if len(parts) != 2:
        raise WSGIContractError(f"Status {status!r} must be '<code> <reason>'.")
    code_text, reason = parts
    if not code_text.isdigit() or len(code_text) != 3:
        raise WSGIContractError(f"Status code {code_text!r} must be three digits.")
    if not reason.strip():
        raise WSGIContractError(f"Status {status!r} has an empty reason phrase.")
    if int(code_text) < 100:
        raise WSGIContractError(f"Status code {code_text!r} is out of range.")


def validate_headers(headers: Any) -> None:
    """Check the header list against the PEP 3333 ``str`` rules."""
    if not isinstance(headers, list):
        raise WSGIContractError(f"Headers must be a list, got {type(headers).__name__}.")
    for item in headers:
        if not isinstance(item, tuple) or len(item) != 2:
            raise WSGIContractError(f"Header entry {item!r} must be a 2-tuple.")
        name, value = item
        if not isinstance(name, str) or not isinstance(value, str):
            raise WSGIContractError(f"Header {item!r} must contain str values (PEP 3333).")
        try:
            name.encode("latin-1")
            value.encode("latin-1")
        except UnicodeEncodeError:  # pragma: no cover - defensive
            raise WSGIContractError(f"Header {item!r} is not latin-1 encodable.") from None
        if "\n" in name or "\n" in value or "\r" in value:
            raise WSGIContractError(f"Header {item!r} contains a newline (header injection).")


def validate_response(status: Any, headers: Any, body: Any) -> None:
    """Validate a complete WSGI response triple."""
    validate_status(status)
    validate_headers(headers)
    if not isinstance(body, Iterable):
        raise WSGIContractError(f"Body must be an iterable of bytes, got {type(body).__name__}.")
    for chunk in body:
        if not isinstance(chunk, bytes):
            raise WSGIContractError(
                f"Body chunks must be bytes, got {type(chunk).__name__} ({chunk!r})."
            )


class _QuietHandler(WSGIRequestHandler):
    """Request handler that delegates access logging to the caller."""

    def log_message(self, format: str, *args: Any) -> None:
        if not getattr(self.server, "quiet", False):
            super().log_message(format, *args)


def serve_wsgiref(
    app: WSGIApp,
    host: str = "127.0.0.1",
    port: int = 8000,
    quiet: bool = False,
    server_class: type[WSGIServer] = WSGIServer,
) -> None:
    """Serve *app* with :mod:`wsgiref`, the standard library reference server.

    This exists to prove and exercise the WSGI contract (and for integration
    tests).  It is single-threaded and not hardened for the public internet —
    use ``myframework run`` for development and Gunicorn/Waitress in production.
    """
    httpd = make_server(host, port, app, server_class=server_class, handler_class=_QuietHandler)
    httpd.quiet = quiet  # type: ignore[attr-defined]
    sys.stderr.write(f" * Serving WSGI app on http://{host}:{port}/ (wsgiref)\n")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:  # pragma: no cover - interactive only
        sys.stderr.write("\n * Shutting down\n")
    finally:
        httpd.server_close()


def make_environ(
    path: str = "/",
    method: str = "GET",
    query_string: str = "",
    headers: Sequence[tuple[str, str]] | Mapping[str, str] | None = None,
    body: bytes | str = b"",
    server_name: str = "localhost",
    server_port: str = "80",
    scheme: str = "http",
    remote_addr: str = "127.0.0.1",
    environ_overrides: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a minimal but valid WSGI environ dictionary.

    Used by the test client and by the integration tests; also convenient when
    calling a WSGI app by hand.  The path is encoded the way PEP 3333 requires
    (latin-1 decoded UTF-8).
    """
    from .utils import parse_options_header  # local import keeps wsgi.py light

    if isinstance(body, str):
        body = body.encode("utf-8")
    path_info = path.encode("utf-8").decode("latin-1")
    environ: dict[str, Any] = {
        "REQUEST_METHOD": method.upper(),
        "SCRIPT_NAME": "",
        "PATH_INFO": path_info,
        "QUERY_STRING": query_string,
        "SERVER_NAME": server_name,
        "SERVER_PORT": str(server_port),
        "SERVER_PROTOCOL": "HTTP/1.1",
        "REMOTE_ADDR": remote_addr,
        "wsgi.version": (1, 0),
        "wsgi.url_scheme": scheme,
        "wsgi.input": __import__("io").BytesIO(body),
        "wsgi.errors": sys.stderr,
        "wsgi.multithread": False,
        "wsgi.multiprocess": False,
        "wsgi.run_once": False,
        "CONTENT_LENGTH": str(len(body)),
    }
    header_items: list[tuple[str, str]]
    if headers is None:
        header_items = []
    elif hasattr(headers, "items"):
        header_items = list(headers.items())
    else:
        header_items = list(headers)
    if not any(name.lower() == "host" for name, _ in header_items):
        default_port = "443" if scheme == "https" else "80"
        header_items.append(
            (
                "Host",
                server_name if str(server_port) == default_port else f"{server_name}:{server_port}",
            )
        )
    for name, value in header_items:
        key = name.upper().replace("-", "_")
        if key in ("CONTENT_TYPE", "CONTENT_LENGTH"):
            environ[key] = value
            continue
        if key == "HOST":
            environ["HTTP_HOST"] = value
            continue
        environ[f"HTTP_{key}"] = value
    content_type = environ.get("CONTENT_TYPE")
    if content_type:
        _main, _options = parse_options_header(content_type)
    if environ_overrides:
        environ.update(environ_overrides)
    return environ
