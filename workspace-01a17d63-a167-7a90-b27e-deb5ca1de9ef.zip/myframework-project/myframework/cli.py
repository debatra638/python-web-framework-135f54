"""The ``myframework`` command line interface.

Commands
--------
``myframework run``
    Import an application and start the development server.
``myframework routes``
    Print every registered rule (a quick way to debug 404s).
``myframework new <name>``
    Scaffold a new project directory (app, templates, static, tests).
``myframework version``
    Print the installed version.

The application can be given as ``module:attribute``, ``module.attribute`` or
just ``module`` (in which case ``app``/``application``/``create_app`` are
tried).  It is also read from the ``MYFRAMEWORK_APP`` environment variable.
"""

from __future__ import annotations

import argparse
import importlib
import os
import sys
import textwrap
from collections.abc import Sequence
from typing import Any

from . import __version__

__all__ = ["load_app", "main"]

_PROJECT_FILES: dict[str, str] = {
    "app.py": '''"""A minimal MyFramework application."""

from myframework import App, render_template, request

app = App(__name__)


@app.route("/")
def index():
    return render_template("index.html", title="Home")


@app.route("/hello/<name>")
def hello(name: str):
    return {"message": f"Hello, {name}!"}


if __name__ == "__main__":
    app.run(debug=True)
''',
    "templates/base.html": """<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{% block title %}MyFramework{% endblock %}</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
  </head>
  <body>
    <main>
      {% block content %}{% endblock %}
    </main>
  </body>
</html>
""",
    "templates/index.html": """{% extends "base.html" %}
{% block title %}{{ title }}{% endblock %}
{% block content %}
  <h1>It works!</h1>
  <p>Edit <code>app.py</code> and <code>templates/index.html</code> to get started.</p>
{% endblock %}
""",
    "static/style.css": """body {
  font-family: system-ui, -apple-system, "Segoe UI", sans-serif;
  margin: 0 auto;
  max-width: 46rem;
  padding: 3rem 1.5rem;
  line-height: 1.6;
  color: #1c2530;
}
h1 { color: #0b5fa5; }
""",
    "tests/test_app.py": """from app import app


def test_index():
    client = app.test_client()
    response = client.get("/")
    assert response.status_code == 200
    assert "It works!" in response.text


def test_hello():
    response = app.test_client().get("/hello/ada")
    assert response.json == {"message": "Hello, ada!"}
""",
    "README.md": """# __PROJECT_NAME__

A MyFramework application.

## Run it

```bash
python -m venv .venv && source .venv/bin/activate
pip install myframework          # or: pip install /path/to/myframework-0.1.0-py3-none-any.whl
myframework run --debug
```

Then open http://127.0.0.1:8000/. You do **not** need to install this project itself to run
it: `myframework run` imports `app.py` from the current directory.

## Test it

```bash
pip install pytest
pytest
```

## Commands

* `myframework run --debug` — development server with automatic reloading
* `myframework routes --app app:app` — list every URL rule
* `pytest` — run the tests in `tests/`

## Layout

```
app.py            routes and views
templates/        Jinja-like templates with inheritance
static/           CSS/JS served at /static/...
tests/            tests using the in-process test client
```

## Deploy

Install this project (it declares `myframework` as a dependency) and serve the WSGI app:

```bash
pip install -e ".[dev]"
gunicorn --workers 4 --bind 0.0.0.0:8000 "app:app"
```
""",
    "pyproject.toml": """[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.build_meta"

[project]
name = "__PROJECT_NAME__"
version = "0.1.0"
description = "A MyFramework application."
requires-python = ">=3.10"
dependencies = ["myframework>=0.1.0"]

[project.optional-dependencies]
dev = ["pytest>=7", "gunicorn>=21"]

[tool.setuptools]
# The application is a single module; there is no importable package to ship.
py-modules = ["app"]

[tool.pytest.ini_options]
# Make `pytest` work from the project root without installing the project.
pythonpath = ["."]
testpaths = ["tests"]
""",
}


def _import_path(spec: str) -> Any:
    """Resolve an application object from an import specification.

    Accepted forms: ``module:attribute``, ``module.attribute`` and plain
    ``module`` (in which case ``app``/``application``/``create_app`` are tried).
    """
    if ":" in spec:
        module_name, _, attribute = spec.partition(":")
        module_name, attribute = module_name.strip(), attribute.strip()
        if not attribute:
            raise SystemExit(f"Missing attribute in --app {spec!r}; use module:attribute.")
        module = _import_module(module_name, spec)
        target = getattr(module, attribute, None)
        if target is None:
            public = sorted(name for name in dir(module) if not name.startswith("_"))[:15]
            raise SystemExit(
                f"Module {module_name!r} has no attribute {attribute!r}. "
                f"Available public names: {', '.join(public)}."
            )
        return target() if attribute == "create_app" else target

    # No colon: try the spec as a module first, then as "module.attribute".
    try:
        module = importlib.import_module(spec)
    except ImportError as first_error:
        module_name, _, attribute = spec.rpartition(".")
        if not module_name:
            raise SystemExit(
                f"Could not import {spec!r}: {first_error}. Run the command from your "
                "project directory or set PYTHONPATH, and use --app module:attribute."
            ) from None
        module = _import_module(module_name, spec)
        target = getattr(module, attribute, None)
        if target is None:
            raise SystemExit(f"Module {module_name!r} has no attribute {attribute!r}.") from None
        return target

    for name in ("app", "application", "create_app"):
        target = getattr(module, name, None)
        if target is not None:
            return target() if name == "create_app" else target
    raise SystemExit(
        f"Module {spec!r} does not define 'app', 'application' or 'create_app'. "
        "Point --app at the variable, e.g. --app mymodule:my_app."
    )


def _import_module(module_name: str, spec: str) -> Any:
    try:
        return importlib.import_module(module_name)
    except ImportError as exc:
        raise SystemExit(
            f"Could not import module {module_name!r} (from --app {spec!r}): {exc}. "
            "Run the command from your project directory or set PYTHONPATH."
        ) from None


def load_app(spec: str | None = None) -> Any:
    """Resolve an application object from *spec* (or the environment/default)."""
    spec = spec or os.environ.get("MYFRAMEWORK_APP")
    if spec is None:
        # Use the current working directory as an import root.
        sys.path.insert(0, os.getcwd())
        for module_name in ("app", "wsgi", "main"):
            if os.path.isfile(os.path.join(os.getcwd(), f"{module_name}.py")):
                spec = module_name
                break
        if spec is None:
            raise SystemExit(
                "No application found. Pass --app module:attribute, set MYFRAMEWORK_APP, "
                "or run the command from a directory containing app.py."
            )
    else:
        sys.path.insert(0, os.getcwd())
    return _import_path(spec)


def cmd_run(args: argparse.Namespace) -> int:
    """Implement ``myframework run``."""
    app = load_app(args.app)
    debug = args.debug or bool(
        getattr(getattr(app, "config", {}), "get", lambda *_: False)("DEBUG")
    )
    if args.debug:
        app.config["DEBUG"] = True
    app.run(
        host=args.host,
        port=args.port,
        debug=debug,
        reload=args.reload,
        threaded=not args.no_threads,
        quiet=False,
    )
    return 0


def cmd_routes(args: argparse.Namespace) -> int:
    """Implement ``myframework routes``."""
    app = load_app(args.app)
    print(f"App: {app.import_name!r}  ({len(app.url_map)} rules)")
    print(f"{'URL':<40} {'METHODS':<32} ENDPOINT")
    print("-" * 100)
    for rule in app.url_map:
        methods = ",".join(sorted(rule.methods))
        print(f"{rule.rule:<40} {methods:<32} {rule.endpoint}")
    return 0


def cmd_new(args: argparse.Namespace) -> int:
    """Implement ``myframework new <name>``."""
    target = os.path.abspath(args.name)
    if os.path.exists(target) and os.listdir(target):
        raise SystemExit(f"Directory {target} already exists and is not empty.")
    for relative, content in _PROJECT_FILES.items():
        destination = os.path.join(target, relative)
        os.makedirs(os.path.dirname(destination), exist_ok=True)
        if os.path.exists(destination):
            continue
        with open(destination, "w", encoding="utf-8") as handle:
            handle.write(content.replace("__PROJECT_NAME__", os.path.basename(target)))
    print(f"Created project in {target}")
    print(
        textwrap.dedent(f"""\
        Next steps:
          cd {os.path.basename(target)}
          python -m venv .venv && source .venv/bin/activate
          pip install myframework        # already installed? skip this line
          myframework run --debug        # http://127.0.0.1:8000/
          pytest                         # after: pip install pytest
        """)
    )
    return 0


def cmd_version(args: argparse.Namespace) -> int:
    """Implement ``myframework version``."""
    print(f"myframework {__version__}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    """Create the argument parser for the CLI."""
    parser = argparse.ArgumentParser(
        prog="myframework",
        description="MyFramework command line interface",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=textwrap.dedent("""\
            Examples:
              myframework run --app app:app --debug
              myframework routes --app mymodule:application
              myframework new mysite
            """),
    )
    parser.add_argument("--version", action="version", version=f"myframework {__version__}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    run_parser = subparsers.add_parser("run", help="start the development server")
    run_parser.add_argument("--app", "-a", help="application import path, e.g. app:app")
    run_parser.add_argument("--host", default="127.0.0.1", help="bind address (default 127.0.0.1)")
    run_parser.add_argument("--port", "-p", type=int, default=8000, help="port (default 8000)")
    run_parser.add_argument("--debug", action="store_true", help="enable debug mode")
    run_parser.add_argument(
        "--reload",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="reload on file changes (default: on in debug mode)",
    )
    run_parser.add_argument("--no-threads", action="store_true", help="serve one request at a time")
    run_parser.set_defaults(func=cmd_run)

    routes_parser = subparsers.add_parser("routes", help="print the URL map")
    routes_parser.add_argument("--app", "-a", help="application import path, e.g. app:app")
    routes_parser.set_defaults(func=cmd_routes)

    new_parser = subparsers.add_parser("new", help="scaffold a new project")
    new_parser.add_argument("name", help="directory to create")
    new_parser.set_defaults(func=cmd_new)

    version_parser = subparsers.add_parser("version", help="print the version")
    version_parser.set_defaults(func=cmd_version)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Entry point used by the ``myframework`` console script."""
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.command == "run" and args.reload is None:
        args.reload = bool(args.debug)
    try:
        return int(args.func(args))
    except KeyboardInterrupt:  # pragma: no cover - interactive only
        print("\nStopped.", file=sys.stderr)
        return 130


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
