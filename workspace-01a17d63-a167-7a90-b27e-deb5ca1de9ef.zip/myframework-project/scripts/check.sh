#!/usr/bin/env bash
# Run every automated check the project defines: lint, format, types, tests, build.
#
#   ./scripts/check.sh          # full run (lint, format, types, tests, build, install)
#   FAST=1 ./scripts/check.sh   # skip the slow tests, the build and the install rehearsal
set -euo pipefail

cd "$(dirname "$0")/.."
PYTHON="${PYTHON:-python3}"

step() { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }

step "ruff check"
ruff check .

step "ruff format --check"
ruff format --check .

step "mypy (strict)"
mypy

step "docs/api.md is in sync with the code"
"$PYTHON" scripts/build_api_docs.py --check

step "pytest"
if [[ "${FAST:-0}" == "1" ]]; then
    "$PYTHON" -m pytest -q -m "not slow"
else
    "$PYTHON" -m pytest -q
fi

if [[ "${FAST:-0}" != "1" ]]; then
    step "build sdist + wheel"
    rm -rf dist build ./*.egg-info
    "$PYTHON" -m build

    if "$PYTHON" -m twine --version >/dev/null 2>&1; then
        step "validate the metadata (twine check)"
        "$PYTHON" -m twine check dist/*
    else
        printf 'twine is not installed; skipping metadata validation (pip install twine)\n'
    fi

    step "install from the artifacts and use them like a stranger would"
    ./scripts/verify_install.sh
fi

printf '\n\033[1;32mAll checks passed.\033[0m\n'
