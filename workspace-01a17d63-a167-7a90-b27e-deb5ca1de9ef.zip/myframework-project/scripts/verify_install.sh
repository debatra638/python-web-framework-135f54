#!/usr/bin/env bash
# Prove that a developer who has never seen the source can install and use MyFramework.
#
#   ./scripts/verify_install.sh              # build, install from wheel, exercise everything
#   PYTHON=/path/to/python3 ./scripts/verify_install.sh
#   KEEP=1 ./scripts/verify_install.sh       # keep the temp directory for inspection
#
# What it does, using only the *built artifacts* (never the source tree):
#   1. builds sdist + wheel and validates them with twine
#   2. creates a throwaway virtual environment in /tmp
#   3. installs the wheel into it
#   4. writes a small app outside the repo and runs it with the test client,
#      a real dev server and a real WSGI server
#   5. scaffolds a project with `myframework new`, installs it, and runs its tests
# Nothing is imported from the working tree: PYTHONPATH is cleared and the working
# directory is always the temp dir, so a pass means the *package* is complete.
set -euo pipefail

REPO="$(cd "$(dirname "$0")/.." && pwd)"
PYTHON="${PYTHON:-python3}"

if [[ -t 1 ]]; then
    BOLD=$'\033[1;32m'; DIM=$'\033[2m'; RESET=$'\033[0m'; STEP=$'\033[1;34m'
else
    BOLD=""; DIM=""; RESET=""; STEP=""
fi
step() { printf '\n%s==> %s%s\n' "$STEP" "$*" "$RESET"; }
ok()   { printf '%s  ✓ %s%s\n' "$BOLD" "$*" "$RESET"; }

WORK="$(mktemp -d "${TMPDIR:-/tmp}/myframework-verify-XXXXXX")"
cleanup() {
    if [[ "${KEEP:-0}" == "1" ]]; then
        printf '%s\n  Kept: %s%s\n' "$DIM" "$WORK" "$RESET"
    else
        rm -rf "$WORK"
    fi
}
trap cleanup EXIT

export PIP_DISABLE_PIP_VERSION_CHECK=1
unset PYTHONPATH || true

# ---------------------------------------------------------------------------
step "1/7  build the distributions"
# ---------------------------------------------------------------------------
rm -rf "$REPO/dist" "$REPO/build"
"$PYTHON" -m build --outdir "$REPO/dist" >"$WORK/build.log" 2>&1 || {
    cat "$WORK/build.log"; exit 1; }
WHEEL="$(ls "$REPO"/dist/*.whl)"
SDIST="$(ls "$REPO"/dist/*.tar.gz)"
ok "wheel: $(basename "$WHEEL")"
ok "sdist: $(basename "$SDIST")"

VERSION="$(basename "$WHEEL" | cut -d- -f2)"

if "$PYTHON" -m twine --version >/dev/null 2>&1; then
    if "$PYTHON" -m twine check "$REPO"/dist/* >"$WORK/twine.log" 2>&1; then
        ok "twine check: metadata and long description are valid"
    else
        cat "$WORK/twine.log"; exit 1
    fi
else
    printf '%s  · twine not installed; skipping metadata validation%s\n' "$DIM" "$RESET"
fi

# ---------------------------------------------------------------------------
step "2/7  create an isolated virtual environment"
# ---------------------------------------------------------------------------
VENV="$WORK/venv"
"$PYTHON" -m venv "$VENV"
V="$VENV/bin"
[[ -x "$V/python" ]] || V="$VENV/Scripts"   # Windows layout
"$V/python" -m pip install --quiet --upgrade pip
ok "venv: $VENV"

# ---------------------------------------------------------------------------
step "3/7  install the wheel (offline, no source tree on the path)"
# ---------------------------------------------------------------------------
"$V/python" -m pip install --quiet --no-index --find-links "$REPO/dist" myframework
# Resolve from a neutral directory so the repo cannot shadow the install.
SITE="$(cd "$WORK" && "$V/python" -c 'import myframework, os; print(os.path.dirname(myframework.__file__))')"
if [[ "$SITE" == "$REPO"* ]]; then
    echo "installed package resolves into the source tree: $SITE" >&2; exit 1
fi
ok "imported from $SITE"
ok "version: $("$V/myframework" version)"
ok "python -m myframework: $("$V/python" -m myframework version)"
(
    # Run from a neutral directory: Python puts the current directory first on
    # sys.path, so running inside the repo would import the source tree instead
    # of the installed package.
    cd "$WORK"
    EXPECTED_VERSION="$VERSION" "$V/python" - <<'PY'
import os

import myframework

expected = {"App", "request", "Response", "jsonify", "render_template", "url_for"}
missing = expected - set(myframework.__all__)
assert not missing, f"missing public names: {missing}"
assert myframework.__version__ == os.environ["EXPECTED_VERSION"], "version mismatch"
assert os.path.isfile(os.path.join(os.path.dirname(myframework.__file__), "py.typed"))
print("  public API, version and py.typed marker OK")
PY
)

# ---------------------------------------------------------------------------
step "4/7  use the package as a stranger would (app outside the repo)"
# ---------------------------------------------------------------------------
APP_DIR="$WORK/site"
mkdir -p "$APP_DIR/templates" "$APP_DIR/static"
cat >"$APP_DIR/hello.py" <<'PY'
"""A tiny app written only against the public API."""

from myframework import App, abort, jsonify, render_template, request, url_for

app = App(__name__, template_dir="templates", static_dir="static")


@app.route("/")
def index():
    return render_template("index.html", title="Verify", items=["alpha", "beta"])


@app.route("/users/<int:user_id>")
def user(user_id):
    if user_id == 0:
        abort(404, "no such user")
    return {"id": user_id, "url": url_for("user", user_id=user_id)}


@app.route("/echo", methods=["POST"])
def echo():
    return jsonify(body=request.get_json(silent=True)), 201


@app.errorhandler(404)
def not_found(error):
    return jsonify(error="not_found", message=error.description), 404
PY
cat >"$APP_DIR/templates/index.html" <<'HTML'
{% extends "base.html" %}
{% block title %}{{ title }}{% endblock %}
{% block content %}
<ul>{% for item in items %}<li>{{ loop.index }}: {{ item }}</li>{% endfor %}</ul>
{% endblock %}
HTML
cat >"$APP_DIR/templates/base.html" <<'HTML'
<!doctype html>
<title>{% block title %}site{% endblock %}</title>
<link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
{% block content %}{% endblock %}
HTML
printf 'body { color: #123; }\n' >"$APP_DIR/static/style.css"

(
    cd "$APP_DIR"
    "$V/python" - <<'PY'
from hello import app

client = app.test_client()

page = client.get("/")
assert page.status_code == 200, page.text
assert "<li>1: alpha</li>" in page.text
assert 'href="/static/style.css"' in page.text

api = client.get("/users/7")
assert api.json == {"id": 7, "url": "/users/7"}, api.json

created = client.post("/echo", json={"x": 1})
assert created.status_code == 201 and created.json == {"body": {"x": 1}}

missing = client.get("/users/0")
assert missing.status_code == 404 and missing.json["error"] == "not_found"

assert client.get("/static/style.css").status_code == 200
assert client.get("/nope").status_code == 404
print("  test client: routing, templates, static files, JSON, errors OK")
PY
    ok "test client round-trip"
)

# `myframework routes` must work from the project directory with no arguments.
(
    cd "$APP_DIR"
    "$V/myframework" routes --app hello:app >routes.txt
    grep -q "/users/<int:user_id>" routes.txt
)
ok "myframework routes"

# A real HTTP server, as a user would start it.
(
    cd "$APP_DIR"
    PORT="$("$V/python" -c 'import socket;s=socket.socket();s.bind(("127.0.0.1",0));print(s.getsockname()[1]);s.close()')"
    "$V/myframework" run --app hello:app --port "$PORT" --no-reload >server.log 2>&1 &
    SERVER_PID=$!
    trap 'kill $SERVER_PID 2>/dev/null || true' RETURN
    for _ in $(seq 1 100); do
        if "$V/python" -c "import urllib.request,sys; urllib.request.urlopen(f'http://127.0.0.1:$PORT/', timeout=0.5)" 2>/dev/null; then break; fi
        sleep 0.1
    done
    "$V/python" - "$PORT" <<'PY'
import json
import sys
import urllib.error
import urllib.request

port = sys.argv[1]
base = f"http://127.0.0.1:{port}"

with urllib.request.urlopen(base + "/users/3", timeout=5) as response:
    assert response.status == 200
    assert json.loads(response.read()) == {"id": 3, "url": "/users/3"}
    assert response.headers["X-Content-Type-Options"] == "nosniff"

request = urllib.request.Request(
    base + "/echo", data=b'{"k": "v"}', headers={"Content-Type": "application/json"}
)
with urllib.request.urlopen(request, timeout=5) as response:
    assert response.status == 201
    assert json.loads(response.read()) == {"body": {"k": "v"}}

try:
    urllib.request.urlopen(base + "/missing", timeout=5)
except urllib.error.HTTPError as error:
    assert error.code == 404
else:
    raise AssertionError("404 expected")
print("  dev server: GET, POST, headers, 404 OK")
PY
    kill "$SERVER_PID" 2>/dev/null || true
    wait "$SERVER_PID" 2>/dev/null || true
)
ok "myframework run (real HTTP)"

# A production WSGI server must also be able to import the app.
(
    cd "$APP_DIR"
    "$V/python" -c "
import wsgiref.simple_server, threading, urllib.request
from hello import app
server = wsgiref.simple_server.make_server('127.0.0.1', 0, app)
thread = threading.Thread(target=server.handle_request, daemon=True)
thread.start()
with urllib.request.urlopen(f'http://127.0.0.1:{server.server_port}/', timeout=5) as r:
    assert r.status == 200
print('  plain WSGI server: OK')
"
)
ok "works as a plain WSGI app"

# ---------------------------------------------------------------------------
step "5/7  scaffold a project with the CLI and run its tests"
# ---------------------------------------------------------------------------
(
    cd "$WORK"
    "$V/myframework" new demo >/dev/null
    "$V/python" -m pip install --quiet pytest
    cd demo
    # Plain `pytest`, exactly as the generated README tells the user to run it.
    "$V/pytest" -q 2>&1 | tail -2 | sed 's/^/  /'
    # The generated project declares myframework as a dependency and must be
    # installable itself (editable), since that is what `pip install -e .` does.
    "$V/python" -m pip install --quiet -e . 2>&1 | tail -2 | sed 's/^/  /'
    "$V/python" -c "import app, importlib.metadata as m; print('  project installs:', m.version(\"demo\"))"
)
ok "generated project: installs and its tests pass"

# ---------------------------------------------------------------------------
step "6/7  the source distribution installs too"
# ---------------------------------------------------------------------------
"$V/python" -m pip uninstall --quiet -y myframework
# An sdist build needs setuptools inside pip's isolated build environment, so the
# fully offline path is the wheel (see docs/installation.md).  Try offline first
# and fall back to a normal install when the build backend is not cached.
if ! "$V/python" -m pip install --quiet --no-index "$SDIST" 2>"$WORK/sdist-offline.log"; then
    printf '%s  · offline sdist build needs setuptools; retrying with the index enabled%s
' \
        "$DIM" "$RESET"
    "$V/python" -m pip install --quiet "$SDIST"
fi
"$V/python" -c "import myframework; print('  import from sdist install OK', myframework.__version__)"
ok "sdist install"

# ---------------------------------------------------------------------------
step "7/7  the shipped test suite runs from the unpacked sdist"
# ---------------------------------------------------------------------------
UNPACKED="$WORK/unpacked"
mkdir -p "$UNPACKED"
tar xzf "$SDIST" -C "$UNPACKED"
SRC="$UNPACKED/myframework-$VERSION"
(
    cd "$SRC"
    PYTHONPATH="$SRC" "$V/python" -m pytest -q -m "not slow" \
        -p no:cacheprovider 2>&1 | tail -2 | sed 's/^/  /'
)
ok "unpacked sdist: tests pass without touching the repo"

printf '\n%sAll install checks passed.%s  (MyFramework %s)\n' "$BOLD" "$RESET" "$VERSION"
