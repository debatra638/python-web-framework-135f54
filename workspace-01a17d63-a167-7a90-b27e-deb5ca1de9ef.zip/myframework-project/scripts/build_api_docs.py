#!/usr/bin/env python3
"""Generate ``docs/api.md`` from the package's own docstrings.

The reference is derived from the code, so it cannot drift: run this script after
changing a public signature.

    python scripts/build_api_docs.py            # rewrite docs/api.md
    python scripts/build_api_docs.py --check    # exit 1 if the file is stale
"""

from __future__ import annotations

import argparse
import inspect
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import myframework  # noqa: E402  (after sys.path fix)
from myframework import exceptions as exceptions_module  # noqa: E402
from myframework.globals import LocalProxy  # noqa: E402

TARGET = ROOT / "docs" / "api.md"

#: Groups shown in the reference, in order.  Each entry maps a heading to the
#: public names documented under it.
SECTIONS: list[tuple[str, str, list[str]]] = [
    (
        "The application",
        "Create one `App` per process; it is also a WSGI application.",
        ["App"],
    ),
    (
        "Request, response and helpers",
        "Values available inside a view, and the objects you return from one.",
        [
            "request",
            "Response",
            "make_response",
            "jsonify",
            "redirect",
            "abort",
            "stream_response",
            "Request",
        ],
    ),
    (
        "Context locals and template helpers",
        "Proxies bound to the current request/application, plus the template shortcuts.",
        [
            "current_app",
            "g",
            "has_request_context",
            "url_for",
            "render_template",
            "render_template_string",
        ],
    ),
    (
        "Routing",
        "Rules, converters, matching and URL building.",
        ["Map", "Rule", "BaseConverter"],
    ),
    (
        "Templates",
        "The engine, its environment and the loaders.",
        [
            "TemplateEnvironment",
            "FileSystemLoader",
            "DictLoader",
        ],
    ),
    (
        "Static files",
        "Traversal-safe file serving.",
        ["StaticFiles", "safe_join", "send_file", "send_from_directory"],
    ),
    (
        "Configuration and data structures",
        "Settings and the request/response containers.",
        ["Config", "Headers", "MultiDict", "FileStorage"],
    ),
    (
        "Middleware",
        "WSGI-level wrappers; the first one added is the outermost layer.",
        [
            "Middleware",
            "WSGIMiddleware",
            "RequestIDMiddleware",
            "AccessLogMiddleware",
            "HeaderMiddleware",
            "SecurityHeadersMiddleware",
            "CORSMiddleware",
            "TrustedHostMiddleware",
            "ProxyFix",
            "HTTPSRedirectMiddleware",
            "middleware_chain",
        ],
    ),
    (
        "WSGI utilities",
        "PEP 3333 helpers, usable without the rest of the framework.",
        ["WSGIApp", "wsgi_application", "serve_wsgiref"],
    ),
    (
        "Exceptions",
        "Import from either `myframework` or `myframework.exceptions`.",
        [
            "HTTPException",
            "BadRequest",
            "Unauthorized",
            "Forbidden",
            "NotFound",
            "MethodNotAllowed",
            "Conflict",
            "UnsupportedMediaType",
            "PayloadTooLarge",
            "InternalServerError",
            "ServiceUnavailable",
            "RequestRedirect",
            "FrameworkException",
            "RoutingError",
            "ConfigurationError",
            "SecurityError",
            "TemplateError",
            "TemplateNotFound",
            "TemplateSyntaxError",
            "TemplateRuntimeError",
            "UndefinedError",
        ],
    ),
]


_ROLE_RE = __import__("re").compile(r":(?:class|meth|func|attr|mod|data|exc|obj):`~?([^`]+)`")
_DOUBLE_TICK_RE = __import__("re").compile(r"``([^`]+)``")


def clean_doc(text: str) -> str:
    """Turn Sphinx roles and literal markup in docstrings into Markdown."""
    text = _ROLE_RE.sub(r"`\1`", text)
    text = _DOUBLE_TICK_RE.sub(r"`\1`", text)
    return text.replace("`~myframework.", "`myframework.")


def first_paragraph(doc: str | None) -> str:
    """Return the summary line/paragraph of a docstring."""
    if not doc:
        return ""
    lines: list[str] = []
    for line in inspect.cleandoc(doc).splitlines():
        if not line.strip():
            if lines:
                break
            continue
        lines.append(line.strip())
    return clean_doc(" ".join(lines))


def _annotation(value: Any) -> str:
    """Render an annotation without the quotes :mod:`inspect` adds for strings."""
    text = value if isinstance(value, str) else str(value)
    return text.replace("typing.", "").replace("myframework.", "")


def _sig(obj: Any) -> str:
    """Render a readable signature (annotations and defaults kept, ``self`` dropped)."""
    try:
        sig = inspect.signature(obj)
    except (TypeError, ValueError):  # pragma: no cover - builtins
        return ""
    parts: list[str] = []
    keyword_only_started = False
    for param in sig.parameters.values():
        if param.name == "self":
            continue
        if param.kind is inspect.Parameter.KEYWORD_ONLY and not keyword_only_started:
            parts.append("*")
            keyword_only_started = True
        text = param.name
        if param.kind is inspect.Parameter.VAR_POSITIONAL:
            text = f"*{param.name}"
        elif param.kind is inspect.Parameter.VAR_KEYWORD:
            text = f"**{param.name}"
        if param.annotation is not inspect.Parameter.empty:
            text += f": {_annotation(param.annotation)}"
        if param.default is not inspect.Parameter.empty:
            text += f" = {param.default!r}"
        parts.append(text)
    result = "(" + ", ".join(parts) + ")"
    if sig.return_annotation is not inspect.Signature.empty:
        result += f" -> {_annotation(sig.return_annotation)}"
    return result


def resolve(name: str) -> Any:
    if hasattr(myframework, name):
        return getattr(myframework, name)
    return getattr(exceptions_module, name)


def describe_members(obj: Any) -> list[str]:
    """Render the public methods of a class (name, signature, one-line summary)."""
    if not inspect.isclass(obj):
        return []
    rows: list[str] = []
    for member_name, member in sorted(vars(obj).items()):
        if member_name.startswith("_"):
            continue
        if isinstance(member, property):
            summary = first_paragraph(inspect.getdoc(member))
            rows.append(f"- **`{member_name}`** (property) — {summary}")
            continue
        if isinstance(member, (staticmethod, classmethod)):
            member = member.__func__
        if isinstance(member, type):
            # A class attribute such as ``request_class = Request``.
            rows.append(
                f"- **`{member_name}`** (class attribute) — defaults to `{member.__name__}`"
            )
            continue
        if not callable(member):
            continue
        summary = first_paragraph(inspect.getdoc(member))
        rows.append(f"- **`{member_name}`**`{_sig(member)}` — {summary}")
    return rows


def render() -> str:
    lines: list[str] = [
        "# API reference",
        "",
        "Every public name in MyFramework, generated from the source docstrings by",
        "`scripts/build_api_docs.py`. Everything documented here is implemented and tested;",
        "anything not listed here is internal and may change without notice.",
        "",
        "```python",
        "import myframework              # everything is exported from the top level",
        "from myframework import App, request, jsonify, render_template",
        "```",
        "",
        f"Version: `{myframework.__version__}`",
        "",
        "## Contents",
        "",
    ]
    for title, _intro, _names in SECTIONS:
        anchor = title.lower().replace(" ", "-").replace(",", "")
        lines.append(f"- [{title}](#{anchor})")
    lines.append("")

    documented: set[str] = set()
    for title, intro, names in SECTIONS:
        lines += [f"## {title}", "", intro, ""]
        for name in names:
            documented.add(name)
            obj = resolve(name)
            summary = first_paragraph(inspect.getdoc(obj))
            if inspect.isclass(obj):
                base = f"### `{name}`"
                lines.append(base)
                lines.append("")
                if summary:
                    lines += [summary, ""]
                members = describe_members(obj)
                if members:
                    source_module = getattr(obj, "__module__", "")
                    if source_module:
                        lines += [f"Defined in `{source_module}`.", ""]
                    lines += members
                    lines.append("")
            else:
                # Context-local proxies answer attribute lookups from the active
                # request, so they must not be introspected.
                sig = "" if isinstance(obj, LocalProxy) else (_sig(obj) if callable(obj) else "")
                lines.append(f"### `{name}{sig}`")
                lines.append("")
                if summary:
                    lines += [summary, ""]

    missing = [
        name for name in myframework.__all__ if name not in documented and name != "__version__"
    ]
    if missing:
        lines += [
            "## Also exported",
            "",
            ", ".join(f"`{name}`" for name in sorted(missing)),
            "",
            "These helpers are re-exported for convenience; see the module docstrings in the",
            "source distribution for details.",
            "",
        ]

    lines += [
        "---",
        "",
        "Generated by `scripts/build_api_docs.py` — do not edit by hand.",
        "",
    ]
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--check",
        action="store_true",
        help="fail if docs/api.md differs from what the code would generate",
    )
    args = parser.parse_args(argv)

    content = render()
    if args.check:
        if not TARGET.exists() or TARGET.read_text(encoding="utf-8") != content:
            print("docs/api.md is out of date; run scripts/build_api_docs.py")
            return 1
        print("docs/api.md is up to date")
        return 0

    TARGET.write_text(content, encoding="utf-8")
    print(f"wrote {TARGET.relative_to(ROOT)} ({len(content.splitlines())} lines)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
