# Installation

MyFramework is a pure-Python package with **no runtime dependencies**. It supports
Python 3.10 – 3.13 on any operating system.

This page lists every supported way to install it. Pick the first one that matches how you
received the project.

---

## 1. From a wheel (recommended for users)

A wheel is a single file that installs in seconds and needs no build step:

```console
$ python -m venv .venv
$ source .venv/bin/activate           # Windows: .venv\Scripts\activate
$ pip install myframework-0.1.0-py3-none-any.whl
$ myframework version
myframework 0.1.0
```

The wheel installs only the `myframework` package plus its `py.typed` marker; it contains
no tests, examples or documentation.

## 2. From the source distribution

An sdist (`myframework-0.1.0.tar.gz`) is what you get from PyPI when no wheel exists for
your platform. It contains the full source, tests, examples and docs:

```console
$ pip install myframework-0.1.0.tar.gz
```

## 3. From the source tree (editable, for contributing)

```console
$ git clone <your-fork-url> myframework
$ cd myframework
$ python -m venv .venv && source .venv/bin/activate
$ pip install -e ".[dev,servers]"    # dev tools + gunicorn/waitress
$ pytest                             # 582 tests, ~15 s
$ ./scripts/check.sh                 # lint + types + tests + build
```

`pip install -e .` links the working tree into the environment, so edits take effect
without reinstalling.

## 4. Offline / air-gapped install

Ship the wheel to the target machine (a USB stick is fine) and install it with
`--no-index` so pip does not try to reach the network:

```console
$ pip install --no-index --find-links ./dist myframework
```

To build such a folder on a machine that has network access:

```console
$ pip download myframework==0.1.0 --no-deps -d ./dist
```

Installing an **sdist** offline additionally needs the build backend (`setuptools`) in pip's
isolated build environment, so on a machine with no wheel cache use the wheel — that is the
artifact designed for offline installs.

## 5. From PyPI (once published)

```console
$ pip install myframework
```

The project is not on PyPI yet. Everything needed to publish it is in the repository —
`python -m build` produces the artifacts and `python -m twine check dist/*` verifies them;
see [Releasing](#releasing) below.

---

## Next steps

* [Quickstart](quickstart.md) — a working app in five minutes.
* [API reference](api.md) — every public name, in one page.
* [Deployment](deployment.md) — Gunicorn, nginx, systemd.

## Verifying the installation

```console
$ python -m myframework version        # works without the console script
$ python -c "import myframework; print(myframework.__version__, myframework.__file__)"
$ myframework --help
```

If `myframework` is "command not found" but the import works, the script directory is not
on `PATH` — use `python -m myframework ...` instead.

## Type checking

The package ships a `py.typed` marker and is fully annotated, so mypy/pyright pick up the
types automatically:

```console
$ pip install mypy
$ mypy your_app.py        # no stubs needed
```

## Requirements

| Item | Requirement |
| --- | --- |
| Python | 3.10, 3.11, 3.12 or 3.13 |
| Runtime dependencies | none (standard library only) |
| Optional: production server | `gunicorn` (Linux/macOS) or `waitress` (any OS) — `pip install "myframework[servers]"` |
| Optional: development | `pytest`, `pytest-cov`, `ruff`, `mypy`, `build` — `pip install "myframework[dev]"` |

## Uninstalling

```console
$ pip uninstall myframework
```

Nothing outside `site-packages` is touched: the framework writes no configuration files and
no caches (the `.mypy_cache`/`__pycache__` directories you may see belong to your own
project).

## Releasing (for maintainers)

```console
$ rm -rf dist build
$ python -m build                       # sdist + wheel
$ python -m twine check dist/*          # validates metadata and the README rendering
$ python -m twine upload dist/*         # needs PyPI credentials
```

Before the first upload, add real `[project.urls]` entries to `pyproject.toml` (Homepage,
Documentation, Source, Changelog) — they are deliberately absent rather than pointing at
placeholders. `scripts/verify_install.sh` rehearses the whole user experience from the
built artifacts without touching the source tree.
