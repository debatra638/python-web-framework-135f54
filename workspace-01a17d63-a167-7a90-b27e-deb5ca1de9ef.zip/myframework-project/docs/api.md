# API reference

Every public name in MyFramework, generated from the source docstrings by
`scripts/build_api_docs.py`. Everything documented here is implemented and tested;
anything not listed here is internal and may change without notice.

```python
import myframework              # everything is exported from the top level
from myframework import App, request, jsonify, render_template
```

Version: `0.1.0`

## Contents

- [The application](#the-application)
- [Request, response and helpers](#request-response-and-helpers)
- [Context locals and template helpers](#context-locals-and-template-helpers)
- [Routing](#routing)
- [Templates](#templates)
- [Static files](#static-files)
- [Configuration and data structures](#configuration-and-data-structures)
- [Middleware](#middleware)
- [WSGI utilities](#wsgi-utilities)
- [Exceptions](#exceptions)

## The application

Create one `App` per process; it is also a WSGI application.

### `App`

A MyFramework application — also a WSGI application.

Defined in `myframework.app`.

- **`add_url_rule`**`(rule: str, endpoint: str | None = None, view_func: ViewFunction | None = None, methods: Iterable[str] | None = None, defaults: Mapping[str, Any] | None = None, strict_slashes: bool | None = None) -> Rule` — Register a URL rule (the non-decorator form of `route`).
- **`after_request`**`(func: ViewFunction) -> ViewFunction` — Register a function that receives and returns the response (reverse order).
- **`app_context`**`() -> Iterator[AppContext]` — Push an application context (no request) for scripts and tests.
- **`before_request`**`(func: ViewFunction) -> ViewFunction` — Register a function that runs before the view (in order).
- **`context_processor`**`(func: Callable[[], Mapping[str, Any]]) -> Callable[[], Mapping[str, Any]]` — Register a callable whose return value is added to every template context.
- **`converter`**`(name: str) -> Callable[[type[BaseConverter]], type[BaseConverter]]` — Register a custom URL converter under *name*.
- **`delete`**`(rule: str, **kwargs: Any) -> Callable[[ViewFunction], ViewFunction]` — Shortcut for `@app.route(rule, methods=["DELETE"])`.
- **`describe`**`() -> str` — A human readable summary of the registered routes (used by the CLI).
- **`dispatch_request`**`(request: Request) -> Response` — Call the view function for the matched route.
- **`do_teardown_request`**`(error: BaseException | None = None) -> None` — Run `teardown_request` hooks, swallowing nothing but logging errors.
- **`errorhandler`**`(code_or_exception: Any) -> Callable[[ErrorHandler], ErrorHandler]` — Register an error handler for a status code or exception class.
- **`finalize_request`**`(value: Any, request: Request | None = None) -> Response` — Convert a handler's return value into a response.
- **`full_dispatch_request`**`(request: Request) -> Response` — Run the whole request pipeline and always return a response.
- **`get`**`(rule: str, **kwargs: Any) -> Callable[[ViewFunction], ViewFunction]` — Shortcut for `@app.route(rule, methods=["GET"])`.
- **`handle_exception`**`(exc: Exception) -> Response` — Handle an unhandled exception (500) with logging and safe output.
- **`handle_http_exception`**`(exc: HTTPException) -> Response` — Render an `HTTPException` with a registered handler if present.
- **`handle_user_exception`**`(exc: Exception, request: Request) -> Response` — Turn an exception raised during dispatch into a response.
- **`log_exception`**`(exc: BaseException) -> None` — Log an exception with its traceback (or the request id, if any).
- **`make_response`**`(value: Any, request: Request | None = None) -> Response` — Convert a view return value into a `Response`.
- **`name`** (property) — The application's import name.
- **`patch`**`(rule: str, **kwargs: Any) -> Callable[[ViewFunction], ViewFunction]` — Shortcut for `@app.route(rule, methods=["PATCH"])`.
- **`post`**`(rule: str, **kwargs: Any) -> Callable[[ViewFunction], ViewFunction]` — Shortcut for `@app.route(rule, methods=["POST"])`.
- **`preprocess_request`**`(request: Request) -> Response | None` — Run `before_request` hooks; the first response returned wins.
- **`process_response`**`(response: Response, request: Request) -> Response` — Run `after_request` hooks (reverse order) and default headers.
- **`put`**`(rule: str, **kwargs: Any) -> Callable[[ViewFunction], ViewFunction]` — Shortcut for `@app.route(rule, methods=["PUT"])`.
- **`register_error_handler`**`(code_or_exception: Any, func: ErrorHandler) -> None` — Register an error handler without using the decorator.
- **`register_error_handler_instance`**`(exc: HTTPException, func: ErrorHandler) -> None` — Register a handler for the exact class of *exc*.
- **`render_template`**`(template_name: str, **context: Any) -> str` — Render a template file with the request context and processors.
- **`render_template_string`**`(source: str, **context: Any) -> str` — Render a template given as a string.
- **`request_class`** (class attribute) — defaults to `Request`
- **`response_class`** (class attribute) — defaults to `Response`
- **`route`**`(rule: str, methods: Iterable[str] | None = None, endpoint: str | None = None, defaults: Mapping[str, Any] | None = None, strict_slashes: bool | None = None) -> Callable[[ViewFunction], ViewFunction]` — Decorator registering a view function for *rule*.
- **`run`**`(host: str = '127.0.0.1', port: int = 8000, debug: bool | None = None, reload: bool | None = None, threaded: bool = True, quiet: bool = False) -> None` — Start the development server.
- **`static_files`** (property) — The `myframework.static.StaticFiles` handler for `STATIC_DIR`.
- **`teardown_request`**`(func: ViewFunction) -> ViewFunction` — Register a function that always runs at the end of the request.
- **`template_env`** (property) — The template environment (created on first use).
- **`template_filter`**`(name: str | None = None) -> Callable[[Callable[..., Any]], Callable[..., Any]]` — Register a template filter, e.g. `@app.template_filter("slug")`.
- **`template_global`**`(name: str | None = None) -> Callable[[Any], Any]` — Register a template global (function or value).
- **`test_client`**`(**overrides: Any) -> Any` — Return a `myframework.testing.Client` bound to this app.
- **`test_request_context`**`(path: str = '/', method: str = 'GET', **kwargs: Any) -> RequestContext` — Push a synthetic request context (useful in tests and shell sessions).
- **`url_for`**`(endpoint: str, *, _external: bool = False, _scheme: str | None = None, _anchor: str | None = None, **values: Any) -> str` — Build the URL for *endpoint*.
- **`use`**`(middleware: Any) -> Any` — Add a WSGI middleware layer.
- **`wsgi_app`** (property) — The WSGI callable for this application (middleware included).

## Request, response and helpers

Values available inside a view, and the objects you return from one.

### `request`

Forward every operation to the object returned by *getter*.

### `Response`

An HTTP response.

Defined in `myframework.response`.

- **`add_etag`**`(value: str | None = None) -> str` — Set an `ETag` header, generating one from the body if needed.
- **`add_vary`**`(field: str) -> None` — Add a field name to the `Vary` header without duplicating it.
- **`cache_control`**`(max_age: int | None = None, public: bool = False, no_cache: bool = False, no_store: bool = False, must_revalidate: bool = False) -> None` — Set a `Cache-Control` header from common directives.
- **`close`**`() -> None` — Release resources held by a streaming body.
- **`content_type`** (property) — The full `Content-Type` header value.
- **`data`** (property) — The response body as bytes.
- **`delete_cookie`**`(key: str, path: str = '/', domain: str | None = None, secure: bool = False, httponly: bool = False, samesite: str | None = 'Lax') -> None` — Expire a cookie on the client.
- **`get_data`**`(as_text: bool = False) -> Any` — Return the full body, joining a streaming iterable if necessary.
- **`get_etag`**`() -> str | None` — Return the `ETag` value without its quotes.
- **`get_json`**`(silent: bool = True) -> Any` — Parse the body as JSON.
- **`is_json`** (property) — `True` when the response is JSON.
- **`json`** (property) — The body parsed as JSON (`None` when it is not JSON).
- **`mimetype`** (property) — The media type without parameters.
- **`set_cookie`**`(key: str, value: str = '', max_age: int | None = None, expires: Any = None, path: str = '/', domain: str | None = None, secure: bool = False, httponly: bool = False, samesite: str | None = 'Lax') -> None` — Add a `Set-Cookie` header.
- **`set_data`**`(value: BodyType) -> None` — Replace the response body.
- **`set_etag`**`(value: str) -> None` — Set an `ETag` header, quoting the value when needed.
- **`set_expires`**`(expires: float | _dt.datetime | _dt.timedelta | None = None) -> str` — Set an `Expires` header.
- **`set_last_modified`**`(value: float | _dt.datetime | None = None) -> str` — Set a `Last-Modified` header (defaults to now).
- **`status`** (property) — The full status line, e.g. `"200 OK"`.
- **`status_code`** (property) — The numeric status code.
- **`text`** (property) — The response body decoded with `charset`.
- **`wsgi`**`(environ: Mapping[str, Any], start_response: Any) -> Iterable[bytes]` — Run this response as a WSGI application.

### `make_response(value: Any, status: int | str | None = None, headers: HeaderTypes = None) -> Response`

Convert a view's return value into a `Response`.

### `jsonify(*args: Any, *, status: int | str = 200, headers: HeaderTypes = None, **kwargs: Any) -> Response`

Return a JSON response.

### `redirect(location: str, code: int = 302, headers: HeaderTypes = None) -> Response`

Return a redirect response to *location*.

### `abort(code: int, description: str | None = None, *args: Any, **kwargs: Any) -> None`

Abort the request by raising `myframework.exceptions.HTTPException`.

### `stream_response(iterable: Iterable[bytes], status: int | str = 200, mimetype: str = 'text/plain', content_type: str | None = None) -> Response`

Create a streaming response from an iterable of bytes chunks.

### `Request`

An incoming HTTP request.

Defined in `myframework.request`.

- **`args`** (property) — Parsed query string parameters (`?a=1&a=2` keeps both values).
- **`base_url`** (property) — The absolute URL of the request without the query string.
- **`content_length`** (property) — The value of `Content-Length` if the client sent a valid one.
- **`content_type`** (property) — The raw `Content-Type` header, or `""`.
- **`cookies`** (property) — Cookies sent by the client as a plain dictionary.
- **`data`** (property) — The raw request body as bytes.
- **`files`** (property) — Uploaded files as a `myframework.datastructures.MultiDict`.
- **`form`** (property) — Parsed form fields from a urlencoded or multipart body.
- **`from_environ`**`(cls, environ: Mapping[str, Any], max_content_length: int | None = None) -> Request` — Build a `Request` from a WSGI environ dictionary.
- **`full_path`** (property) — The path plus `?query` (the HTTP request target).
- **`get_data`**`(as_text: bool = False, cache: bool = True) -> Any` — Return the raw request body.
- **`get_header`**`(name: str, default: str | None = None) -> str | None` — Return a single header value.
- **`get_json`**`(force: bool = False, silent: bool = False, cache: bool = True) -> Any` — Parse the body as JSON.
- **`get_param`**`(key: str, default: str | None = None) -> str | None` — Look a value up in the query string, then the form, then JSON.
- **`headers`** (property) — Read-only mapping of the request headers (case-insensitive).
- **`host`** (property) — The `Host` header, falling back to `SERVER_NAME:SERVER_PORT`.
- **`is_json`** (property) — `True` when the body claims to be JSON.
- **`is_secure`** (property) — `True` when the request was made over TLS.
- **`iter_pairs`**`() -> Iterator[tuple[str, str]]` — Iterate over `(key, value)` pairs of the query string.
- **`json`** (property) — The parsed JSON body (`None` when the body is empty).
- **`method`** (property) — The HTTP method, upper-cased (`GET`, `POST`, ...).
- **`mimetype`** (property) — The media type of the body without parameters, lower-cased.
- **`path`** (property) — The decoded path of the request, without the query string.
- **`query_string`** (property) — The raw query string as bytes.
- **`query_string_text`** (property) — The query string decoded as UTF-8 where possible.
- **`remote_addr`** (property) — The client address reported by the WSGI server.
- **`root_url`** (property) — The origin of the request, e.g. `https://example.com`.
- **`scheme`** (property) — `http` or `https`.
- **`script_name`** (property) — The mount point of the application (`SCRIPT_NAME`).
- **`stream`** (property) — The raw WSGI input stream.
- **`to_dict`**`() -> dict[str, Any]` — A small debugging summary of the request.
- **`url`** (property) — The absolute URL of the request, including the query string.
- **`urlencoded_form`**`() -> str` — Return the query string, re-encoded (useful for links).
- **`values`** (property) — Combined query string and form values (query string wins).

## Context locals and template helpers

Proxies bound to the current request/application, plus the template shortcuts.

### `current_app`

Forward every operation to the object returned by *getter*.

### `g`

Forward every operation to the object returned by *getter*.

### `has_request_context() -> bool`

`True` when the code is running inside a request.

### `url_for(endpoint: str, **values: Any) -> str`

Build a URL for *endpoint* using the active application's rules.

### `render_template(template_name: str, **context: Any) -> str`

Render a template using the active application's template environment.

### `render_template_string(source: str, **context: Any) -> str`

Render a template from a string with autoescaping enabled (no loader).

## Routing

Rules, converters, matching and URL building.

### `Map`

A collection of `Rule` objects with matching and building logic.

Defined in `myframework.routing`.

- **`add`**`(rule: str, endpoint: str, methods: Iterable[str] | None = None, defaults: Mapping[str, Any] | None = None, strict_slashes: bool | None = None, build_only: bool = False) -> Rule` — Register a rule and return it.
- **`build`**`(endpoint: str, values: Mapping[str, Any] | None = None, append_unknown: bool = True, url_prefix: str = '') -> str` — Build a URL path for *endpoint* (`PATH_INFO` form, no host).
- **`match`**`(path: str, method: str = 'GET') -> MatchResult` — Match *path*/*method*.
- **`resolve`**`(path: str, method: str = 'GET') -> tuple[Rule, dict[str, Any]]` — Match or raise `NotFound` / `MethodNotAllowed` / `RequestRedirect`.

### `Rule`

A single URL rule bound to an endpoint name and a set of methods.

Defined in `myframework.routing`.

- **`allowed_methods`** (property) — Methods this rule accepts (`HEAD` is implied by `GET`).
- **`build`**`(values: Mapping[str, Any], append_unknown: bool = True) -> tuple[str, list[tuple[str, str]]]` — Build a path from *values*; leftover values become a query string.
- **`compile`**`() -> re.Pattern[str]` — Compile (or return the cached) regular expression for this rule.
- **`match`**`(path: str) -> dict[str, Any] | None` — Match *path* and return converted arguments, or `None`.

### `BaseConverter`

Base class for URL converters.

Defined in `myframework.routing`.

- **`get_pattern`**`() -> str` — The regex fragment used for this converter.
- **`to_python`**`(value: str) -> Any` — Convert the URL fragment into the value passed to the view.
- **`to_url`**`(value: Any) -> str` — Convert a Python value into a URL fragment.

## Templates

The engine, its environment and the loaders.

### `TemplateEnvironment`

Holds template configuration: loader, filters, globals, autoescaping.

Defined in `myframework.templates`.

- **`clear_cache`**`() -> None` — Drop cached templates (useful after editing templates in tests).
- **`from_string`**`(source: str, name: str = '<string>') -> Template` — Compile template *source* directly (not cached).
- **`get_template`**`(name: str) -> Template` — Return a (cached) template by name.
- **`list_templates`**`() -> list[str]` — Return every template name the loader can see.
- **`render`**`(name: str, context: Mapping[str, Any] | None = None, **kwargs: Any) -> str` — Render the named template.
- **`render_string`**`(source: str, context: Mapping[str, Any] | None = None, **kwargs: Any) -> str` — Compile and render *source* in one call.
- **`select_template`**`(names: Iterable[str]) -> Template` — Return the first template that exists in *names*.

### `FileSystemLoader`

Load templates from one or more directories.

Defined in `myframework.templates`.

- **`get_source`**`(environment: Environment, template: str) -> tuple[str, str | None, Callable[[], bool]]` — Return `(source, filename, up_to_date)` for *template*.
- **`list_templates`**`() -> list[str]` — Return all template names known to this loader (for tooling).

### `DictLoader`

Load templates from a dictionary — handy for tests and small apps.

Defined in `myframework.templates`.

- **`get_source`**`(environment: Environment, template: str) -> tuple[str, str | None, Callable[[], bool]]` — Return `(source, filename, up_to_date)` for *template*.
- **`list_templates`**`() -> list[str]` — Return all template names known to this loader (for tooling).

## Static files

Traversal-safe file serving.

### `StaticFiles`

Serve a directory of static assets from a URL prefix.

Defined in `myframework.static`.

- **`exists`** (property) — `True` when the directory was configured and exists.
- **`handle`**`(filename: str, environ: Mapping[str, Any]) -> Response` — Serve *filename* (a URL-relative path) or raise `404`/`SecurityError`.

### `safe_join(directory: str, path: str) -> str`

Resolve *path* inside *directory* or raise `SecurityError`.

### `send_file(filepath: str, environ: Mapping[str, Any] | None = None, max_age: int | None = None, mimetype: str | None = None, conditional: bool = True, download_name: str | None = None) -> Response`

Return a streaming response for the file at *filepath*.

### `send_from_directory(directory: str, path: str, environ: Mapping[str, Any] | None = None, max_age: int | None = None, mimetype: str | None = None) -> Response`

Safely serve *path* from *directory*.

## Configuration and data structures

Settings and the request/response containers.

### `Config`

Application configuration.

Defined in `myframework.config`.

- **`as_dict`**`(hide_secrets: bool = True) -> dict[str, Any]` — Return a plain dict, optionally masking secret values.
- **`copy`**`() -> Config` — Return an independent copy.
- **`from_env`**`(prefix: str = 'MYFRAMEWORK_', environ: Mapping[str, str] | None = None) -> list[str]` — Load settings from environment variables such as `MYFRAMEWORK_DEBUG=1`.
- **`from_file`**`(path: str | os.PathLike[str]) -> None` — Load a JSON or TOML configuration file.
- **`from_mapping`**`(*args: Any, **kwargs: Any) -> list[str]` — Like `update` but returns the names of the keys that changed.
- **`from_object`**`(obj: Any) -> None` — Load upper-case attributes from a module or class.
- **`get_bool`**`(key: str, default: bool = False) -> bool` — Read a boolean setting.
- **`get_int`**`(key: str, default: int = 0) -> int` — Read an integer setting, raising on invalid values.
- **`get_list`**`(key: str) -> list[str]` — Read a comma separated or list-like setting as a list of strings.
- **`setdefault`**`(key: str, default: Any = None) -> Any` — D.setdefault(k[,d]) -> D.get(k,d), also set D[k]=d if k not in D
- **`update`**`(*args: Any, **kwargs: Any) -> None` — Update the configuration from a mapping, pairs, or keyword arguments.

### `Headers`

An ordered, case-insensitive header container.

Defined in `myframework.datastructures`.

- **`add`**`(key: str, value: str) -> None` — Append a header without removing existing values.
- **`getlist`**`(key: str) -> list[str]` — Return all values for *key*, case-insensitively.
- **`items`**`() -> Iterator[tuple[str, str]]` — Iterate over every `(name, value)` pair, including repeats.
- **`set`**`(key: str, value: str) -> None` — Replace all values for *key* with a single value.
- **`to_wsgi_list`**`() -> list[tuple[str, str]]` — Return the raw list of pairs, suitable for `start_response`.

### `MultiDict`

An ordered, multi-value mapping.

Defined in `myframework.datastructures`.

- **`add`**`(key: str, value: Any) -> None` — Append a value for *key*, keeping any existing ones.
- **`copy`**`() -> MultiDict` — Return a shallow copy.
- **`fromkeys`**`(cls, keys: Iterable[str], value: Any = '') -> MultiDict` — 
- **`getall`**`(key: str) -> list[Any]` — Return every value stored under *key* (empty list when missing).
- **`getlist`**`(key: str) -> list[Any]` — Return every value stored under *key* (empty list when missing).
- **`items`**`(multi: bool = False) -> Iterator[tuple[str, Any]]` — Iterate over items; with `multi=True` repeated keys appear again.
- **`lists`**`() -> Iterator[tuple[str, list[Any]]]` — Iterate over `(key, [values])` pairs.
- **`setlist`**`(key: str, values: Iterable[Any]) -> None` — Replace all values for *key* with *values*.
- **`to_dict`**`(flat: bool = True) -> dict[str, Any]` — Return a plain dict (lists for repeated keys when `flat=False`).

### `FileStorage`

A thin wrapper around an uploaded file part.

Defined in `myframework.datastructures`.

- **`content_length`** (property) — Size of the uploaded content in bytes.
- **`data`** (property) — The whole uploaded payload.
- **`read`**`(size: int = -1) -> bytes` — Read from the underlying stream.
- **`save`**`(destination: Any) -> None` — Write the upload to a path or a writable binary file object.

## Middleware

WSGI-level wrappers; the first one added is the outermost layer.

### `Middleware`

Base class for WSGI middleware.

Defined in `myframework.middleware`.

- **`process_environ`**`(environ: dict[str, Any]) -> dict[str, Any]` — Return a (possibly new) environ.  Default: unchanged.
- **`process_response`**`(status: str, headers: list[tuple[str, str]]) -> tuple[str, list[tuple[str, str]]]` — Return updated `(status, headers)`.  Default: unchanged.

### `WSGIMiddleware`

Base class for WSGI middleware.

Defined in `myframework.middleware`.

- **`process_environ`**`(environ: dict[str, Any]) -> dict[str, Any]` — Return a (possibly new) environ.  Default: unchanged.
- **`process_response`**`(status: str, headers: list[tuple[str, str]]) -> tuple[str, list[tuple[str, str]]]` — Return updated `(status, headers)`.  Default: unchanged.

### `RequestIDMiddleware`

Ensure every request carries an id, exposed as `X-Request-ID`.

### `AccessLogMiddleware`

Write one log line per request with status, duration and size.

### `HeaderMiddleware`

Add a static header to every response (unless already present).

Defined in `myframework.middleware`.

- **`process_response`**`(status: str, headers: list[tuple[str, str]]) -> tuple[str, list[tuple[str, str]]]` — Return updated `(status, headers)`.  Default: unchanged.

### `SecurityHeadersMiddleware`

Add conservative security headers to responses.

### `CORSMiddleware`

Add CORS headers and answer pre-flight requests.

### `TrustedHostMiddleware`

Reject requests whose `Host` header is not in an allowlist.

### `ProxyFix`

Trust `X-Forwarded-*` headers from a reverse proxy.

Defined in `myframework.middleware`.

- **`process_environ`**`(environ: dict[str, Any]) -> dict[str, Any]` — Return a (possibly new) environ.  Default: unchanged.

### `HTTPSRedirectMiddleware`

Redirect `http` requests to `https` (combine with `ProxyFix`).

### `middleware_chain(app: WSGIApp, *middlewares: Any) -> WSGIApp`

Wrap *app* so that `middlewares[0]` is the outermost layer.

## WSGI utilities

PEP 3333 helpers, usable without the rest of the framework.

### `WSGIApp(*args, **kwargs)`

### `wsgi_application(app: Any) -> WSGIApp`

Return the WSGI callable for *app*.

### `serve_wsgiref(app: WSGIApp, host: str = '127.0.0.1', port: int = 8000, quiet: bool = False, server_class: type[WSGIServer] = <class 'wsgiref.simple_server.WSGIServer'>) -> None`

Serve *app* with `wsgiref`, the standard library reference server.

## Exceptions

Import from either `myframework` or `myframework.exceptions`.

### `HTTPException`

An exception that is also a valid HTTP response.

Defined in `myframework.exceptions`.

- **`get_body`**`() -> str` — Return the default (escaped) HTML body for this error.
- **`get_headers`**`() -> list[tuple[str, str]]` — Return the headers this exception adds to its response.
- **`get_response`**`() -> Response` — Build a `myframework.response.Response` for this error.

### `BadRequest`

An exception that is also a valid HTTP response.

### `Unauthorized`

An exception that is also a valid HTTP response.

### `Forbidden`

An exception that is also a valid HTTP response.

### `NotFound`

An exception that is also a valid HTTP response.

### `MethodNotAllowed`

Raised when the URL exists but does not accept the request method.

Defined in `myframework.exceptions`.

- **`get_headers`**`() -> list[tuple[str, str]]` — Return the headers this exception adds to its response.

### `Conflict`

An exception that is also a valid HTTP response.

### `UnsupportedMediaType`

An exception that is also a valid HTTP response.

### `PayloadTooLarge`

The request body exceeded `MAX_CONTENT_LENGTH`.

### `InternalServerError`

An exception that is also a valid HTTP response.

### `ServiceUnavailable`

An exception that is also a valid HTTP response.

### `RequestRedirect`

A routing result that asks the client to retry on a different URL.

Defined in `myframework.exceptions`.

- **`get_response`**`() -> Response` — Build a `myframework.response.Response` for this error.
- **`new_url`** (property) — Alias of `new_path` (kept for readability in client code).

### `FrameworkException`

Base class for every exception defined by MyFramework.

### `RoutingError`

Base class for errors raised by the routing engine itself.

### `ConfigurationError`

Raised when the application configuration is invalid.

### `SecurityError`

Raised when a request attempts an unsafe file or path operation.

### `TemplateError`

Base class for template engine errors.

### `TemplateNotFound`

The requested template does not exist in the loader search path.

### `TemplateSyntaxError`

The template source is not valid.

### `TemplateRuntimeError`

An error occurred while rendering (e.g. unknown filter).

### `UndefinedError`

A template used a variable that does not exist.

---

Generated by `scripts/build_api_docs.py` — do not edit by hand.
