# Quickstart

This walkthrough assumes MyFramework is installed (see [Installation](installation.md)) and
takes you from an empty directory to a small site with templates, static files, a JSON API
and tests. Every command is copy-pasteable.

---

## 1. Create a project

```console
$ myframework new hello-site
$ cd hello-site
```

You get a runnable project:

```
hello-site/
├── app.py
├── pyproject.toml
├── README.md
├── templates/
│   ├── base.html
│   └── index.html
├── static/style.css
└── tests/test_app.py
```

## 2. Run it

```console
$ myframework run --debug
  MyFramework development server
  App:      'app'
  Debug:    on    Reloader: on
  Running:  http://127.0.0.1:8000/
```

Open <http://127.0.0.1:8000/>. The reloader restarts the process when you save a `.py`,
`.html` or `.css` file. `CTRL+C` stops the server.

Useful flags: `--host 0.0.0.0` (reachable from other machines), `--port 9000`,
`--no-reload`, `--app module:attribute` (default: `app` in the current directory).

## 3. Add routes

`app.py`:

```python
from myframework import App, abort, jsonify, render_template, request, url_for

app = App(__name__)


@app.route("/")
def index():
    return render_template("index.html", title="Home", items=["a", "b", "c"])


@app.route("/hello/<name>")
def hello(name):
    return f"<h1>Hello, {name}!</h1>"


@app.route("/users/<int:user_id>")
def user(user_id):
    if user_id > 100:
        abort(404, "No such user")
    return {"id": user_id, "url": url_for("user", user_id=user_id)}


@app.route("/widgets", methods=["GET", "POST"])
def widgets():
    if request.method == "POST":
        payload = request.get_json(silent=True) or {}
        return jsonify(created=payload), 201
    return {"widgets": []}
```

Things worth noticing:

* Return values are converted for you: `str` → HTML, `dict`/`list` → JSON,
  `(body, status)` / `(body, status, headers)` tuples, `Response` objects.
* `<name>` captures one path segment, `<int:user_id>` converts to `int`, `<path:rest>`
  spans slashes. `/users/me` beats `/users/<name>` automatically.
* `url_for` builds URLs from endpoint (function) names, so links never go stale.

```console
$ curl localhost:8000/users/7
{"id": 7, "url": "/users/7"}
$ myframework routes            # print the whole URL map
$ myframework routes --app app:app
```

## 4. Templates

`templates/index.html` extends `templates/base.html`:

```html
{% extends "base.html" %}
{% block title %}{{ title }}{% endblock %}
{% block content %}
  <h1>{{ title }}</h1>
  <ul>
  {% for item in items %}
    <li class="{{ 'last' if loop.last }}">{{ loop.index }}. {{ item }}</li>
  {% else %}
    <li>Nothing here yet.</li>
  {% endfor %}
  </ul>
{% endblock %}
```

* `{{ ... }}` output is HTML-escaped; `{% ... %}` is logic.
* Templates find `url_for`, `config`, `g` and anything you pass to `render_template`.
* Reach for `{% include %}`, `{% block %}`/`{{ super() }}`, `{% set %}`, `{% raw %}` and
  filters (`|upper`, `|join`, `|default`, `|tojson`, `|length`, …) as you need them.
* Private attributes (`_foo`, `__class__`) are blocked and expressions are interpreted, not
  `eval`'d — see [Security](security.md).

## 5. Static files

Put files in `static/` and link them with `url_for`:

```html
<link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
```

The dev server serves them with `ETag`, `Last-Modified` and 304 support. In production let
nginx/CDN handle `/static/` (see [Deployment](deployment.md)).

## 6. Configuration

```python
app = App(__name__, MAX_CONTENT_LENGTH=2 * 1024 * 1024, DEBUG=False)
app.config.from_env("MYAPP_")                 # MYAPP_DEBUG=True -> config["DEBUG"]
app.config.from_file("settings.toml", format="toml")
app.config.from_object("myproject.settings")
```

Read settings with `app.config["KEY"]`, `app.config.get_int("KEY", default)` or
`current_app.config["KEY"]` inside views. Unknown keys raise `AttributeError` instead of
silently doing nothing.

## 7. Testing

The test client runs the real WSGI application in-process — no sockets, no server:

```python
# tests/test_app.py
from app import app


def test_index():
    response = app.test_client().get("/")
    assert response.status_code == 200
    assert "Home" in response.text


def test_user_json():
    response = app.test_client().get("/users/7")
    assert response.json == {"id": 7, "url": "/users/7"}


def test_missing():
    app.test_client().get("/users/101").assert_status(404)
```

```console
$ pip install pytest
$ pytest
```

`app.test_client()` supports `get/post/put/patch/delete/head/options`, `json=`, `data=`,
`form=`, `files=`, `headers=`, `query_string=`, `follow_redirects=` and cookie persistence;
responses expose `.status_code`, `.json`, `.text`, `.headers`, `.history` and the
`assert_*` helpers.

## 8. Errors and debugging

```python
@app.errorhandler(404)
def not_found(error):
    return render_template("404.html", message=error.description), 404


@app.errorhandler(ValueError)
def bad_value(error):
    return {"error": str(error)}, 400
```

In debug mode unexpected exceptions render a traceback page; with `DEBUG=False` you get a
generic 500 page and the traceback goes to the log. Production checklist:

* `DEBUG=False`, `PROPAGATE_EXCEPTIONS` unset;
* serve with Gunicorn/Waitress, not `myframework run`;
* behind a proxy, add `ProxyFix` and `TrustedHostMiddleware`/`PREFERRED_HOST`;
* add `SecurityHeadersMiddleware` (and HSTS once TLS works).

## 9. Deploy

```console
$ pip install gunicorn
$ gunicorn --workers 4 --bind 0.0.0.0:8000 "app:app"
```

`app` is a WSGI application, so anything that speaks WSGI (Gunicorn, Waitress, uWSGI,
mod_wsgi) can serve it. Full configuration, nginx and systemd examples:
[Deployment](deployment.md).

---

## Where to go next

| I want to… | Read |
| --- | --- |
| look up a function or class | [API reference](api.md) |
| understand how a request flows | [Architecture](architecture.md) |
| know what is *not* provided (auth, sessions, CSRF) | [Security](security.md) |
| run the whole project in production | [Deployment](deployment.md) |
| see complete programs | `examples/` in the source distribution |
