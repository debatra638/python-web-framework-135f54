# Deployment

MyFramework applications are ordinary WSGI applications, so the deployment story is the
standard Python one.

## 1. Build and install

```console
$ python -m build                      # dist/myframework-0.1.0.tar.gz + .whl
$ python -m venv /srv/apps/myapp/.venv
$ /srv/apps/myapp/.venv/bin/pip install /path/to/myframework-0.1.0-py3-none-any.whl
$ /srv/apps/myapp/.venv/bin/pip install gunicorn
```

## 2. Gunicorn

```console
$ cd /srv/apps/myapp
$ /srv/apps/myapp/.venv/bin/gunicorn \
    --workers 4 \
    --threads 2 \
    --bind 0.0.0.0:8000 \
    --access-logfile - \
    --error-logfile - \
    "wsgi:app"
```

`wsgi.py` in the project directory:

```python
from myadmin import create_app

app = create_app()
```

Gunicorn (sync workers) is fine here because views are synchronous. Threads help with
I/O-bound views; scale workers to `2 × CPU + 1` as a starting point.

## 3. Waitress (Windows-friendly, no fork)

```console
$ pip install waitress
$ waitress-serve --listen=0.0.0.0:8000 wsgi:app
```

## 4. Reverse proxy (nginx) — TLS, compression, static files

```nginx
server {
    listen 443 ssl http2;
    server_name example.com;

    ssl_certificate     /etc/letsencrypt/live/example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/example.com/privkey.pem;

    # Let the proxy serve static assets when you want gzip/caching.
    location /static/ {
        alias /srv/apps/myapp/static/;
        expires 1h;
        gzip on;
        gzip_types text/css application/javascript image/svg+xml;
    }

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host              $host;
        proxy_set_header X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host  $host;
    }
}
```

Because the proxy sets `X-Forwarded-*`, enable the middleware in the app — it is off by
default so that a direct client cannot spoof its address or scheme:

```python
from myframework import ProxyFix, SecurityHeadersMiddleware, HTTPSRedirectMiddleware

app.use(ProxyFix(x_for=1, x_proto=1, x_host=1))     # one trusted hop
app.use(HTTPSRedirectMiddleware())                  # http -> https (308)
app.use(SecurityHeadersMiddleware(hsts_max_age=31536000))  # include HSTS only with TLS
app.config["PREFERRED_HOST"] = "example.com"        # reject poisoned Host headers
```

## 5. Process supervision

```ini
# /etc/systemd/system/myapp.service
[Unit]
Description=MyFramework app
After=network.target

[Service]
User=www-data
WorkingDirectory=/srv/apps/myapp
Environment="MYFRAMEWORK_MAX_CONTENT_LENGTH=2097152"
ExecStart=/srv/apps/myapp/.venv/bin/gunicorn --workers 4 --bind 127.0.0.1:8000 wsgi:app
Restart=always

[Install]
WantedBy=multi-user.target
```

Configuration can come from environment variables (`MYFRAMEWORK_*`), a JSON/TOML file, or
`app.config.from_object("myapp.settings")` — pick one and keep secrets in the environment or
a secrets manager, not in the repository.

## 6. Health checks and logs

```python
@app.route("/healthz")
def healthz():
    return {"status": "ok"}
```

* Access logs: `AccessLogMiddleware` (application level) or Gunicorn's `--access-logfile`.
* Add `RequestIDMiddleware` so a 500 in your logs can be matched to a request id; it is
  echoed in the `X-Request-ID` response header.
* Set `LOG_LEVEL=INFO` (or `WARNING`) in production; `DEBUG=True` must never be used there.

## 7. Scaling notes

* The app keeps no request state outside `contextvars`; any number of worker **processes**
  is safe. Shared state (caches, counters) belongs in Redis/Postgres, not module globals.
* Uploads are buffered in memory up to `MAX_CONTENT_LENGTH`. Keep the limit small, or
  stream large files yourself.
* Static files are served by Python; for high traffic let nginx/CDN handle them.
