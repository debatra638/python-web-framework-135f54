# Architecture

This document explains how a request flows through MyFramework, which module owns which
responsibility, and why the seams are where they are.

## Module map

```
                    ┌──────────────────────────────────────────┐
  WSGI server  ───▶ │ app.wsgi_app  (middleware pipeline)      │
 (Gunicorn,         └───────────────┬──────────────────────────┘
  waitress,                         │  WSGIMiddleware layers (CORS, security headers, ...)
  wsgiref,                          ▼
  devserver)              ┌──────────────────────┐
                          │ App._dispatch_wsgi   │  builds Request, pushes contextvars
                          └──────────┬───────────┘
                                     ▼
                     ┌───────────────────────────────┐
                     │ App.full_dispatch_request     │
                     │  1. match URL  (routing.Map)  │  → 404 / 405 / 308
                     │  2. before_request hooks      │
                     │  3. view function             │  → return value
                     │  4. make_response             │  → Response
                     │  5. after_request hooks       │
                     │  6. teardown_request hooks    │
                     └──────────────┬────────────────┘
                                    ▼
                          Response.wsgi(environ, start_response)
```

| Module | Responsibility | Depends on |
| --- | --- | --- |
| `exceptions.py` | `HTTPException` hierarchy, framework/template/security errors | stdlib only |
| `utils.py` | escaping, `Markup`, cookies, dates, header parsing | stdlib only |
| `datastructures.py` | `MultiDict`, `Headers`, `FileStorage` | stdlib only |
| `routing.py` | rules, converters, matching, URL building | exceptions, utils |
| `request.py` | WSGI environ → `Request` (lazy body/form/json parsing) | datastructures, exceptions, utils |
| `response.py` | `Response` (also a WSGI app), `jsonify`, `redirect`, `abort` | datastructures, exceptions, utils |
| `templates.py` | lexer → parser → AST nodes → restricted evaluator; loaders | exceptions, utils |
| `static.py` | `safe_join`, `send_file`, `StaticFiles` (also a WSGI app) | exceptions, response, utils |
| `config.py` | defaults, env/file/object loading, `ConfigAttribute` | exceptions |
| `globals.py` | `request`/`g`/`current_app` proxies, `RequestContext` | contextvars |
| `middleware.py` | WSGI middleware collection | stdlib only (cookie/WSGI conventions) |
| `wsgi.py` | PEP 3333 helpers, validation, `wsgiref` runner, `make_environ` | stdlib only |
| `app.py` | application object: routing table, hooks, errors, templates, pipeline | all of the above |
| `devserver.py` | threaded `wsgiref` server + file reloader | app (typing only) |
| `testing.py` | `Client`, `TestResponse` (real WSGI round-trip) | request, response, wsgi |
| `cli.py` | `myframework` command line interface | app import path |

Dependencies point downwards only: `app.py` is the composition root, and no module imports
`app.py` at runtime (only under `TYPE_CHECKING`), which keeps import cycles impossible.

## Request lifecycle in detail

1. **Server → app.** The WSGI server calls `App.__call__(environ, start_response)`, which
   delegates to `App.wsgi_app` — the outermost middleware layer of the pipeline built once
   at first use (`App._build_pipeline`, invalidated by `app.use(...)`).
2. **Request object.** `_dispatch_wsgi` constructs a `Request` from the environ. Nothing is
   read from `wsgi.input` yet; `MAX_CONTENT_LENGTH` is stored for later enforcement.
3. **Context push.** `RequestContext.push()` sets the `request`, `current_app` and `g`
   `ContextVar`s, so views, hooks, templates and error handlers can use the proxies.
4. **Matching.** `routing.Map.match` finds the most specific rule, then checks the method.
   Failures become `NotFound`, `MethodNotAllowed` (with `Allow`) or a `RequestRedirect`
   (`308`) for a trailing-slash mismatch.
5. **Before hooks.** `before_request` functions run in registration order. Returning
   anything other than `None` short-circuits the view.
6. **View.** `dispatch_request` calls the view with the converted URL arguments. `OPTIONS`
   is answered automatically when the view did not claim it.
7. **Response conversion.** `make_response` accepts `str`, `bytes`, `dict`/`list`,
   `Response`, `(body, status[, headers])`, `None`, WSGI callables and byte iterables.
8. **After hooks.** `after_request` functions run in reverse order and must return the
   response; `X-Content-Type-Options: nosniff` is added if absent.
9. **Teardown.** `teardown_request` functions always run, receiving the exception (or
   `None`); their own errors are logged, never raised.
10. **Response → server.** `Response.wsgi` validates/normalises headers (latin-1), sets
    `Content-Length` for in-memory bodies, strips the body for `HEAD`, and hands the
    iterable to the server. `close()` releases streaming resources.

Errors can be raised anywhere in steps 4–8. `full_dispatch_request` funnels them through
`handle_user_exception` → (`HTTPException` response | registered handler | `500`). With
`PROPAGATE_EXCEPTIONS` (default in debug/testing) the exception is re-raised so tests and
the debugger can see it.

## Concurrency and state

* One `App` instance is shared by all request threads. After startup the routing table,
  hooks, handlers and template cache are read-mostly; registration after the first request
  is not supported.
* Per-request state lives in `contextvars`, so a threaded server, a thread pool or an
  `asyncio` task each see their own `request`/`g`.
* Streaming views produce their bytes *after* the context is popped. Capture anything you
  need from `request` before the first `yield`.
* Response objects are per-request and not shared.

## The template engine

```
source ──tokenize()──▶ tokens ──TemplateParser──▶ TemplateBody
                                                  ├── nodes (text/{{ }}/if/for/set/include/block)
                                                  ├── blocks {name: BlockNode}
                                                  └── extends (expression)
TemplateBody ──render_body()──▶ HTML
                   │
                   ├─ inheritance: parent body rendered with the block chain
                   │  (ancestor first, so the most derived definition wins and
                   │   {{ super() }} walks one level up)
                   └─ expressions: ast.parse → Evaluator (allow-list)
```

`Evaluator` handles exactly: constants, names, attribute/subscript access (private names
blocked), calls, arithmetic, comparisons, boolean logic, conditional expressions and
f-strings. Anything else raises a `TemplateRuntimeError` that names the unsupported node —
there is no path from a template to `eval`, imports, attribute assignment or `__globals__`.

Loading is confined to `FileSystemLoader.searchpath`: names are normalised, `..`/absolute
paths/backslashes are rejected and the resolved `realpath` must stay inside the search path.
`auto_reload` compares the loader's `up_to_date()` callable (mtime) and recompiles on change.

## Where to extend

| Want to add | Touch |
| --- | --- |
| a URL converter | `routing.BaseConverter` + `app.converter()` |
| middleware | subclass `middleware.WSGIMiddleware` |
| template filter/global | `app.template_filter()` / `app.template_global()` |
| a request property | `request.Request` (keep it lazy) |
| a new response type | `response.make_response` |
| sessions | new module + `Response.set_cookie` (design the signing scheme first) |
| blueprints | `routing.Map` already supports many rules per app; a blueprint would be a
  registry that flushes rules into an app with a URL prefix |
