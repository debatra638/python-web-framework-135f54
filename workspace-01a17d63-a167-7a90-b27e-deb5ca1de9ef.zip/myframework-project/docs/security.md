# Security notes

MyFramework aims for *safe defaults* and *honest documentation*. This page lists what the
framework actually does, what it deliberately leaves to you, and how to verify each claim.

## Threat model

In scope: inputs that reach the framework — the request line, headers, cookies, query
string, body, uploaded files, and the paths used to reach templates/static files. The goal
is that hostile input can never (a) execute code, (b) escape a directory, (c) be reflected
as active HTML, or (d) crash the worker.

Out of scope: everything above the framework (TLS termination, authentication, authorization,
CSRF, rate limiting, WAF, secrets management) and everything below it (application queries,
template *content* you author, third-party packages you add).

## Implemented controls

| Control | Where | Tests |
| --- | --- | --- |
| HTML autoescaping of `{{ }}` output (`& < > " '`) | `templates.py`, `utils.escape` | `tests/test_templates.py`, `tests/test_security.py` |
| Error pages escape every embedded value | `exceptions.py`, `app._debug_response` | `tests/test_response.py`, `tests/test_security.py` |
| Request body limit applied before reading, including unknown-length bodies | `request.Request._read_body` | `tests/test_security.py`, `tests/test_app.py` |
| Static path normalisation + realpath containment + symlink blocking + NUL/backslash rejection | `static.safe_join` | `tests/test_static.py` |
| Template path containment (`..`, absolute, symlink escapes) | `templates.FileSystemLoader` | `tests/test_templates.py` |
| Executables/unknown types served as `application/octet-stream` | `static.send_file` | `tests/test_static.py` |
| `X-Content-Type-Options: nosniff` on every response | `App.process_response` | `tests/test_app.py`, `tests/test_security.py` |
| CSP / `X-Frame-Options` / `Referrer-Policy` available via middleware | `middleware.SecurityHeadersMiddleware` | `tests/test_middleware.py` |
| Cookie defaults `Path=/`, `SameSite=Lax`; `Secure`/`HttpOnly` explicit | `utils.dump_cookie` | `tests/test_response.py`, `tests/test_security.py` |
| No `eval`/`exec` in templates; private attribute access blocked | `templates.Evaluator` | `tests/test_templates.py`, `tests/test_security.py` |
| Generic `500` page in production; tracebacks only with `DEBUG` | `app.handle_exception` | `tests/test_security.py` |
| Malformed JSON/Content-Length/multipart/cookies → `400`/`415`, never a crash | `request.py` | `tests/test_request.py`, `tests/test_security.py` |
| Host-header pinning (`PREFERRED_HOST`) and proxy-header opt-in (`ProxyFix`) | `app.py`, `middleware.py` | `tests/test_app.py`, `tests/test_middleware.py` |
| URL-encoded input decoded once, then matched; `%2F` cannot smuggle segments | `request.path`, `routing.Map` | `tests/test_security.py` |
| JSON `tojson` filter escapes `<`, `>`, `&` for safe `<script>` embedding | `templates._filter_tojson` | `tests/test_templates.py` |

## Not provided (and what to do instead)

* **Authentication / authorization.** Nothing is built in. Use a vetted library, verify
  password hashes with a memory-hard KDF (argon2/bcrypt/scrypt), and enforce authorization
  in a `before_request` hook.
* **Sessions and CSRF.** No session machinery exists (the `SECRET_KEY` setting is reserved).
  Implement signed cookies (e.g. `itsdangerous`) and CSRF tokens (a random token stored in
  the session, echoed in forms and compared with `hmac.compare_digest`) yourself, or add
  them to the framework with tests.
* **Rate limiting / brute-force protection.** Put it in a reverse proxy or middleware
  (a `WSGIMiddleware` is a fine home for it).
* **HTTPS.** The dev server speaks plain HTTP. Terminate TLS at a proxy, then enable
  `HTTPSRedirectMiddleware`, `SecurityHeadersMiddleware(hsts_max_age=...)` and
  `SESSION_COOKIE_SECURE = True` (for your own session implementation).
* **CSP for your own app.** `SecurityHeadersMiddleware` ships a conservative starting policy
  (`default-src 'self'`, inline styles allowed). If you use CDNs or inline scripts, write
  your own policy — do not assume the default fits.
* **Upload storage.** Uploads are held in memory (bounded by `MAX_CONTENT_LENGTH`). If you
  accept large files, stream them to disk yourself and validate the content type *and*
  extension; never serve an upload directory with `StaticFiles`.

## Deployment checklist

1. `DEBUG = False` (and never pass `--debug` to a production server).
2. Run under Gunicorn/Waitress/uWSGI with worker timeouts; do not use `myframework run`.
3. Set `MAX_CONTENT_LENGTH` to the smallest value your app needs.
4. Behind a proxy: enable `ProxyFix` **only** with the number of trusted hops, and set
   `PREFERRED_HOST`/`TrustedHostMiddleware` to your real hostnames.
5. Enable `SecurityHeadersMiddleware` and `HTTPSRedirectMiddleware`; add HSTS once HTTPS is
   confirmed working.
6. Serve static assets from your reverse proxy/CDN in production if you need caching and
   compression; the built-in handler is correct but simple (no range requests, no gzip).
7. Log at `INFO`, ship logs off-box, and make sure `X-Request-ID` (from
   `RequestIDMiddleware`) is in your access logs so a 500 can be traced to a request.

## Reporting

This is an educational framework at version `0.1.0`; it has not been audited. If you use it
for anything that matters, review the modules relevant to your threat model — they are small
on purpose. The test suite encodes the security expectations listed above, so any change
that weakens one of them should break a test.
