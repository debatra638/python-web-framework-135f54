"""Example: a complete small site using templates, static files and a JSON API.

Run it with::

    python examples/blog_app.py
    # or
    myframework run --app examples.blog_app:app --debug

Endpoints
---------
``GET  /``                 rendered home page (template inheritance + partials)
``GET  /users``            rendered user table
``GET  /users/<username>`` rendered profile page (HTML-escaped)
``GET  /api/items``        JSON list
``POST /api/items``        JSON create (returns 201 + Location)
``GET  /old-page``         301 redirect example
``GET  /boom``             deliberate error (custom 500 handler)
"""

from __future__ import annotations

import os

from myframework import (
    App,
    HTTPException,
    Response,
    abort,
    jsonify,
    redirect,
    render_template,
    request,
    url_for,
)

HERE = os.path.dirname(os.path.abspath(__file__))

app = App(
    __name__,
    template_dir=os.path.join(HERE, "templates"),
    static_dir=os.path.join(HERE, "static"),
)

USERS = [
    {"name": "Ada Lovelace", "bio": "Mathematician & first programmer."},
    {"name": "Grace Hopper", "bio": "Compiler pioneer, <script>alert(1)</script> fan."},
]

ITEMS: list[dict[str, object]] = [{"id": 1, "name": "Widget", "price": 9.99}]


@app.context_processor
def inject_globals() -> dict[str, object]:
    """Values available in every template."""
    from myframework import __version__

    return {"site_version": __version__}


@app.route("/")
def index() -> str:
    return render_template(
        "index.html",
        title="MyFramework demo",
        user={"name": "visitor"},
        visits=42,
        items=["Templates", "Routing", "Middleware", "WSGI"],
    )


@app.route("/users")
def users_page() -> str:
    return render_template("users.html", users=USERS)


@app.route("/users/<username>")
def user_detail(username: str) -> str:
    for user in USERS:
        if user["name"].lower() == username.lower():
            return render_template(
                "index.html", title=username, user=user, visits=1, items=[user["bio"]]
            )
    abort(404, f"No user named {username!r}")
    raise AssertionError("unreachable")  # abort() always raises


@app.route("/api/items", methods=["GET", "POST"])
def api_items() -> Response:
    if request.method == "POST":
        payload = request.get_json(silent=True) or {}
        if not isinstance(payload, dict) or "name" not in payload:
            abort(400, "Expected a JSON object with a 'name' field.")
        item = {
            "id": len(ITEMS) + 1,
            "name": str(payload["name"]),
            "price": payload.get("price", 0),
        }
        ITEMS.append(item)
        response = jsonify(item, status=201)
        response.headers["Location"] = url_for("api_items")
        return response
    return jsonify(items=ITEMS, count=len(ITEMS))


@app.route("/old-page")
def old_page() -> Response:
    return redirect(url_for("index"), code=301)


@app.route("/boom")
def boom() -> str:
    raise RuntimeError("This is an intentional error used by the example.")


@app.errorhandler(404)
def not_found(error: HTTPException) -> tuple[str, int]:
    return f"<h1>404</h1><p>{error.description}</p>", 404


@app.errorhandler(RuntimeError)
def runtime_error(error: RuntimeError) -> tuple[str, int]:
    app.logger.warning("RuntimeError handled: %s", error)
    return f"<h1>Something broke</h1><p>{error}</p>", 500


if __name__ == "__main__":
    app.run(debug=True)
