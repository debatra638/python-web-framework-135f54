"""Example: a JSON REST API deployed behind middleware.

Demonstrates CORS, request ids, security headers, custom error handlers and
WSGI middleware composition.

    gunicorn -w 4 "examples.api_app:app"
    curl -i http://127.0.0.1:8000/api/notes
"""

from __future__ import annotations

import os
import threading

from myframework import (
    App,
    CORSMiddleware,
    RequestIDMiddleware,
    Response,
    SecurityHeadersMiddleware,
    abort,
    jsonify,
    request,
)

app = App(
    __name__,
    template_dir=os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates"),
    static_dir=os.path.join(os.path.dirname(os.path.abspath(__file__)), "static"),
    MAX_CONTENT_LENGTH=64 * 1024,  # 64 KiB is plenty for a JSON API
)

# WSGI middleware: the first added is the outermost layer.
app.use(RequestIDMiddleware())
app.use(CORSMiddleware(allow_origins=["https://example.com"], allow_credentials=True))
app.use(SecurityHeadersMiddleware())

_NOTES: dict[int, dict[str, object]] = {1: {"id": 1, "text": "first note"}}
_LOCK = threading.Lock()
_NEXT_ID = 2


@app.route("/api/notes", methods=["GET"])
def list_notes() -> Response:
    return jsonify(notes=list(_NOTES.values()))


@app.route("/api/notes", methods=["POST"])
def create_note() -> Response:
    global _NEXT_ID
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict) or not isinstance(payload.get("text"), str):
        abort(422)
    with _LOCK:
        note_id = _NEXT_ID
        _NEXT_ID += 1
        _NOTES[note_id] = {"id": note_id, "text": payload["text"]}
    response = jsonify(_NOTES[note_id], status=201)
    response.headers["Location"] = f"/api/notes/{note_id}"
    return response


@app.route("/api/notes/<int:note_id>", methods=["GET", "PATCH", "DELETE"])
def note_detail(note_id: int) -> Response:
    note = _NOTES.get(note_id)
    if note is None:
        abort(404, f"Note {note_id} does not exist.")
    if request.method == "DELETE":
        del _NOTES[note_id]
        return Response(status=204)
    if request.method == "PATCH":
        payload = request.get_json(silent=True) or {}
        note.update({key: payload[key] for key in ("text",) if key in payload})
    return jsonify(note)


@app.errorhandler(404)
def not_found(error):
    return jsonify(error="not_found", message=error.description), 404


@app.errorhandler(422)
def unprocessable(error):
    return jsonify(error="unprocessable_entity", message="Body must be {'text': str}."), 422


if __name__ == "__main__":
    app.run(port=8000, debug=True)
