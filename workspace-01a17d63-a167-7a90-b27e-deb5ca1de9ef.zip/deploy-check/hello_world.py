"""Example: the smallest possible MyFramework application.

python examples/hello_world.py
# open http://127.0.0.1:8000/
"""

from myframework import App, request

app = App(__name__)


@app.route("/")
def home():
    return "<h1>My Website</h1>"


@app.route("/users/<username>")
def user_profile(username):
    return f"<h1>Hello, {username}</h1>"


@app.route("/api/data", methods=["GET"])
def get_data():
    return {"message": "Hello from my framework"}


@app.route("/greet", methods=["GET", "POST"])
def greet():
    # ``request`` is a context-local proxy: no need to pass it to views.
    name = request.args.get("name") or (request.get_json(silent=True) or {}).get("name") or "world"
    return {"greeting": f"Hello, {name}!"}


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8000, debug=True)
