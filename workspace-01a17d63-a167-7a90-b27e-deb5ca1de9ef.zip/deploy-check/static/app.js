document.addEventListener("DOMContentLoaded", () => {
  console.log("MyFramework example loaded");
});
